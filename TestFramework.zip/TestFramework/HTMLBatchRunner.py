import fnmatch
import os
import sys
import unittest
from time import strftime

import HTMLTestRunner
from utilities import Utilities
from utilities import excel_handler

util = Utilities.Utilities()
global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'WebConfig'))

sBatchExecutionFileName = "WebPortalSuite.txt"
sProjectPath = os.path.abspath(os.path.join(os.path.dirname(__file__), "."))

# Function to fetch the test scripts to be executed in the suite
portal_name = global_config.get('Web', 'PortalSuite')  # Suite name in webconfig.ini
excel_handler.get_suite_file(portal_name)

if sProjectPath.replace("\\", "\\\\") not in sys.path:
    sys.path.append(sProjectPath.replace("\\", "\\\\"))


def all_test_modules(root_dir, pattern):
    """
    The function is used to get all the test modules
    :param root_dir: root directories to be mentioned
    :param pattern: pattern to be provided
    :return: module path
    """
    test_file_names = all_files_in(root_dir, pattern)
    return [path_to_module(str) for str in test_file_names]


def check_if_testexist_infile(test_name):
    """
    The function is used check whether the text file exist
    :param test_name: name of the test
    :return: True for success else false
    """
    Flag = ""
    sBatchFilePath = os.path.join(sProjectPath, sBatchExecutionFileName)

    with open(sBatchFilePath, 'r') as logfile:
        for line in logfile:
            if line.strip() == test_name:
                Flag = True
                break
            else:
                Flag = False

    if Flag:
        return True
    else:
        return False


def all_files_in(root_dir, pattern):
    """
    The function is used to search the file in the directories
    :param root_dir: root directories to be mentioned
    :param pattern: pattern to be provided
    :return: matches
    """
    matches = []

    for root, dirnames, filenames in os.walk(root_dir):
        for filename in fnmatch.filter(filenames, pattern):
            if check_if_testexist_infile(filename):
                matches.append(os.path.join(root, filename))
    return matches


def path_to_module(py_file):
    """
    the function is used to fetch the path to the module
    :param py_file: file name
    :return: formatted file name
    """
    return strip_leading_dots( \
        replace_slash_by_dot( \
            strip_extension(py_file)))


def strip_extension(py_file):
    """
    the function is used to strip the file
    :param py_file:
    :return: stripped file name
    """
    return py_file[0:len(py_file) - len('.py')]


def replace_slash_by_dot(str):
    """
    The function is used to replace slash by dot
    :param str:
    :return: replaced string
    """
    return str.replace('\\', '.').replace('/', '.')


def strip_leading_dots(str):
    """
    The function is used to strip the leading dots
    :param str:
    :return: formatted string
    """
    while str.startswith('.'):
        str = str[1:len(str)]
    return str

# To create the suite file from the testscripts in 'WebPortalSuite.txt'
module_names = all_test_modules('.', '*.py')
print(module_names)
suites = [unittest.defaultTestLoader.loadTestsFromName(mname) for mname
          in module_names]

testSuite = unittest.TestSuite(suites)
runner = unittest.TextTestRunner(verbosity=1)
sTime = strftime("%Y-%m-%d_%H-%M-%S")
directory = os.path.join(sProjectPath + "/output/web/webportal/")
# create output directory if it does not exists
if not os.path.exists(directory):
    os.makedirs(directory)
filename = sProjectPath + '/output/web/webportal/Web_Execution_Report_' + portal_name + sTime + '.html'
output = open(filename, "wb")
sImagePath = sProjectPath + "/python.png"
output = open(filename, "wb")
runner = HTMLTestRunner.HTMLTestRunner(
    stream=output,
    title='Web Portal Test Report',
    description='Web Portal Test Report'
)


runner.run(testSuite)
