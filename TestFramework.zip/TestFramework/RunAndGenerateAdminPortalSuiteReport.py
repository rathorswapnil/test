import unittest
import HTMLTestRunner
import os
from testscripts.web.adminportal import TC0001AdminUserPermissionValidation
from testscripts.web.adminportal import TC0002AdminRolesPermissionValidation
from testscripts.web.adminportal import TC0003AdminUserWithRolePermissionValidation
from testscripts.web.adminportal import TC0004AdminMultiRolePermissionValidation

# get the directory path to output report file
report_location = os.path.abspath(os.path.join(os.path.dirname(__file__), "."))
# get all tests from SearchProductTest and HomePageTest class

UserPermissionSelection = unittest.TestLoader().loadTestsFromTestCase(TC0001AdminUserPermissionValidation.TC0001AdminUserPermissionValidation)
RolePermissionSelection = unittest.TestLoader().loadTestsFromTestCase(TC0002AdminRolesPermissionValidation.TC0002AdminRolesPermissionValidation)
UserRolePermissionSelection = unittest.TestLoader().loadTestsFromTestCase(TC0003AdminUserWithRolePermissionValidation.TC0003AdminUserWithRolePermissionValidation)
MultiRolePermissionSelection=unittest.TestLoader().loadTestsFromTestCase(TC0004AdminMultiRolePermissionValidation.TC0004AdminMultiRolePermissionValidation)
# Creation of suite
web_tests = unittest.TestSuite([UserPermissionSelection,RolePermissionSelection,UserRolePermissionSelection,MultiRolePermissionSelection])

directory = os.path.join(report_location + "/output/web/adminportal/")
# create output directory if it does not exists
if not os.path.exists(directory):
    os.makedirs(directory)
# open the report file
outfile = open(directory+"AdminUserPermissionValidation.html", "w")

# configure HTMLTestRunner options
runner = HTMLTestRunner.HTMLTestRunner(
    stream=outfile,
    title='Admin User Permission Validation Test Report',
    description='Admin User Permission Validation Tests Report'
)

# run the suite using HTMLTestRunner
runner.run(web_tests)
