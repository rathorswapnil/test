import os
import unittest
import re
from utilities import Utilities


class BaseTestCase(Utilities.Utilities, unittest.TestCase):
    """ This class contains all functions common for test case"""

    def get_requiredTest_data(self, file_name):
        """
        Function to get webportal login credentials
        :param file_name: test data file name
        :return: parser
        """
        try:
            """Read webportal test data file"""
            return self.read_ini_file(os.path.join(self.get_project_path(), 'testdata','web', 'webportal', file_name))
        except Exception as e:
            raise Exception("Unable to read test data file :'{0}'".format(e))

    def create_csv_filename(self, filename_list):
        """
        This function creates filename similar to exported csv from the given list of variables
        :param filename_list: contains variables present in the name of the file
        :return: filename
        """
        filename = ""
        try:
            for var in filename_list:
                var = re.sub(' ', '', var.lower())
                #var = re.sub(' |-|&', '', var.lower())
                filename = filename+var+'-'
            filename = filename[:-1]+'.csv'
            return filename
        except Exception as e:
            raise Exception("Unable to create filename from given filename variable list :'{0}'".format(e))


# if __name__ == '__main__':
#     test = BaseTestCase()
#     test.create_csv_filename(['United States' , 'RSR Metro', '1H 2016', 'Speed','Winners'])