# encoding: utf-8
import traceback
import unittest
from utilities import Utilities
from actioncontrollers.mobile.CoverageMap.iOS import HomeScreen
from actioncontrollers.mobile.CoverageMap.iOS import AboutScreen


class About_Privacy(unittest.TestCase):
    """Verify "About" screen - Priority1  testcase-- TC064"""
    HomeScreen = HomeScreen.HomeScreen()
    AboutScreen = AboutScreen.AboutScreen()
    util = Utilities.Utilities()

    def setUp(self):

        """To handle welcome screen of CoverageMap app"""
        if (self.HomeScreen.verify_element_is_present('accept', 'name')):
            self.assertTrue(self.HomeScreen.welcome_screen_navigation(), "Could not save welcome screen settings")

    def test_About_Privacy(self):
        """Verify "About" screen - Priority1  testcase-- TC064"""
        try:
            # TC064
            print "TC064 started"
            """Locate and click on menu button"""
            self.assertTrue(self.HomeScreen.touch_on_menu_button(), "Could not Click on the menu button")
            """Locate and click on About button"""
            self.assertTrue(self.HomeScreen.touch_on_navigation_option("About"),
                            "Could not Click on the About button")

            """Click on - Privacy matters and wait for screen to load"""
            self.assertTrue(self.AboutScreen.tap_element_by_name("Privacy matters"),
                            "Could not click on element- Privacy matters")
            self.assertTrue(self.AboutScreen.wait_for_text_appearance("Privacy matters"),
                            "Could not wait for text to appear-Privacy matters")

            """Verify Privacy- Header UI elements using IR"""
            self.assertTrue(self.AboutScreen.image_compare('Privacy_header', 'Privacy_header', 'xpath'),
                            "Could not get image of 'Privacy- Header UI elements'")

            """Verify the title,body of Privacy screen"""
            self.assertTrue(self.AboutScreen.image_compare('Privacy Policy', 'Privacy Policy', 'xpath'),
                            "Could not compare image of 'title,body of Privacy screen'")
            self.assertTrue(self.AboutScreen.image_compare('Date Year', 'Date Year', 'xpath'),
                            "Could not get compare of 'title,body of Privacy screen'")

            """Tap on 'How Google uses data when you use our partners' sites or apps' and verify UI elements using IR"""
            self.assertTrue(self.AboutScreen.element_selection_by_xpath("How Google uses data"),
                            "Could not tap on -'How Google uses data when you use our partners' sites or apps")
            # wait for URL to load
            self.assertTrue(self.AboutScreen.wait_for_text_appearance("URL", "google", 'value'),
                            "Could not wait for text to appear-google link")
            self.assertTrue(self.AboutScreen.image_compare('Google uses data', 'Google uses data', 'xpath'),
                            "Could not compare image of 'Google uses data- UI elements'")

            """Click on- Back to Coverage Map"""
            self.assertTrue(self.AboutScreen.element_selection_by_precise_tap("Back to Coverage Map"),
                            "Could not tap on -Back to Coverage Map")
            self.assertTrue(self.AboutScreen.wait_for_text_appearance("Privacy"),
                            "Could not wait for text to appear-Privacy title")

            """Tap on 'Network Advertising Initiative website' and verify UI elements using IR"""
            self.assertTrue(self.AboutScreen.element_selection_by_xpath('Network Advertising Initiative website'),
                            "Could not tap on-Network Advertising Initiative website")
            # wait for URL to load
            self.assertTrue(self.AboutScreen.wait_for_text_appearance("URL", "networkadvertising", 'value'),
                            "Could not wait for text to appear-network advertising link")

            self.assertTrue(
                self.AboutScreen.image_compare('Network Advertising Initiative', 'Network Advertising Initiative',
                                               'xpath'),
                "Could not compare image of 'Network Advertising Initiative- UI elements'")
            """Click on- Back to Coverage Map"""
            self.assertTrue(self.AboutScreen.element_selection_by_precise_tap("Back to Coverage Map"),
                            "Could not tap on -Back to Coverage Map")
            self.assertTrue(self.AboutScreen.wait_for_text_appearance("Privacy"),
                            "Could not wait for text to appear-Privacy title")

            """Tap on 'userprivacy@rootmetrics.com'"""
            self.assertTrue(self.AboutScreen.element_selection_by_xpath('userprivacy@rootmetrics.com'),
                            "Could not tap on-userprivacy@rootmetrics.com")
            """Verify Gmail account UI with new mail created addressed to userprivacy@rootmetrics.com"""
            self.assertTrue(self.AboutScreen.verify_element_is_present('New Message', 'name'),
                            "Could not verify presence  of 'New Message UI elements'")
            self.assertTrue(self.AboutScreen.verify_element_is_present('userprivacy@rootmetrics.com', 'name'),
                            "Could not verify presence of 'userprivacy@rootmetrics.com'")
            print "TC064 completed"
        except Exception as e:
            print("Exception= ", e.args)
            print(traceback.format_exc())
            print self.HomeScreen.get_base64_encoded_screen_shot('coveragemap', 'About_Privacy')
            self.fail()

    def tearDown(self):
        """Close the application"""
        self.HomeScreen.quit_application()
