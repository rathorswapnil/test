import traceback
import unittest
import os
from utilities import Utilities
from actioncontrollers.mobile.CoverageMap.Android import HomeScreen
from actioncontrollers.mobile.CoverageMap.Android import AboutScreen
from utilities import adb_handler


class About_DefaultUIElements(unittest.TestCase):
    """Test the About screen with default UI elements | Android TC: 59,60
    | Name: Default UI elements,Rate this app | Test-link id :"""
    HomeScreen = HomeScreen.HomeScreen()
    AboutScreen = AboutScreen.AboutScreen()

    def setUp(self):
        util = Utilities.Utilities()
        global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'MobileConfig'))
        self.assertTrue(adb_handler.clear_app_data(global_config.get('Android_CoverageMap', 'app_package')),
                        "Pre-condition failed: App data could not be cleared")
        """To handle welcome screen of CoverageMap app"""
        self.assertTrue(self.HomeScreen.save_welcomescreen_settings(), "Could not save welcome screen settings")

    def test_About_DefaultUIElements(self):
        """Test the About screen with default UI elements"""
        try:
            """Locate and click on menu button"""
            self.assertTrue(self.HomeScreen.touch_on_menu_button(), "Could not Click on the menu button")

            """Locate and click on About button"""
            self.assertTrue(self.HomeScreen.touch_on_navigation_option("About"), "Could not Click on the About button")

            """Locate and click on verify about screen default screen element"""
            self.assertTrue(self.AboutScreen.verify_about_default_ui_elements(),
                            "Could not verify about screen default elements")

            """Locate and click on Rate this app option"""
            self.assertTrue(self.AboutScreen.select_element_by_name('Rate this app'),
                            "Could not click on Rate this App option")

            """Verify google play store page for Coverage map app"""
            self.assertTrue(self.AboutScreen.verify_google_play_store(),
                            "Unable to verify google play store for coverage map app")

            """Locate and click on device back button """
            self.assertTrue(self.AboutScreen.tap_on_device_back_button(), "Could not click on device back button")

            """Locate and verify About screen title"""
            self.assertTrue(self.AboutScreen.verify_about_screen_title(), "Unable to verify About screen title")

        except Exception as e:
            print("Exception= ", e.args)
            print(traceback.format_exc())
            print self.HomeScreen.get_base64_encoded_screen_shot('coveragemap', 'About_DefaultUIElements')
            self.fail()

    def tearDown(self):
        """Close the application"""
        self.HomeScreen.quit_application()
