import os
import traceback
import unittest

from actioncontrollers.mobile.CoverageMap.Android import HomeScreen
from actioncontrollers.mobile.CoverageMap.Android import ImageSetup
from actioncontrollers.mobile.CoverageMap.Android import SettingsScreen
from utilities import Utilities
from utilities import adb_handler


class Image_Setup(unittest.TestCase):
    """Take application screen-shots by navigating each screen of app """
    HomeScreen = HomeScreen.HomeScreen()
    SetupScreen = ImageSetup.SetupScreen()
    SettingsScreen = SettingsScreen.SettingsScreen()

    def setUp(self):
        util = Utilities.Utilities()
        global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'MobileConfig'))
        self.assertTrue(adb_handler.clear_app_data(global_config.get('Android_CoverageMap', 'app_package')),
                        "Pre-condition failed: App data could not be cleared")
        """To handle welcome screen of CoverageMap app"""
        self.assertTrue(self.HomeScreen.save_welcomescreen_settings(), "Could not save welcome screen settings")

    def test_take_android_app_screen_shots(self):
        """Take android app screen-shots"""
        try:
            print "About Screen Images"
            """Locate and click on menu button"""
            self.assertTrue(self.HomeScreen.touch_on_menu_button(), "Could not Click on the menu button")

            """Locate and Take About screen images """
            self.assertTrue(self.SetupScreen.get_about_screen_screenshots(),
                            "Unable to get 'About Screen' screen-shots")

            """Locate and click on menu button"""
            self.assertTrue(self.HomeScreen.touch_on_menu_button(), "Could not Click on the menu button")

            """To clear the upload data samples"""
            self.assertTrue(self.SettingsScreen.clear_upload_data_samples(), "Unable to clear upload data samples")

            print "Settings Screen Images"
            """Locate and click on menu button"""
            self.assertTrue(self.HomeScreen.touch_on_menu_button(), "Could not Click on the menu button")

            """Locate and Take Setting screen images """
            self.assertTrue(self.SetupScreen.get_setting_screen_screenshots(),
                            "Unable to get 'Setting Screen' screen-shots")

            print "Report Screen Images"
            """Locate and click on menu button"""
            self.HomeScreen.tap_back_button()
            self.assertTrue(self.HomeScreen.touch_on_menu_button(), "Could not Click on the menu button")

            """Locate and Take Report screen images """
            self.assertTrue(self.SetupScreen.get_report_screen_screenshots(),
                            "Unable to get 'Report Screen' screen-shots")


        except Exception as e:
            print("Exception= ", e.args)
            print(traceback.format_exc())
            print self.HomeScreen.get_base64_encoded_screen_shot('coveragemap', 'Image_Setup')
            self.fail()

    def tearDown(self):
        """Close the application"""
        self.HomeScreen.quit_application()
