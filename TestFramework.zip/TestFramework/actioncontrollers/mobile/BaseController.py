# encoding: utf-8
import base64
import os
import time
from time import sleep

import unidecode
from PIL import Image, ImageChops
from appium import webdriver
from appium.webdriver.common.multi_action import MultiAction
from appium.webdriver.common.touch_action import TouchAction
from utilities import Utilities
from utilities import adb_handler


class BaseController(Utilities.Utilities):
    """
    This is the base class for all functions which have interaction with the mobile app / device
    """
    mobile_driver = None
    device_name = None
    replace_pattern = "##data##"
    screen_resolutions = {
        "iphones": [{"iphone4": {"width": 640, "height": 960}}, {"iphone5": {"width": 640, "height": 1136}},
                    {"iphone6": {"width": 750, "height": 1334}}, {"iphone6plus": {"width": 1242, "height": 2208}}],
        "droids": [{"android_hd_ready": {"width": 720, "height": 1280}}, {"android_hd": {"width": 800, "height": 1280}},
                   {"android_full_hd": {"width": 1080, "height": 1920}},
                   {"android_quad_hd": {"width": 1440, "height": 2560}},
                   {"android_2k": {"width": 1536, "height": 2048}}, {"android_4k": {"width": 2560, "height": 1800}}]}

    @property
    def driver(self):
        if BaseController.mobile_driver is None:
            BaseController.mobile_driver = BaseController.set_desired_capabilities(self)
        return BaseController.mobile_driver

    def get_object_repo(self, folder_name, file_name):
        """
        Function to read object repository and get element identifiers based on the execution platform
        :param file_name: file to read
        :return: configparser instance
        """
        try:
            """Read configuration file"""
            return self.read_ini_file(os.path.join(self.get_project_path(), 'objectrepository', folder_name, file_name))
        except Exception as e:
            raise Exception("Unable to read object repository file : ", e)

    def set_desired_capabilities(self):
        """
        Method to set desired capabilities for appium
        :return:driver instance
        """
        try:
            desired_caps = {}
            """Read configuration file"""
            global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'MobileConfig'))
            BaseController.platform_name = global_config.get('Generic', 'platform_name')
            if 'android' == BaseController.platform_name.lower() and 'coveragemap' in global_config.get('Generic',
                                                                                                        'app'):
                desired_caps['platformName'] = global_config.get('Generic', 'platform_name')
                desired_caps['platformVersion'] = global_config.get('Generic', 'platform_version')
                desired_caps['deviceName'] = global_config.get('Generic', 'device_name')
                desired_caps['appPackage'] = global_config.get('Android_CoverageMap', 'app_package')
                desired_caps['appActivity'] = global_config.get('Android_CoverageMap', 'app_activity')
                app_driver = webdriver.Remote(global_config.get('Android_CoverageMap', 'remote_web_driver_url'),
                                              desired_caps)

            elif 'android' == BaseController.platform_name.lower() and 'scoutmaster' in global_config.get('Generic',
                                                                                                          'app'):
                desired_caps['platformName'] = global_config.get('Generic', 'platform_name')
                desired_caps['platformVersion'] = global_config.get('Generic', 'platform_version')
                desired_caps['deviceName'] = global_config.get('Generic', 'device_name')
                desired_caps['appPackage'] = global_config.get('Android_ScoutMaster', 'app_package')
                desired_caps['appActivity'] = global_config.get('Android_ScoutMaster', 'app_activity')
                desired_caps['appWaitActivity'] = global_config.get('Android_ScoutMaster', 'appwaitactivity')
                desired_caps['newCommandTimeout'] = global_config.get('Android_ScoutMaster', 'command_timeout')
                app_driver = webdriver.Remote(global_config.get('Android_ScoutMaster', 'remote_web_driver_url'),
                                              desired_caps)

            elif 'ios' == BaseController.platform_name.lower() and 'coveragemap' in global_config.get('Generic', 'app'):
                desired_caps['platformName'] = global_config.get('Generic', 'platform_name')
                desired_caps['platformVersion'] = global_config.get('Generic', 'platform_version')
                desired_caps['deviceName'] = global_config.get('Generic', 'device_name')
                desired_caps['deviceFormFactor'] = global_config.get('Generic', 'device_form_factor')
                supported=['iphone6plus','iphone6','iphone5']
                if not desired_caps['deviceFormFactor'] in supported:
                    raise Exception('Support not added for {0} device form factor.Please use the supported device form factors.'
                                    'If the device used is iphone5/iphone5s/iphone5 SE, ensure device_form_factor=iphone5 in "MobileConfig.ini"'.format(desired_caps['deviceFormFactor']))
                desired_caps['udid'] = global_config.get('iOS_CoverageMap', 'udid')
                desired_caps['bundleId'] = global_config.get('iOS_CoverageMap', 'bundle_id')
                app_driver = webdriver.Remote(global_config.get('iOS_CoverageMap', 'remote_web_driver_url'),
                                              desired_caps)
            self.device_name = desired_caps['deviceName']

            app_driver.implicitly_wait(5)
            return app_driver
        except Exception as e:
            raise Exception("Exception observed while setting capabilities and starting application on mobile device: ",
                            e)

    def find_element(self, identifier, time_out=8):
        """
        Function to find element based on the given 'element_identifier'
        :param identifier: search element element_identifier
        :return: element
        """
        elements = self.find_elements(identifier, time_out)
        if elements.__len__() == 0:
            raise Exception("Unable to find element: {0} within {1} seconds".format(identifier, time_out))
        else:
            return elements[0]

    def find_elements(self, identifier, time_out=5):
        """
        Function to find multiple elements based on the given 'element_identifier'
        :param identifier: search element element_identifier
        :return: element
        """
        search_type = str(identifier).split('|')[0]
        element_identifier = str(identifier).split('|')[1]
        for i in range(time_out):
            elements = []
            try:
                if search_type == "xpath":
                    elements = self.driver.find_elements_by_xpath(element_identifier)
                elif search_type == "id":
                    elements = self.driver.find_elements_by_id(element_identifier)
                elif search_type == "name":
                    elements = self.driver.find_elements_by_name(element_identifier)
                elif search_type == "accessibility_id":
                    elements = self.driver.find_elements_by_accessibility_id(element_identifier)
                else:
                    raise NotImplemented("Search type {0} not yet implemented".format(search_type))
            except Exception as e:
                print (" Element : {0} : with search_type: {1} : not found within {2} seconds. Retrying...".format(
                    element_identifier, search_type, i))
            if len(elements) > 0:
                return elements
            else:
                continue
        return []

    def tap_on_button(self, identifier, time_out=5):
        """
        Function to tap on button based on the identifier given
        :param identifier: search element identifier
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            element = self.find_element(identifier, time_out)
            element.click()
            return True
        except Exception as e:
            raise Exception("Unable to tap on element error : {0} ".format(e))

    def get_element_text(self, identifier, search_attribute='name'):
        """
        Function to get element text or value
        :param identifier: search element path
        :param search_attribute: search attribute value e.g. 'value' , 'text', 'name'
        :return:element_text
        """
        try:
            element = self.find_element(identifier)
            element_text = element.get_attribute(search_attribute)
            return element_text
        except Exception as e:
            raise Exception(
                "Unable to get text/value of an element using attribute : {0} : error : {1}".format(search_attribute,
                                                                                                    e))

    def get_element_text_by_element(self, element, search_attribute='name'):
        """
        Function to get element text or value
        :param identifier: search element path
        :param search_attribute: search attribute value e.g. 'value' , 'text', 'name'
        :return:element_text
        """
        try:
            element_text = element.get_attribute(search_attribute)
            return element_text
        except Exception as e:
            raise Exception(
                "Unable to get text/value of an element using attribute: {0} : {1}".format(search_attribute, e))

    def enter_text(self, identifier, text_to_enter):
        """
        Function to enter text into text field, text area
        :param identifier: search element identifier
        :param text_to_enter: value to set
        :return:element_text
        """
        try:
            device_type = self.get_device_type()
            if device_type == 'ios':
                ele = self.find_element(identifier)
                ele.send_keys(text_to_enter)
                return ele
            else:
                self.tap_on_button(identifier)
                adb_handler.send_text(text_to_enter)
                return True
        except Exception as e:
            raise Exception("Unable to set text/value to an element error : {0}".format(e))

    def get_base64_encoded_screen_shot(self, folder_name, file_name):
        if not os.path.exists(os.path.join(self.get_project_path(), 'screen_shots', 'mobile')):
            os.makedirs(os.path.join(self.get_project_path(), 'screen_shots', 'mobile'))

        if not os.path.exists(os.path.join(self.get_project_path(), 'screen_shots', 'mobile', folder_name)):
            os.makedirs(os.path.join(self.get_project_path(), 'screen_shots', 'mobile', folder_name))

        abs_file_path = os.path.join(self.get_project_path(), 'screen_shots', 'mobile', folder_name, file_name + '.png')
        self.driver.get_screenshot_as_file(abs_file_path)
        with open(abs_file_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read())
        img_element = 'b64EncodedStart{0}b64EncodedEnd'.format(encoded_string)
        return img_element

    def get_device_screenshot(self, file_name):
        """
        Capture a device screenshot and store it in 'Automation home/screen_shots/[coveragemap/masterlite]/[ios/Android]'
        :param file_name: name of the screenshot file
        :return: absolute file path of the screenshot
        """
        global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'MobileConfig'))
        folder_path = os.path.join(self.get_project_path(), 'screen_shots', 'mobile',
                                   global_config.get('Generic', 'app'),
                                   global_config.get('Generic', 'execution_platform'),
                                   global_config.get('Generic', 'device_form_factor'))
        abs_file_path = os.path.join(self.get_project_path(), 'screen_shots', 'mobile',
                                     global_config.get('Generic', 'app'),
                                     global_config.get('Generic', 'execution_platform'),
                                     global_config.get('Generic', 'device_form_factor'), file_name + '.png')

        # create output directory if it does not exists
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        self.driver.get_screenshot_as_file(abs_file_path)
        return abs_file_path

    def get_ref_image_for_comparision(self, imageName):
        """
        Return the correct reference image for comparision based on the current application ,execution platform and device form factor
        :param imageName: The image to returned
        :return: image
        """
        global_config = self.read_ini_file(
            os.path.join(self.get_project_path(), 'config', 'MobileConfig'))
        abs_file_path = os.path.join(self.get_project_path(), 'screen_shots', 'mobile',
                                     global_config.get('Generic', 'app'),
                                     global_config.get('Generic', 'execution_platform'),
                                     global_config.get('Generic', 'device_form_factor'), imageName + '.png')
        return abs_file_path

    def get_element_image_by_dimensions(self, element_id, screenshot_image):
        """
        Returns cropped image containing the element passed
        :param element_id: The element whose image needs to be retrieved from the screenshot
        :param screenshot_image: screen-shot of the whole device
        :return: image containing only the
        """
        global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'MobileConfig'))
        device_type = global_config.get('Generic', 'platform_name').lower()
        """ Get element size and location"""

        ele = self.find_element(element_id)
        location = ele.location
        size = ele.size
        """Get device dimensions as given by Appium"""
        device_dimension = self.driver.get_window_size()
        """Get device form factor - pixel to CSS pixel mapping """
        device_form_factor = self.get_global_config_value('Generic', 'device_form_factor').lower()
        """Get actual device resolution from pre-defined values. Screenshots will be in this size"""
        if device_type == 'android':
            device_resolution = \
                [x[device_form_factor] for x in self.screen_resolutions['droids'] if x.has_key(device_form_factor)][0]
        else:
            device_resolution = \
                [x[device_form_factor] for x in self.screen_resolutions['iphones'] if x.has_key(device_form_factor)][0]

        """Crop the image based on the form factor"""
        factor = device_resolution.get('width') / device_dimension.get('width')
        start_x = location.get('x') * factor
        start_y = location.get('y') * factor
        end_x = start_x + (size.get('width') * factor)
        end_y = start_y + (size.get('height') * factor)
        cropped_image = screenshot_image.crop((start_x, start_y, end_x, end_y))

        return cropped_image

    def is_element_present(self, identifier):
        """
        Function to check if element is present on screen
        :param identifier: search element path
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            self.find_element(identifier)
            is_element_present = True
        except Exception as e:
            is_element_present = False
        return is_element_present

    def is_element_enabled(self, identifier):
        """
        Function to check if element on the screen is enabled i.e. can be interacted with
        :param identifier: search element path
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            element = self.find_element(identifier)
            element.is_enabled()
            return True
        except Exception as e:
            raise Exception("Element not enabled", e)

    def scroll_to_text(self, text):
        """
        Function to scroll to the given text on the screen
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            self.driver  # ensure that application instance is open
            scroll = '{0}{1}{2}'.format(
                'new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().text("',
                text, '").instance(0));')
            self.driver.find_element_by_android_uiautomator(scroll)
            return True
        except Exception as e:
            raise Exception("Unable to scroll down to find text : {0} : error : {1}".format(text, e))

    # TODO: Possible duplicate function - remove after consulation with team through merge request comments
    def swipe_on_screen(self, direction):
        """
        Function to swipe to on the screen
        :param direction: left / right / up / down
        :return:Boolean (True:For success or False:For failure)
        """
        # ToDo : Need to handle swipe w.r.t. Android
        try:
            if direction == 'left':
                self.driver.swipe(100, 500, 300, 500, 100)
            elif direction == 'right':
                width = self.driver.get_window_size()['width']
                start_x = width - self.calculate_percentage(10, width)
                self.driver.swipe(start_x, 943, 100, 943, 1000)
            elif direction == 'up':
                self.driver.swipe(187, 295, 189, 287, 100)
            elif direction == 'down':
                self.driver.swipe(500, 30, 500, 500, 100)
            else:
                raise NotImplemented("Given direction {0} is not  implemented yet".format(direction))
            return True
        except Exception as e:
            raise Exception("Unable to swipe the screen: {0} {1}".format(direction, e))

    def swipe_to_given_location(self, start_x, start_y, end_x, end_y, duration=1000):
        """
        This function used to swipe on screen from given starting point to given end point
        :param start_x: x co-ordinate of starting point
        :param start_y: y co-ordinate of starting point
        :param end_x: x co-ordinate of end point
        :param end_y: y co-ordinate of end point
        :return:
        """
        try:

            if self.get_device_type() == 'ios':
                self.driver.swipe(start_x, start_y, end_x, end_y,
                                  duration)  # 1000 miliseconds duration over which to perform the swipe action
                return True
            else:
                self.driver.swipe(start_x, start_y, end_x, end_y)
                time.sleep(1)
                # TouchAction(self.driver).tap(None, end_x,end_y, 1).perform()
                return True
        except Exception as e:
            raise Exception("Unable to swipe from given start to end location: ", e)

    def touch_and_hold(self, identifier, x_point=1, y_point=1):
        """
        Function to perform touch and hold action on the screen
        :param identifier: search element path
        :param x_point: x-coordinate
        :param y_point: y-coordinate
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            touch_element = self.find_element(identifier)
            action = TouchAction(self.driver)
            action.long_press(touch_element, x_point, y_point).perform()
            return True
        except Exception as e:
            raise Exception(
                "Unable to long press on location element : {0} : co-ordinates: ({1},{2}) : error : {3}".format(
                    identifier, x_point, y_point, e))

    def zoom_on_screen(self, identifier=None, percentage=200, steps=50):
        """
        Function to perform pinch zoom onto screen on an element
        :param identifier: search element path
        :param percentage: percentage factor to zoom
        :param steps: no.of steps to zoom by
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            if self.get_device_type() == 'ios':
                # Zoom into the center of the screen (NOT the component)
                dimension = self.driver.get_window_size()
                TouchAction(self.driver).tap(None, dimension['width'] / 2, dimension['height'] / 2, 2).perform()
            else:
                self.driver.zoom(element=identifier, percent=percentage, steps=steps)
            return True
        except Exception as e:
            raise Exception(
                "Unable to zoom into map location with {0} percentage in {1} steps {2}".format(percentage, steps, e))

    def pinch_zoom_on_screen(self, identifier, zoom_type):
        '''
        Zoom into or zoom out on element based on zoom type by zoom factor of 10px
        :param identifier: element on which to zoom , if None the whole screen will be considered
        :param zoom_type: in / out
        :return: true
        '''
        try:
            if self.get_device_type() == 'ios':
                ''' If element is not specified calculate the central location based on screen dimensions'''
                if None != identifier:
                    ele = self.find_element('xpath|//UIAMapView[1]/UIAElement[1]')
                    dimension = ele.size
                else:
                    dimension = self.driver.get_window_size()
            else:
                if None != identifier:
                    ele = self.find_element('name|' + identifier)
                    dimension = ele.size
                else:
                    dimension = self.driver.get_window_size()
            x = dimension['width'] / 2
            y = dimension['height'] / 2
            '''Zoom in / out from the central location'''
            if zoom_type == 'in':
                action_1 = TouchAction(self.driver).press(ele, x, y).move_to(ele, x, y - 10)  # swipe out upwards
                action_2 = TouchAction(self.driver).press(ele, x, y).move_to(ele, x, y + 90)  # swipe out downwards
            else:
                action_1 = TouchAction(self.driver).press(ele, x, y).move_to(ele, x, y + 10)  # swipe in downwards
                action_2 = TouchAction(self.driver).press(ele, x, y + 100).move_to(ele, x, y + 90)  # swipe in upwards

            multi_action = MultiAction(self.driver)
            multi_action.add(action_1)
            multi_action.add(action_2)
            multi_action.perform()
            return True
        except Exception as e:
            raise Exception("Unable to zoom in/out to map location with {0} percentage in ".format(e))

    def tap_on_first_search_result(self, search_field):
        """
        Function to search and tab on map location
        :param search_field: search field that has accepted text for searching
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            """Search and tab on given location """
            loc = search_field.location
            loc['y'] += 250
            positions = [(loc['x'], loc['y'])]
            self.driver.tap(positions, 1)
            return True
        except Exception as e:
            raise Exception("Unable to zoom into map location", e)

    def tap_back_button(self):
        """
        Function to tap on the device back button
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            self.driver.back()
            return True
        except Exception as e:
            raise Exception("Unable to click browser back button", e)

    def quit_application(self):
        """
        Function to quit the mobile application
        :rtype: bool
        :return: True:For success or False:For failure
        """
        try:
            global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'MobileConfig'))
            execution_platform = global_config.get('Generic', 'execution_platform').lower()
            platform = global_config.get('Generic', 'platform_name').lower()
            if BaseController.mobile_driver:
                if execution_platform == 'mac' and platform == 'android':
                    adb_handler.kill_app()
                else:
                    self.driver.quit()
            BaseController.mobile_driver = None
        except Exception as e:
            print 'Quiting App app must have been hit earlier'

    def wait_for_text_to_appear(self, identifier, expected_text, attribute='name', time_out=15):
        """
        Function to wait for element to appear. Works on the basis of the text / name of the element
        :return:Boolean (True:For success or False:For failure)
        """
        wait_time = 0
        try:
            while wait_time < time_out - 1:
                element = self.get_element_text(identifier, attribute)
                if expected_text in element:
                    return True
                else:
                    sleep(wait_time)
                wait_time += 1

        except Exception as e:
            raise Exception("Unable to wait for element", e)

    def get_pickerwheel_elements(self, identifier, picker_value):
        """
        Function to select element from pickerwheel
        :param identifier: identifier of pickerhweel
        :param picker_value: element to be selected from pickerwheel
        :return:Boolean (True:For success or False:For failure)
        """
        try:

            ele = self.mobile_driver.find_element_by_xpath(identifier)
            ele.send_keys(picker_value)
            return ele
        except Exception as e:
            raise Exception(
                "Unable to get pickerhweel element : {0} {1}".format(picker_value, e))

    def tap_on_screen(self, x, y):
        try:
            device_type = self.get_device_type()
            if device_type == 'ios':
                TouchAction(self.driver).tap(None, x, y, 1).perform()
            else:
                adb_handler.tapscreen(x, y)
            return True
        except Exception as e:
            raise Exception("Unable to tap on screen : ", e)

    def wait_for_element(self, time_out=5):
        """
        Function to wait for element to appear. Works on the basis of the text / name of the element
        :return:Boolean (True:For success or False:For failure)
        """
        wait_time = 0
        try:
            while wait_time < time_out - 1:
                sleep(wait_time)
                wait_time += 1
        except Exception as e:
            raise Exception("Unable to wait for required element", e)

    def get_device_type(self):
        """
        Function to get device type
        :return:device type
        """
        return self.get_global_config_value('Generic', 'platform_name').lower()

    def get_global_config_value(self, sectionName, paramName):
        '''
        Get the value of the global config parameter from MobileConfig.ini file
        :param paramName: Name of the parameter whose value is to be retrieved
        :param sectionName: Name of the section to be used for retrieving parameter
        :return:
        '''
        try:
            global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'MobileConfig'))
            return global_config.get(sectionName, paramName)
        except Exception as e:
            raise Exception("Unable to retrieve: {0} -> {1}".format(sectionName, paramName), e)

    def convert_using_unidecode(self, element):
        """
        Function to convert using unidecode
        :param element: element to be converted
        :return:device type
        """
        try:
            unicode_element = unidecode.unidecode(element)
            return unicode_element
        except Exception as e:
            raise Exception("Unable to unidecode : ", e)

    def get_checkbox_status(self, identifier, search_attribute='checked'):
        """
        Function to get status of checkbox
        :param identifier: search element path
        :param search_attribute: search attribute value 'checked'
        :return:boolean
        """
        try:
            element = self.find_element(identifier)
            status = element.get_attribute(search_attribute)
            if status != 'true':
                return False
            return True
        except Exception as e:
            raise Exception(
                "Unable to get status of checkbox using attribute : {0} : error : {1}".format(search_attribute, e))

    def wait_for_element_to_appear(self, identifier, time_out=20):
        """
        Function to wait for element to appear. Works on the basis of the text / name of the element
        :return:Boolean (True:For success or False:For failure)
        """
        wait_time = 0
        try:
            while wait_time < time_out - 1:
                ele = self.find_elements(identifier, time_out=1)
                if len(ele) > 0:
                    return True
                wait_time += 1
        except Exception as e:
            raise Exception("Unable to wait for element", e)

    def swipe_pickerwheel_action(self, identifier, direction):
        """
        Function to implement swipe for pickerwheel
        :param identifier: search element path  of pickerwheel
        :param direction: direction of swiping
        :return: Boolean (True:For success or False:For failure)
        """
        try:

            element = self.find_element(identifier)
            location = element.location
            size = element.size

            for key, value in location.items():
                if key == 'y':
                    y1 = value
                else:
                    x1 = value

            for key, value in size.items():
                if key == 'height':
                    s2 = value
                else:
                    s1 = value

            startY = y1 + (s2 / 2)
            startX = x1 + (s1 / 2)
            endX = startX
            endY = startY - 50
            if direction == 'up':
                self.mobile_driver.swipe(start_x=startX, start_y=startY, end_x=endX, end_y=endY, duration=None)
            else:
                self.mobile_driver.swipe(start_x=endX, start_y=endY, end_x=startX, end_y=startY, duration=None)
            return True
        except Exception as e:
            raise Exception("Unable to swipe pickerwheel {0} :", e)

    def swipe_till_element_text(self, identifier, direction, ele_text, swipe_count=5):
        """
        Function to swipe screen till element text found
        :param identifier: Identifier of the element to be matched
        :param direction: Swipe direction (Left/Right/Up/Down)
        :param ele_text: Element text till swipe to be performed
        :param swipe_count: No of swipe needs to be performed on device sceeen
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            i = 0
            for i in range(swipe_count):
                try:
                    ele_val = self.get_element_text(identifier, 'text')
                    if ele_val == ele_text:
                        return True
                except:
                    self.swipe_on_screen(direction)
                    continue
            if i == swipe_count:
                print "Element either not present or not available for swipe"
                return False
        except Exception as e:
            raise "Unable to find element after five swipe" + e.message

    def tap_on_topcenter_of_pickerwheel(self, identifier):
        """
        Function to tap on top of pickerwheel
        :param identifier: search element path of pickerwheel
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            element = self.find_element(identifier)
            location = element.location
            size = element.size

            for key, value in location.items():
                if key == 'y':
                    y1 = value
                else:
                    x1 = value

            for key, value in size.items():
                if key == 'height':
                    s2 = value
                else:
                    s1 = value

            tapX = s1 / 2
            tapY = y1 - 30
            self.mobile_driver.tap([(tapX, tapY)])
            return True
        except Exception as e:
            raise Exception("Unable to tap on top of pickerwheel {0} :", e)

    def AppInBackground(self, time):
        """
        Function to put app in background
        :param time: duration
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            self.driver.background_app(time)
            return True
        except Exception as e:
            raise Exception("Unable to tap on top of pickerwheel {0} :", e)

    def enter_val(self, identifier, keycode_to_enter):
        """
        Function to enter key code into text field, text area
        :param identifier: search element identifier
        :param keycode_to_enter: key code to set
        :return:Boolean (True:For Success, False: For Failure)
        """
        try:
            device_type = self.get_device_type()
            if device_type == 'ios':
                ele = self.mobile_driver.find_element_by_xpath(identifier)
                ele.send_keys(keycode_to_enter.upper())
                return ele
            else:
                self.tap_on_button(identifier)
                adb_handler.send_key(keycode_to_enter.upper())
                return True
        except Exception as e:
            raise Exception("Unable to set text/value to an element error : {0}".format(e))

    def tap_on_device_back_button(self):
        """
        To click the back button of the device
        :return:
        """
        try:
            self.driver.back()
            return True

        except Exception as e:
            raise Exception("Unable to tap on device back button {0} :", e)

    def image_recognition(self, ref_image, element_identified, element_name):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element_identified: the element identified through page screen (by name/xpath)
        :param element: element-image with which comparison is to be done
        :param type(default): Element identifier using 'name' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Open existing image for comparision"""
            ref_image = Image.open(self.get_ref_image_for_comparision(ref_image))

            """Capture new image at runtime for verification"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(element_name + 'Runtime')
            screen_shot = Image.open(abs_file_path)
            runtime_image = self.get_element_image_by_dimensions(element_identified, screen_shot)
            runtime_image.save(abs_file_path)

            if ImageChops.difference(ref_image, runtime_image).getbbox() is None:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to compare image for {0} : {1}".format(ref_image, e))

    def switch_keyboard(self, keyboard):
        """
        Function to switch the keyboard to either google or adb keyboard types
        :param keyboard: Keyboard type (i.e. google or adb)
        :return: Boolean (True: For success or False: For failure)
        """
        try:
            adb_handler.install_and_set_keyboard(keyboard)
        except Exception as e:
            raise Exception("Unable to switch to keyboard", e)

    def set_text_to_clipboard(self, clipboard_text):
        """
        Function to add text to mobile clipboard
        :param clipboard_text: Clipboard text to be copied
        :return: Boolean (True: For success or False: For failure)
        """
        try:
            adb_handler.set_clipboard_text(clipboard_text)
        except Exception as e:
            raise Exception("Unable to set clipboard text", e)

    def enter_utf_characters(self, text):
        """
        Function to enter non-english text using keyboard
        :param text: text to be entered
        :return: Boolean (True: For success or False: For failure)
        """
        try:
            adb_handler.send_unicode_characters_to_keyboard(text)
        except Exception as e:
            raise Exception("Unable to enter data into the keyboard", e)

    def tap_element_by_name(self, element_name):
        """
        Function to tap on element by using name identifier
        :param text: element to be tapped
        :return: Boolean (True: For success or False: For failure)
        """
        try:
            element = self.driver.find_element_by_name(element_name)
            element.click()
            return True
        except Exception as e:
            raise Exception("Unable to tap element by name:{0} :{1}".format(element_name, e))

    def tap_on_device_home_button(self):
        """
        To click the home button of the device and close the app and launch it
        :return:True(For success)
        """
        try:
            self.driver.press_keycode(3)  # To click the home button of the device
            self.driver.close_app()  # To close the current app
            self.driver.launch_app()  # To launch the closed app
            return True
        except Exception as e:
            raise Exception("unable to verify report screen on the home button click", e.message)

    def switch_context(self, view_name="NATIVE_APP"):
        """
        Function to switch the app view
        :param view_name: Name of the view i.e. Web-view or Native
        :return: Boolean (True for success or False for failure)
        """
        try:
            if view_name == "Webview":
                self.driver.switch_to.context('WEBVIEW_com.rootmetrics')
            else:
                self.driver.switch_to.context(view_name)
            return True
        except Exception as e:
            raise Exception("Unable to switch context", e)

    def click_link(self, link_name):
        """
        Function to click on link by link name
        :param link_name: Name of the link to be clicked
        :return: Boolean (True for Success or False for Failure)
        """
        try:
            self.driver.find_element_by_partial_link_text(link_name).click()
            return True
        except Exception as e:
            raise Exception("Unable to click on the link {0} : {1}".format(link_name, e))

    def calculate_percentage(self, percent, number):
        """
        Function to calculate the percentage
        :param percent: Percentage value to be calculated
        :param number: Number for which percentage to be calculated
        :return: percentage value
        """
        try:
            return (percent * number) / 100.0
        except Exception as e:
            raise Exception("Unable to calculate percentage of given number {0} {1}".format(number, e))

    def click_keyboard_done(self):
        """
        Function to click on SIP keyboard done button
        :return: Boolean (True for Success or False for Failure)
        """
        try:
            """Get device dimensions as given by Appium"""
            device_dimension = self.driver.get_window_size()
            """Get the dimensions and click on SIP keyboard done button"""
            self.tap_on_screen(device_dimension['width'] - self.calculate_percentage(7, device_dimension['width']),
                               (
                               device_dimension['height'] - self.calculate_percentage(3.5, device_dimension['height'])))
            return True
        except Exception as e:
            raise ("Unable to click on device SIP keyboard done button", e)