from actioncontrollers.mobile import BaseController
import time

class HomeScreen(BaseController.BaseController):
    filename = "HomeScreen"
    folder_name = "CoverageMap/iOS"
    menu_screen_title = "RootMetrics CoverageMap"

    def __init__(self):
        """ Get object repository for the current Screen controller"""
        self.elements = self.get_object_repo(self.folder_name, self.filename)
        self.device_type = BaseController.BaseController.get_device_type(self)

    def touch_on_menu_button(self):
        """
        Function to touch Menu button from Home Screen
        :return: Boolean (True: For success or False: For failure)
        """
        try:
            self.tap_on_button(self.elements.get('HomeScreen', 'menu_tap'))
            return True
        except Exception as e:
            raise Exception("Unable to click on Menu button:{0}".format(e.message))

    def touch_on_navigation_option(self, option):
        """
       Function to touch on one of the home screen and navigation buttons on screen
       :param option: option or button to be selected
       :return: Boolean (True:For success or False:For failure)
       """
        navigation_options = {
            'Search': 'Search',
            'Settings button': 'Map filters',
            'Hex': 'Map multi hex',
            'Map': 'Map',
            'Test': 'Test',
            'Report': 'Report',
            'Support': 'Support',
            'Usage': 'Usage',
            'Settings': 'Settings',
            'About': 'About'
        }
        try:
            """ Locate and click the navigation options from the menu list displayed """
            self.tap_on_button(
                self.elements.get('HomeScreen', 'variable_text').replace(self.replace_pattern, navigation_options[option]))
            return True
        except Exception as e:
            raise Exception("Unable to click on {0} button :".format(navigation_options[option]), e)

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == 'xpath':
                flag = self.is_element_present(
                    self.elements.get('HomeScreen', 'variable_xpath').replace(self.replace_pattern, identifier))
            else:
                flag = self.is_element_present(
                    self.elements.get('HomeScreen', 'variable_text').replace(self.replace_pattern, identifier))

            if flag is False:
                return False
            else:
                return True
        except Exception as e:
            raise Exception("Unable to verify presence of text for {0} : {1}", identifier)

    def element_selection_by_precise_tap(self, element):
        """
        Function to select element by name identifier by which location co-ordinates and click by precise tap using those
        :param link_element:  name of element to be selected
        :return: Boolean (True:For success or False:For failure
        """
        try:
            ele = self.find_element(
                self.elements.get('HomeScreen', 'variable_text').replace(self.replace_pattern,
                                                                          element))
            location = ele.location
            x1 = y1 = 0
            for key, value in location.items():
                if key == 'y':
                    y1 = value
                else:
                    x1 = value
            y1 = y1 + 10
            x1 = x1 + 10
            self.mobile_driver.tap([(x1, y1)], 1)
            return True
        except Exception as e:
            raise Exception("Unable to get select element by and click by precise tap for {0} : {1}", element)

    def welcome_screen_navigation(self):
        """
        Function to navigate through welcome screen
        :return: Boolean (True:For success or False:For failure
        """
        try:
            """Locate and click on menu button"""
            self.tap_element_by_name('accept')
            self.tap_element_by_name('Skip')
            self.tap_element_by_name('continue')

            if (self.verify_element_is_present('Allow', 'name')):
                self.tap_element_by_name('Allow')
            if (self.verify_element_is_present('Cancel', 'name')):
                self.tap_element_by_name('Cancel')
            return True
        except Exception as e:
            raise Exception("Unable to get naviagate through welcome screen (clean install) {0} : ",e)

