import time
from PIL import Image
from actioncontrollers.mobile import BaseController

class SettingsScreen(BaseController.BaseController):
    filename = "SettingsScreen"
    folder_name = "CoverageMap/iOS"
    images = {
        'Settings_header': 'Header_IR',
        'enableBDE_yellow':'enableBDE_switch',
        'send_data_using_paragraph':'send_data_using_paragraph',
        'Background_textview':'Background_textview_IR'
    }

    def __init__(self):
        """Get object repository for the current repo"""
        self.elements = self.get_object_repo(self.folder_name,self.filename)

    def get_screen_title(self, screen_name):
        """
        Function to get the Screen title for the given screen_name
        :param screen_name:
        :return: screen_title_text
        """
        try:
            """Locate and verify settings screen title"""
            screen_title_text = self.get_element_text(self.elements.get('SettingsScreen', 'settings_screen_title'))
            return screen_title_text
        except Exception as e:
            raise Exception("Unable to verify screen title for {0} : {1}".format(screen_name, e))

    def ImageSetup(self, image_name, element_identifier=None, type='name'):
        """
        Function to create setup image using IR at before runtime execution
        :param element: element-image by which it will be stored during runtime execution
        :param element_identifier: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('SettingsScreen', 'variable_text').replace(self.replace_pattern,
                                                                              element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('SettingsScreen', self.images[element_identifier]), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} :{1} ".format(image_name,e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == "name":
                self.image_recognition(ref_image,
                                       self.elements.get('SettingsScreen', 'variable_text').replace(self.replace_pattern,
                                                                                             element), element)
            else:
                self.image_recognition(ref_image, self.elements.get('SettingsScreen', self.images[element]), element)
            return True
        except Exception as e:
            raise Exception("Unable to compare image for {0} :{1} ".format(ref_image,e))

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == 'xpath':
                flag = self.is_element_present(
                    self.elements.get('SettingsScreen', 'variable_xpath').replace(self.replace_pattern, identifier))
            else:
                flag = self.is_element_present(
                    self.elements.get('SettingsScreen', 'variable_text').replace(self.replace_pattern, identifier))

            return flag
        except Exception as e:
            raise Exception("Unable to verify absence of text for {0} : {1}".format(identifier,e))

    def verify_text_on_screen(self, identifier, expected_text):
        """
        Function to get text on currently displayed screen
        :param: identifer: item whose value w.r.t. which expected text is to be checked
        :param: expected_text: expected text on screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            text_fetched = self.get_element_text(self.elements.get('SettingsScreen', 'variable_text').replace(self.replace_pattern, identifier), 'value')

            if expected_text == text_fetched:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to get required text for {0} : {1}".format(expected_text, e))

    def verify_UI_before_and_after_cancel_on_dialog(self):
        """
        Function to get verify UI and text before and after cancel on dialog in baseline data screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            self.image_compare('Background collection', 'Background collection')
            self.tap_element_by_name("Cancel")
            self.image_compare('enableBDE_yellow', 'enableBDE_yellow', 'xpath')
            list={'Baseline data experience','locationSettings','Background collection is enabled but inactive. Go to Location settings and allow access: Always'}
            for key in list:
                self.verify_element_is_present(key, 'name')
            return True
        except Exception as e:
            raise Exception("Unable to verify UI after cancel on dialog {0}: ".format(e))


    def element_selection_by_precise_tap(self, element):
        """
        Function to select element by name identifier by fetching location co-ordinates and click by precise tap using those co-ordinates
        :param element:  name of element to be selected
        :return: Boolean (True:For success or False:For failure
        """
        try:
            ele = self.find_element(
                self.elements.get('SettingsScreen', 'variable_text').replace(self.replace_pattern,
                                                                          element))
            dict = ele.location
            y = dict['y']
            x = dict['x']
            y = y + 10
            x = x + 10
            self.mobile_driver.tap([(x, y)], 1)
            return True
        except Exception as e:
            raise Exception("Unable to get select element and click by precise tap for {0} : {1}" .format(element,e))