import configparser
import time
from PIL import Image
from actioncontrollers.mobile import BaseController

class AboutScreen(BaseController.BaseController):
    parser = configparser.ConfigParser()
    filename = "AboutScreen"
    folder_name = "CoverageMap/iOS"
    images = {
        'Terms_header': 'Header_IR',
        'Privacy_header':'Header_IR',
        'About_header':'Header_IR',
        'Open_source_licenses_header':'Header_IR',
        'Rootmetrics Privacy Policy': 'URL',
        'Terms of Service':'URL',
        'Legal Notices': 'URL',
        'Terms of Use':'URL',
        'Apache':'URL',
        'Terms and Conditions':'text_IR',
        'Date Year':'Date_Year_IR',
        'Privacy Policy':'text_IR',
        'Google uses data':'URL',
        'Network Advertising Initiative':'URL',
        'charts_text':'charts_text_IR',
        'offline_terms':'offline',
        'offline_privacy':'offline',
        'whatsnew_title':'whatsnew_title_IR',
        'whatsnew_UI':'whatsnew_UI_IR',
        'First_set_images_whatsnew':'whatsnew_UI_IR',
        'Last_page_whatsnew_UI':'whatsnew_UI_IR'
    }

    def __init__(self):
        """
        Constructor to get parser from Base controller class
        :return: parser object
        """
        self.elements = self.get_object_repo(self.folder_name,self.filename)
        self.device_type = BaseController.BaseController.get_device_type(self)

    def ImageSetup(self, image_name, element_identifier=None, type='name'):
        """
        Function to create setup image using IR at before runtime execution
        :param element: element-image by which it will be stored during runtime execution
        :param element_identifier: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern,
                                                                               element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('AboutScreen', self.images[element_identifier]), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} :{1} " .format(image_name,e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == "name":
                self.image_recognition(ref_image,
                                   self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern, element), element)
            else:
                self.image_recognition(ref_image, self.elements.get('AboutScreen', self.images[element]), element)
            return True
        except Exception as e:
            raise Exception("Unable to compare image for {0} :{1} " .format(ref_image,e))

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :param type(default): Element identifier using 'name' or 'xpath'
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == 'xpath':
                flag = self.is_element_present(
                    self.elements.get('AboutScreen', 'variable_xpath').replace(self.replace_pattern, identifier))
            else:
                flag = self.is_element_present(
                    self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern, identifier))
            return flag
        except Exception as e:
            raise Exception("Unable to verify presence of text for {0} : {1}".format(identifier,e))

    def verify_element_is_absent(self, identifier):
        """
        Function to verify whether element is absent on screen
        :param identifier: the element whose absence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            flag = self.is_element_present(
                self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern, identifier))
            if flag is False:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify absence of text for {0} : {1}".format(identifier, e))

    def element_selection_by_xpath(self, element):
        """
        Function to select element by xpath identifier
        :param element:  name of link or data to be selected
        :return: Boolean (True:For success or False:For failure
        """
        try:
            self.tap_on_button(self.elements.get('AboutScreen', 'variable_xpath').replace(self.replace_pattern,element))
            return True
        except Exception as e:
            raise Exception("Unable to get required element by name for {0} : {1}" .format(element,e))

    def element_selection_by_precise_tap(self, element):
        """
        Function to select element by name identifier by fetching location co-ordinates and click by precise tap using those co-ordinates
        :param element:  name of element to be selected
        :return: Boolean (True:For success or False:For failure
        """
        try:
            ele = self.find_element(
                self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern,
                                                                             element))
            dict=ele.location
            y=dict['y']
            x=dict['x']
            y = y + 10
            x = x + 10
            self.mobile_driver.tap([(x, y)], 1)
            return True
        except Exception as e:
            raise Exception("Unable to get select element and click by precise tap for {0} : {1}".format(element,e))

    def wait_for_text_appearance(self, identifier, expected_text=None, type='name'):
        """
        Function to wait for element to appear. Works on the basis of the text / name /value of the element
        :param identifier: the identifier of the element to wait for
        :param expected_text: expected text (if any) for which waiting to appear on screen
        :return:Boolean (True:For success or False:For failure)
        """
        mapping = {}
        try:
            if type == 'name':
                self.wait_for_element_to_appear(self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern,
                                                                                       identifier))
            else:
                self.wait_for_text_to_appear(
                    self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern,
                                                                                       identifier),
                    expected_text,'value')
            return True
        except Exception as e:
            raise Exception("Unable to wait for element{0} :{1}".format(identifier,e))



