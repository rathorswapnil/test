import configparser
import time
import math, operator
from PIL import Image, ImageChops
from actioncontrollers.mobile import BaseController

class MapScreen(BaseController.BaseController):
    parser = configparser.ConfigParser()
    filename = "MapScreen"
    folder_name = "CoverageMap/iOS"
    images = {
        'searchbox_cancel': 'searchbox_cancel_IR',
        'Network carousel': 'Network_carousel_IR',
        'Layer carousel': 'Layer_carousel_IR',
        'Style carousel': 'Style_carousel_IR',
        'multihex':'multihex_button',
        'toolbar_icon':'toolbar_icon_xpath'
    }

    def __init__(self):
        """
        Constructor to get parser from Base controller class
        :return: parser object
        """
        self.elements = self.get_object_repo(self.folder_name, self.filename)
        self.device_type = BaseController.BaseController.get_device_type(self)

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :return: flag status (True:For success or False:For failure)
        """
        mapping = {'keyboard': 'keyboard_IR',
                   'first_search_item': 'first_table_cell',
                   'carrier_header': 'carrier_header',
                   'multihex': 'multihex_button',
                   'Verizon_only':'Verizon_only_xpath'}
        try:
            if type == 'xpath':
                flag = self.is_element_present(
                    self.elements.get('MapScreen', mapping[identifier]))
            else:
                flag = self.is_element_present(
                    self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern, identifier))
            return flag
        except Exception as e:
            raise Exception("Unable to verify presence of text for {0} : {1}".format(identifier, e))

    def verify_element_is_absent(self, identifier, type='xpath'):
        """
        Function to verify whether element is absent on screen
        :param identifier: the element whose absence is to be checked
        :return: flag status (True:For success or False:For failure)
        """
        self.mapping = {'no_maphistory': 'first_table_cell',
                        'keyboard': 'keyboard_IR',
                        'multihex': 'multihex_button'}
        try:
            if type == 'name':
                flag = self.is_element_present(
                    self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern, identifier))
            else:
                flag = self.is_element_present(self.elements.get('MapScreen', self.mapping[identifier]))
            if flag is False:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify absence of text for {0} : {1}".format(identifier, e))

    def ImageSetup(self, image_name, element_identifier=None, type='name'):
        """
        Function to create setup image using IR at before runtime execution
        :param element: element-image by which it will be stored during runtime execution
        :param element_identifier: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success else return failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern,
                                                                            element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('MapScreen', self.images[element_identifier]), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} :{1} ".format(image_name, e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success else return failure)
        """
        try:
            if type == "name":
                self.image_recognition(ref_image,
                                       self.elements.get('MapScreen', 'variable_text').replace(
                                           self.replace_pattern,
                                           element), element)
            else:
                self.image_recognition(ref_image, self.elements.get('MapScreen', self.images[element]),
                                       element)
            return True
        except Exception as e:
            raise Exception("Unable to compare image for {0} :{1} ".format(ref_image, e))

    def enter_text_in_searchbox(self, data):
        """
        Function to enter text on search box
        :param data: text to be entered
        :return: Boolean (True:For success else return failure)
        """
        try:
            self.tap_element_by_name('Search')
            self.enter_text(self.elements.get('MapScreen', 'text_area'), data)
            self.verify_element_is_present('first_search_item', 'xpath')
            return True
        except Exception as e:
            raise Exception(
                "Unable to enter text in search box and wait for results to populate{0} :{1}".format(data, e))

    def fetch_location_of_element_on_screen(self, identifier, type='name'):
        """
        Function to fetch location of element on screen
        :param identifier: identifier whose location is to be fetched
        :param type: default value is fetched-  by 'name'
        :return: location else return failure)
        """
        mapping = {'Tap on hex message': 'stats_msg_xpath'}
        try:
            if type == 'xpath':
                ele = self.find_element(self.elements.get('MapScreen', mapping[identifier]))
            else:
                ele = self.find_element(
                    self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern,
                                                                            identifier))
            location = ele.location
            return location
        except Exception as e:
            raise Exception("Unable to fetch location for element on screen for {0} : {1}".format(identifier, e))

    def fetch_size_of_element_on_screen(self, identifier, type='name'):
        """
        Function to fetch size of element on screen
        :param identifier: identifier whose size is to be fetched
        :param type: default value is fetched-  by 'name'
        :return: Boolean (True:For success or False:For failure)
        """
        mapping = {'CoverageMap_Application': 'CoverageMap_Application_identifier'}
        try:
            if type == 'xpath':
                ele = self.find_element(self.elements.get('MapScreen', mapping[identifier]))
            else:
                ele = self.find_element(
                    self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern,
                                                                            identifier))
            size = ele.size
            return size
        except Exception as e:
            raise Exception("Unable to fetch size for element on screen for {0} : {1}".format(identifier, e))

    def legends_layer_verification(self, layer, device_factor):
        """
        Function to verify legend contents of map layer from screen
        :param layer: map layer whose legends are to be verified which will also be the reference image name for image comparison
        :param device_factor: device factor for devices
        :return: Boolean (True:For success or False:For failure)
        """
        try:
                """Open existing image for comparison"""
                ref_image = Image.open(self.get_ref_image_for_comparision(layer))
                """Capture new image at runtime for verification"""
                fetch_location = self.find_element(
                    self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern, 'Good'))
                dict = fetch_location.location
                x = dict['x']
                y = dict['y']
                startx = (x - 40) * device_factor
                starty = y * device_factor
                endx = (x + 70) * device_factor
                endy = (y + 130) * device_factor

                abs_file_path = self.get_device_screenshot(layer+'Runtime')
                screen_shot = Image.open(abs_file_path)
                runtime_image = screen_shot.crop((startx, starty, endx, endy))
                runtime_image.save(abs_file_path)
                if ImageChops.difference(ref_image, runtime_image).getbbox() is None:
                    return True
                else:
                    diff_image = ImageChops.difference(ref_image, runtime_image)
                    diff_image.show()
                    return False
        except Exception as e:
            raise Exception("Unable to compare legends image using IR for layer {0} : {1}".format(layer, e))

    def element_selection_by_xpath(self, element):
        """
        Function to select element by xpath identifier
        :param element:  name of link or data to be selected
        :return: Boolean (True:For success else return failure)
        """
        mapping = {'Call performance': 'Call_performance',
                   'Fastest speed found': 'Fastest_speed_found',
                   'Best technology found': 'Best_technology_found',
                   'Verizon': 'Verizon',
                   'Map': 'Map',
                   'Speed': 'speed_carousel_xpath',
                   'Satellite': 'satellite_xpath',
                   'multihex':'multihex_button'}
        try:
            self.tap_on_button(self.elements.get('MapScreen', mapping[element]))
            return True
        except Exception as e:
            raise Exception("Unable to get required element by name for {0} : {1}".format(element, e))

    def perform_map_settings(self, layer, style, network=None):
        """
        Function to do settings for map
        :param layer: the map layer to be selected
        :param style: the map style to be selected
        :param network: the network type to be selected (None by default)
        :return:Boolean (True:For success else return failure)
        """
        try:
            self.tap_element_by_name('mapSettings')
            self.element_selection_by_xpath(layer)
            self.element_selection_by_xpath(style)
            if network!= None:
                self.element_selection_by_xpath(network)
            return True
        except Exception as e:
            raise Exception(
                "Unable to do settings for map for layer {0} network {1} style {2}: Error {3}".format(layer, network,
                                                                                                      style, e))

    def verify_search_history(self, current_location, previous_location):
        """
        Funtion to verify currently selected search query displayed with search history
        and it's on the Top of history search results
        :param current_location: Current location to search
        :param previous_location: Previous location to search
        :return: Boolean (True:For success or False: For failure)
        """
        try:
            search_results = []
            # Click on search button to search location
            self.tap_element_by_name('Search')

            # Get list of all populated search history and add it in the list
            for i in range(1, 3):
                text = self.get_element_text(
                    self.elements.get('MapScreen', 'history_table_cell').replace(self.replace_pattern,
                                                                                 '{0}'.format(i)))
                search_results.append(text)

            # Verify that history results contains current and previously searched locations
            if (current_location and previous_location) not in search_results:
                raise Exception("Search history not populated with all results")

            # Get currently searched location name
            text = self.get_element_text(
                self.elements.get('MapScreen', 'history_table_cell').replace(self.replace_pattern, '1'))

            # Verify that currently searched location is at the top in the search result table
            if text != current_location:
                raise Exception("Current location and Top history search results not matches")

            return True
        except Exception as e:
            raise Exception("Unable to verify search history with current {0} and previous {1} locations : {2}".format(
                current_location, previous_location, e))

    def close_the_drawer(self):
        """
        Function to close the drawer
        :return:Boolean (True:For success else return failure)
        """
        try:
            location_dict = self.fetch_location_of_element_on_screen('DragUp')
            y = location_dict['y']
            x = location_dict['x']
            self.swipe_to_given_location(x, y, x, y + 30)
            return True
        except Exception as e:
            raise Exception("Unable to close the drawer {0}".format(e))

    def get_header_text(self):
        """
        The function is used to get the carrier header text
        :return: header text
        """
        try:
            header_text = self.get_element_text_by_element(
                self.find_elements(self.elements.get('MapScreen', 'carrier_header'))[0])
            return header_text
        except Exception as e:
            raise Exception("Unable to get the header text", e.message)

    def verify_call_performance_map_stats_elements(self):
        """
        The function is used to verify call performance map stats elements
        :return: True(for success)
        """
        try:
            dbm_text = self.get_element_text_by_element(
                self.find_elements(self.elements.get('MapScreen', 'stats_msg_xpath'))[0])
            if not dbm_text.__contains__('dBm'):
                raise Exception("call performance map stats does not contain dbm")
            datapoints_text = self.get_element_text_by_element(
                self.find_elements(self.elements.get('MapScreen', 'data_points'))[0])
            if datapoints_text == 'No data points':
                raise Exception("Colored hex not selected,hence network type not available")
            else: #data points and count are loaded
                if not datapoints_text.__contains__('data point'):
                    raise Exception("call performance map stats does not contain 'data points' text")
                if not int(datapoints_text.split(' ')[0]): #check if int value present
                    raise Exception("Call performance- map stats does not contain 'data point' text")

            return True
        except Exception as e:
            raise Exception("Unable to verify call performance map stats elements", e.message)

    def verify_best_technology_map_stats_elements(self):
        """
        The function is used to verify best technology map stats elements
        :return: True(for success) else raise exception
        """
        try:
            datapoints_text = self.get_element_text_by_element(
                self.find_elements(self.elements.get('MapScreen', 'data_points'))[0])
            if datapoints_text == 'No data points':
                raise Exception("Colored hex not selected,hence network type also not available")
            else:#data points and stats are loaded
                if not datapoints_text.__contains__('data point'):
                    raise Exception("Best tech found map stats does not contain 'data point' text")
                if not int(datapoints_text.split(' ')[0]):#check if int value present
                    raise Exception("Best tech found --map stats does not contain 'data point' text")

                network_text = self.get_element_text_by_element(
                    self.find_elements(self.elements.get('MapScreen', 'stats_msg_xpath'))[0])
                network_list = ["LTE", "2G/3G", "2G"]
                for network in network_list:
                    if network_text.__contains__(network):
                        return True
        except Exception as e:
            raise Exception("Unable to verify best technology map stats elements", e.message)

    def verify_fastest_speed_found_map_stats_elements_hex_selection(self):
        """
        The function is used to verify fastest speed fopund- map stats elements
        :return: True(for success) else raise exception
        """
        try:

            """Tap on any colored hex"""
            # tap on screen for hex selection.
            # if data points hold value "no data points" shift x,y co-ordinates to tap on adjoining colored hex if any
            # continue for 10 trials to get hex data of color (no white hex)
            count = 0
            x = 200
            y = 300
            self.mobile_driver.tap([(x, y)])
            data_points = self.fetch_text_from_screen('data_points_fastest')
            while data_points=='' and count <= 10: #while data points not available and count<10 keep tapping other hexes
                if count > 5:
                    if count==6 :
                        x = 100
                        y = 100
                    x = x + 20
                    y = y + 20
                else:
                    x = x - 10
                    y = y - 10
                self.mobile_driver.tap([(x, y)])
                data_points = self.fetch_text_from_screen('data_points_fastest')
                count += 1
            """Verify quickview open"""
            data = self.fetch_text_from_screen('data_points_fastest')
            if not 'data point' in data:
                raise Exception('Quickview not opened')
            """Verify stats"""
            if self.get_count_of_elements('Mbps')!=2:
                raise Exception('Upload speed and download speed is not displayed with Mbps')
            #verify upload speed is not blank
            Upload_speed_mapscreen_fastestspeed = self.fetch_text_from_screen('Upload speed')
            if Upload_speed_mapscreen_fastestspeed== '':
                raise Exception('Upload speed is not displayed with numerics')
            # verify download speed is not blank
            Download_speed_mapscreen_fastestspeed = self.fetch_text_from_screen('Tap on hex message')
            if Download_speed_mapscreen_fastestspeed == '':
                raise Exception('Download speed is not displayed with numerics')
            # verify text-'data points' is present with stats
            datapoints_text = self.fetch_text_from_screen('data_points_fastest')
            if datapoints_text=='No data points':
                raise Exception("Colored hex not selected,hence network type not available")
            else:#stats loaded
                if not datapoints_text.__contains__('data point'): #verify 'data point' test present
                    raise Exception("Fastest speed found map stats does not contain 'data points' text")
                #verify network type only if fetched download upload speed values !=0
                if Download_speed_mapscreen_fastestspeed  and Upload_speed_mapscreen_fastestspeed != 0:
                    network_type_download = self.fetch_text_from_screen('network_type_download')
                    network_type_upload = self.fetch_text_from_screen('network_type_upload')
                    network_list = ["LTE", "2G/3G", "2G"]
                    for network in network_list:
                        if network_type_upload.__contains__(network) and network_type_download.__contains__(network):
                            return True
                if Upload_speed_mapscreen_fastestspeed ==0 : #if upload speed=0 then no network type
                    print "Speed is 0 mbps , hence no network type detected for upload"
                if Download_speed_mapscreen_fastestspeed == 0:#if download speed=0 then no network type
                    print "Speed is 0 mbps , hence no network type detected for download"
                return True
        except Exception as e:
            raise Exception("Unable to verify fastest speed found map stats elements", e.message)

    def verify_drawer_closed(self):
        """
       Function to verify if the drawer is closed
       :return:Boolean (True:For success else return failure)
        """
        try:
            location_dict = self.fetch_size_of_element_on_screen('CoverageMap_Application', 'xpath')
            height = location_dict['height']
            location_dict = self.fetch_location_of_element_on_screen('Please zoom in.')
            y = location_dict['y']
            if height == y or height-y <=2: #iphone5 has difference of height 2 between CM and 'Please zoom in.' message
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify is drawer is closed {0}".format(e))

    def verify_drawer_opened(self,view_type):
        """
        Function to verify if the drawer is open
        :return:Boolean (True:For success else return failure)
        """
        try:
            location_dict = self.fetch_size_of_element_on_screen('CoverageMap_Application', 'xpath')
            height = location_dict['height']
            location_dict = self.fetch_location_of_element_on_screen('Please zoom in.')
            y = location_dict['y']

            if view_type=='quickview':
                if height != y and height - y < 150:
                    # difference between 'Please zoom in.' is within permissible limits i.e. to cross-check its not in full view
                    return True
                else:
                    return False
            else:
                if height != y and height - y > 150:
                    # cross-check its in full view and not quick view
                    return True
                else:
                    return False
        except Exception as e:
            raise Exception("Unable to verify is drawer is opened {0}".format(e))


    def fetch_text_from_screen(self, identifier):
        """
        Function to fetch text from screen
        :param identifier: identifier from where text is to be fetched
        :return: Boolean (True:For success or False:For failure)
        """
        mapping = {'Tap on hex message': 'stats_msg_xpath',
                   'data points': 'data_points',
                   'Verizon_only':'Verizon_only_xpath',
                   'Upload speed':'Upload_speed_mapscreen_fastestspeed',
                   'data_points_fastest':'data_points_fastest_xpath',
                   'layer_network':'layer_network_xpath',
                   'network_type_download':'network_type_download_xpath',
                   'network_type_upload':'network_type_upload_xpath'}
        try:
            text = self.get_element_text(self.elements.get('MapScreen', mapping[identifier]), 'value')
            return text
        except Exception as e:
            raise Exception("Unable to fetch data from screen for {0} :{1} ".format(identifier, e))

    def zoom_for_hex_selection(self):
        """
        Function to zoom the map untill screen is correct zoom level for hex selection
        :return: Boolean (True:For success or Exception:For failure)
        """
        try:
            ele = self.fetch_text_from_screen('Tap on hex message')
            ele = self.convert_using_unidecode(ele)
            ele1 = 'Tap on a hex to see details of that area\'s call performance, data speed, and best technology found.'.encode(
                'ascii', 'ignore')
            while ele != ele1:
                self.zoom_on_screen()
                ele = self.fetch_text_from_screen('Tap on hex message')
                ele = self.convert_using_unidecode(ele)  # convert to unicode to handle special characters
            return True
        except Exception as e:
            raise Exception("Unable to zoom untill hexes selection available on screen for {0} : ".format(e))

    def tap_colored_hex(self):
        """
        Function to tap on colored hex for maximum of 10 trials
        :return: Boolean (True:For success or Exception:For failure)
        """
        try:
            # tap on screen for hex selection.
            # if data points hold value "no data points" shift x,y co-ordinates to tap on adjoining colored hex if any
            # continue for 10 trials (5 trials within lower area and rest 5 trials in upper area) to get hex data of color (no blank hex or white hex)
            count = 0
            x = 200
            y = 300
            self.mobile_driver.tap([(x, y)])
            data_points = self.fetch_text_from_screen('data points')
            while 'No data points' in data_points and count <= 10:
                if count > 5:
                    x = 100
                    y = 100
                    x = x + 20
                    y = y + 20
                else:
                    x = x - 10
                    y = y - 10
                self.mobile_driver.tap([(x, y)])
                data_points = self.fetch_text_from_screen('data points')
                count += 1
            return True
        except Exception as e:
            raise Exception("Unable to tap on colored hex {0} : ".format(e))

    def verify_quickview_taphex_message(self):
        """
        Function to verify quickview displayed by checking 'Tap on hex' message
        :return: Boolean (True:For success or Exception:For failure)
        """
        try:
            ele = self.fetch_text_from_screen('Tap on hex message')
            ele = self.convert_using_unidecode(ele)
            ele1 = 'Tap on a hex to see details of that area\'s call performance, data speed, and best technology found.'.encode(
                'ascii', 'ignore')
            if ele != ele1:
                raise Exception('Tap on a hex to see details... - Message not dispalyed on screen')

            # following code is to check - drawer open in quick view when 'Tap on a hex ' message displayed
            # fetch location of message and compare it with application window's height
            location_dict = self.fetch_location_of_element_on_screen('Tap on hex message', 'xpath')
            y = location_dict['y']
            location_dict = self.fetch_size_of_element_on_screen('CoverageMap_Application', 'xpath')
            height = location_dict['height']

            if height != y and height - y < 150:  # if conditions checks- drawer not closed and not in full view
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Drawer not opened in quick view {0} : ".format(e))

    def verify_quickview_after_hex_selection(self):
        """
        Function to verify quickview displayed after hex selection
        :return: Boolean (True:For success or Exception:For failure)
        """
        try:
            data = self.fetch_text_from_screen('data points')
            if not 'data point' in data:
                raise Exception('Quickview not opened')
            return True
        except Exception as e:
            raise Exception("Drawer not opened in quick view after hex selection {0} : ".format(e))


    def verify_drawer_closed_tap_on_hex_message(self):
        """
        Function to verify drawer is closed with 'Tap on hex' message
        :return: Boolean (True:For success or Exception:For failure)
        """
        try:
            fetch_text = self.fetch_text_from_screen('Tap on hex message')
            fetch_text = self.convert_using_unidecode(fetch_text)
            message = 'Tap on a hex to see details of that area\'s call performance, data speed, and best technology found.'.encode(
                'ascii', 'ignore')
            if fetch_text != message:
                raise Exception('Tap on a hex to see details... - Message not displayed on screen')

            # following code is to check - drawer closed when 'Tap on a hex ' message displayed
            # fetch location of message and compare it with application window's height
            location_dict = self.fetch_location_of_element_on_screen('Tap on hex message', 'xpath')
            y = location_dict['y']
            location_dict = self.fetch_size_of_element_on_screen('CoverageMap_Application', 'xpath')
            height = location_dict['height']

            if height == y or height-y <=2 : #iphone5 devices has differenc of 2 between height of CM app and 'tap on hex' message
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Drawer not closed {0} : ".format(e))

    def get_count_of_elements(self, element):
        """
        Function to get count of elements on screen. Works on the basis of the text / name of the element
        :param element: the element whose count is to be checked
        :return:the count of its presence
        """
        try:
            elements = self.find_elements(
                self.elements.get('MapScreen', 'variable_text').replace(self.replace_pattern, element))
            return elements.__len__()
        except Exception as e:
            raise Exception("Unable to get count for element:".format(element, e))

    def verify_legend_position(self,view_type,device_name):
        """
        Function to verify the position of legend for quickview and closeview of drawer
        :param view_type: type of view: close view or quickview
        :param device_name: device name for devices i.e. iphone6, iphone6plus etc
        :return:Boolean (True:For success or Exception:For failure)
        """
        try:
            location = self.fetch_location_of_element_on_screen('Good')
            if device_name=='iphone6':
                if view_type=='quickview':
                    if not (location['y'] < 483):
                        raise Exception('Legend does not move up to maintain position in quickview')
                else:
                    if not (location['y'] == 471):
                        raise Exception('Legend does not move down to maintain position in closeview')
            elif device_name=='iphone6plus':
                if view_type == 'quickview':
                    if not (location['y'] < 540):
                        raise Exception('Legend does not move up to maintain position in quickview')
                else:
                    if not (location['y'] == 540):
                       raise Exception('Legend does not move down to maintain position in closeview')
            else: #iphone5
                if view_type == 'quickview':
                    if not (location['y'] < 372):
                        raise Exception('Legend does not move up to maintain position in quickview')
                else:
                    if not (location['y'] == 372):
                        raise Exception('Legend does not move down to maintain position in closeview')

            return True
        except Exception as e:
            raise Exception("Unable to verify the legend position with respect to drawer:".format(view_type, e))

