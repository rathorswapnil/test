from actioncontrollers.mobile import BaseController
from PIL import Image
from utilities.Utilities import Utilities
import time
import os
util = Utilities()

class WelcomeScreen(BaseController.BaseController):
    filename = "WelcomeScreen"
    folder_name = "CoverageMap/iOS"
    util = Utilities()
    menu_screen_title = "RootMetrics CoverageMap"
    images = {
        'content_link':'content_link_xpath',
        'enableBDE_yellow': 'enableBDE_switch'
    }

    def __init__(self):
        """ Get object repository for the current Screen controller"""
        self.elements = self.get_object_repo(self.folder_name, self.filename)
        self.device_type = BaseController.BaseController.get_device_type(self)

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        mapping={}
        try:
            if type == 'xpath':
                flag = self.is_element_present(
                    self.elements.get('WelcomeScreen', 'variable_xpath').replace(self.replace_pattern,mapping[identifier]))
            else:
                flag = self.is_element_present(
                    self.elements.get('WelcomeScreen', 'variable_text').replace(self.replace_pattern, identifier))

            if flag is False:
                return False
            else:
                return True
        except Exception as e:
            raise Exception("Unable to verify presence of text for {0} : {1}", identifier)

    def verify_element_is_absent(self, identifier, type='xpath'):
        """
        Function to verify whether element is absent on screen
        :param identifier: the element whose absence is to be checked
        :return: flag status (True:For success or False:For failure)
        """
        mapping = {}
        try:
            if type == 'name':
                flag = self.is_element_present(
                    self.elements.get('WelcomeScreen', 'variable_text').replace(self.replace_pattern, identifier))
            else:
                flag = self.is_element_present(self.elements.get('WelcomeScreen', mapping[identifier]))
            if flag is False:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify absence of text for {0} : {1}".format(identifier, e))

    def enable_bde_first_launch(self):
        """To enable the BDE settings on welcome screen
        :return: Boolean(True:For success or False:For failure)
        """
        try:
            self.tap_element_by_name('enableBDE')
            if (self.verify_element_is_present('Allow', 'name')):
                self.tap_element_by_name("Allow")
            return True

        except Exception as e:
            raise Exception("Unable to enable BDE {0} : ".format(e))

    def disable_bde_first_launch(self):
        """To disable the BDE settings on welcome screen
        :return: Boolean(True:For success or False:For failure)
        """
        try:
            self.tap_element_by_name('enableBDE')
            if (self.verify_element_is_present('Allow','name')):
                self.tap_element_by_name("Allow")
            self.tap_element_by_name('enableBDE')
            return True

        except Exception as e:
            raise Exception("Unable to disable BDE {0} : ".format(e))

    def ImageSetup(self, image_name, element_identifier=None, type='name'):
        """
        Function to create setup image using IR at before runtime execution
        :param element: element-image by which it will be stored during runtime execution
        :param element_identifier: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success else return failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('WelcomeScreen', 'variable_text').replace(self.replace_pattern,
                                                                            element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('WelcomeScreen', self.images[element_identifier]), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} :{1} ".format(image_name, e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success else return failure)
        """
        try:
            if type == "name":
                self.image_recognition(ref_image,
                                       self.elements.get('WelcomeScreen', 'variable_text').replace(
                                           self.replace_pattern,
                                           element), element)
            else:
                self.image_recognition(ref_image, self.elements.get('WelcomeScreen', self.images[element]),
                                       element)
            return True
        except Exception as e:
            raise Exception("Unable to compare image for {0} :{1} ".format(ref_image, e))

    def element_selection_by_xpath(self, element):
        """
        Function to select element by xpath identifier
        :param element:  name of link or data to be selected
        :return: Boolean (True:For success else return failure)
        """
        mapping = {'location_settings':'location_settings_dialog'}
        try:
            self.tap_on_button(self.elements.get('WelcomeScreen', mapping[element]))
            return True
        except Exception as e:
            raise Exception("Unable to get required element by name for {0} : {1}".format(element, e))

    def verify_UI_before_and_after_cancel_on_dialog(self):
        """
        Function to get verify UI and text before and after cancel on dialog in baseline data screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            self.image_compare('Background collection', 'Background collection')
            self.tap_element_by_name("Cancel")
            self.image_compare('enableBDE_yellow', 'enableBDE')
            list = {'Baseline data experience', 'locationSettings',
                    'Background collection is enabled but inactive. Go to Location settings and allow access: Always'}
            for key in list:
                self.verify_element_is_present(key, 'name')
            return True
        except Exception as e:
            raise Exception("Unable to verify UI after cancel on dialog {0}: ".format(e))

    def fetch_location_of_element_on_screen(self, identifier, type='name'):
        """
        Function to fetch location of element on screen
        :param identifier: identifier whose location is to be fetched
        :param type: default value is fetched-  by 'name'
        :return: location else return failure)
        """
        mapping = {}
        try:
            if type == 'xpath':
                ele = self.find_element(self.elements.get('WelcomeScreen', mapping[identifier]))
            else:
                ele = self.find_element(
                    self.elements.get('WelcomeScreen', 'variable_text').replace(self.replace_pattern,
                                                                            identifier))
            location = ele.location
            return location
        except Exception as e:
            raise Exception("Unable to fetch location for element on screen for {0} : {1}".format(identifier, e))

    def element_selection_by_precise_tap(self, element):
        """
        Function to select element by name identifier by fetching location co-ordinates and click by precise tap using those co-ordinates
        :param element:  name of element to be selected
        :return: Boolean (True:For success or False:For failure
        """
        try:
            # fetch the device type connected
            device = self.util.read_ini_file(
                os.path.join(util.get_project_path(), 'config', 'MobileConfig')).get(
                'Generic', 'device_form_factor')
            x=y=0
            if element=='Back to Coverage Map':
                location = self.fetch_location_of_element_on_screen('Back to Coverage Map')
                x = location['x'] + 10
                y = location['y'] + 10
            else:
                location = self.fetch_location_of_element_on_screen(
                    'By using this app you agree to its Terms and Conditions and Privacy Policy.', 'name')
                if element=='Terms link':#this is for "terms" link
                    x=location['x']+100
                    y=location['y']+40
                else: #this is for "privacy" link-iphone5
                    if device=='iphone5':
                        x = location['x'] + 110
                        y = location['y'] + 60
                    else:#this is for "privacy" link-iphone6,iphone6plus
                        x = location['x'] + 200
                        y = location['y'] + 40
            self.mobile_driver.tap([(x, y)], 1)
            return True
        except Exception as e:
            raise Exception("Unable to get select element and click by precise tap for {0} : {1}".format(element, e))
