# -*- coding: utf-8 -*-
import datetime
import time
from PIL import Image, ImageChops
from dateutil import parser
from actioncontrollers.mobile import BaseController

class ReportScreen(BaseController.BaseController):
    filename = "ReportScreen"
    folder_name = "CoverageMap/iOS"
    images = {
        'Notes_text_symbol': 'notes_IR',
        'Details_text_symbol': 'details_IR',
        'Location_text_symbol': 'location_IR',
        'issuetype_symbol': 'issuetype_IR',
        'issue_subtype': 'issue_subtype_IR',
        'checkmark_symbol': 'checkmark_IR',
        'location_line_reportscreen': 'location_line_reportscreen_IR',
        'NotesScreen_Header_UI': 'NotesScreen_Header_UI_IR',
        'NotesScreen_Keyboard_UI': 'NotesScreen_Keyboard_UI_IR',
        'LocationScreen_Header_UI': 'LocationScreen_Header_UI_IR',
        'LocationScreen_Footer_UI': 'LocationScreen_Footer_UI_IR',
        'When_Header_UI': 'When_Header_UI_IR',
        'Issue_subtype_text_symbol':'Issue_subtype_text_symbol_IR',
        'Issuetype_text_symbol':'Issuetype_text_symbol_IR',
        'mapview_locationscreen':'mapview_locationscreen_IR',
        'map_reportscreen':'map_reportscreen_IR',
        'when_dateline_UI':'when_dateline_UI_IR',
        'About_UI':'About_UI_IR',

    }

    def __init__(self):
        """Get object repository for current activity screen"""
        self.elements = self.get_object_repo(self.folder_name, self.filename)

    def verify_text_on_screen(self, identifier, expected_text):
        """
        Function to get text from currently displayed screen and verify it with expected value
        :param: identifier: item whose value w.r.t. which expected text is to be checked
        :param: expected_text: expected text on screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            text_fetched = self.get_element_text(self.elements.get('ReportScreen', identifier),'value')
            if expected_text == text_fetched:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to get required text for {0} : {1}".format(expected_text, e))

    def verify_labels_on_screen(self):
        """
        Function to verify labels on currently displayed screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            screen_text_ios = ['Optional information', 'When', 'Report', 'Send', 'Cancel', 'Issue type']
            for key in screen_text_ios:
                if not self.is_element_present(self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern, key)):
                    return False
            return True
        except Exception as e:
            raise Exception("Unable to get required label : {0}".format(e))

    def verify_date_on_screen(self):
        """
        Function to verify current date and time
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            i = datetime.datetime.now()
            date_time_string = i.strftime('%d-%b-%Y, %H:%M')
            fetched_datetime_from_screen = self.get_element_text(self.elements.get('ReportScreen', 'date'),'value')
            dt = parser.parse(fetched_datetime_from_screen)
            fetched_datetime_from_screen = dt.strftime('%d-%b-%Y, %H:%M')
            datetime_list = fetched_datetime_from_screen.split(':')
            datetime1_list = date_time_string.split(':')
            if not (int(datetime_list[1]) - int(datetime1_list[1]) <= 1 and datetime_list[0] == datetime1_list[0]):
                raise Exception("Date and time not verified due to time lag datetime on reportscreen")
            else:
                return True
        except Exception as e:
            raise Exception("Unable to get required date : {0}".format(e))

    def verify_collapsed_items(self):
        """
        Function to verify whether issue type, issue subtype and 'when' are collapsed or expanded
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            flag1 = self.is_element_present(self.elements.get('ReportScreen', 'call_option'))
            flag2 = self.is_element_present(self.elements.get('ReportScreen', 'issue_subtype_blocked_call'))
            flag3 = self.is_element_present(self.elements.get('ReportScreen', 'when_now'))
            if flag1 is True and flag2 is False and flag3 is False:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify collapsed items: {0}".format(e))

    def verify_report_screen_footer(self):
        """
        Function will verify report screen footer text
        :return: Boolean (True:For success or False:For failure
        """
        try:
            footer_text = "Reports are anonymous. Don't include any personally identifiable information in your notes."
            text = self.get_element_text(self.elements.get('ReportScreen', 'report_footer'))
            if footer_text.replace("'", "") == text.encode('ascii', 'ignore'):
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify report screen footer text:{0}" .format(e))

    def select_issue_type(self, picker_value, time_out=10):
        """
        Function to select the picker wheel element for issue type using ddt approach
        :param picker_value: Picker wheel element to be selected
        :param time_out(optional): find element till specified time_out, default is 10
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            fetched_from_pickerwheel = self.get_element_text(
                self.elements.get('ReportScreen', 'generic_issue_type_picker'), 'value')
            # convert the special characters (if any) in their correct unicode
            fetched_from_pickerwheel = self.convert_using_unidecode(fetched_from_pickerwheel)
            wait_time = 0
            while wait_time < time_out - 1:
                if fetched_from_pickerwheel == picker_value:
                    return True
                else:
                    self.swipe_pickerwheel_action(self.elements.get('ReportScreen', 'generic_issue_type_picker'), 'up')
                    fetched_from_pickerwheel = self.get_element_text(
                        self.elements.get('ReportScreen', 'generic_issue_type_picker'), 'value')
                    # convert the special characters (if any) in their correct unicode
                    fetched_from_pickerwheel = self.convert_using_unidecode(fetched_from_pickerwheel)
                    wait_time += 1
        except Exception as e:
            raise Exception("Unable to select pickerwheel for issue type{0} : {1}".format(picker_value, e))

    def select_issue_subtype(self, picker_value, time_out=10):
        """
        Function to select the picker wheel element for issue subtype using ddt approach
        :param time_out(optional): find element till specified time_out, default is 10
        :param picker_value: Picker wheel element to be selected
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            self.swipe_pickerwheel_action(self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'up')
            fetched_from_pickerwheel = self.get_element_text(
                self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'value')
            # convert the special characters (if any) in their correct unicode
            fetched_from_pickerwheel = self.convert_using_unidecode(fetched_from_pickerwheel)
            wait_time = 0
            while wait_time < time_out - 1:
                if fetched_from_pickerwheel == picker_value:
                    return True
                else:
                    self.swipe_pickerwheel_action(self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'up')
                    fetched_from_pickerwheel = self.get_element_text(
                        self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'value')
                    # convert the special characters (if any) in their correct unicode
                    fetched_from_pickerwheel = self.convert_using_unidecode(fetched_from_pickerwheel)
                    wait_time += 1
        except Exception as e:
            raise Exception("Unable to select pickerwheel for issue subtype{0} : {1}".format(picker_value, e))

    def select_verify_issue_type_issue_subtype(self, list):
        """
        Function to select the picker wheel element for issue type and subtype using ddt approach
        and perform verifications of selections done
        :param list: list to be verified using ddt
        :return: Boolean (True:For success or False:For failure)
        """
        text = "Select"  # default text to be verified
        try:
            for key, sublist in list.items():
                # fetch value of issue type from issue type line
                issue_type_fetched_from_pickerwheel = self.get_element_text(
                    self.elements.get('ReportScreen', 'generic_issue_type_picker'), 'value')
                while issue_type_fetched_from_pickerwheel != key:
                    self.swipe_pickerwheel_action(self.elements.get('ReportScreen', 'generic_issue_type_picker'), 'up')
                    issue_type_fetched_from_pickerwheel = self.get_element_text(
                        self.elements.get('ReportScreen', 'generic_issue_type_picker'), 'value')
                text_fetched = self.get_element_text(
                    self.elements.get('ReportScreen', 'select_text'),'value')
                if 'Select' not in text_fetched:
                    raise Exception("'Select' not present on report screen")

                # tap on Issue subtype to expand it
                self.tap_on_button(
                    self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern, 'Issue subtype'))

                # verify on selecting New issue type whether "select" is present by default on issue subtype pickerhweel
                fetched_from_pickerwheel = self.get_element_text(
                    self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'value')
                if "Select" not in fetched_from_pickerwheel:
                    raise Exception("'Select' is not present in pickerwheel by default")

                self.swipe_pickerwheel_action(self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'up')

                # fetch the text on Issue subtype text line
                ele = self.get_element_text(self.elements.get('ReportScreen', 'variable'),'value')
                # convert the special characters (if any) in their correct unicode
                ele = self.convert_using_unidecode(ele)

                # fetch the value of Issue subtype pickerwheel
                fetched_from_pickerwheel = self.get_element_text(
                    self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'value')
                # convert the special characters (if any) in their correct unicode
                fetched_from_pickerwheel = self.convert_using_unidecode(fetched_from_pickerwheel)

                count = 1
                for value in sublist:
                    # check if text on 'Issue subtype' is present in sublist
                    # check if "Select" option not there in pickerwheel selector after the scroll
                    if ele == value and ele != text and fetched_from_pickerwheel != text:
                        # check if its not last element in sublist and continue to swipe
                        if len(sublist) != count:
                            if value == 'Dropped call':
                                """Verify issue subtypes appear in blue on selection"""
                                self.image_compare('issue_subtype', 'issue_subtype', 'xpath')
                            self.swipe_pickerwheel_action(
                               self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'up')

                        ele = self.get_element_text(self.elements.get('ReportScreen', 'variable'),'value')
                        ele = self.convert_using_unidecode(ele)
                        fetched_from_pickerwheel = self.get_element_text(
                            self.elements.get('ReportScreen', 'generic_issue_subtype_picker'), 'value')
                        fetched_from_pickerwheel = self.convert_using_unidecode(fetched_from_pickerwheel)

                        # check if selected element on pickerwheel appears on Issue subtype text line
                        if fetched_from_pickerwheel != ele:
                            raise Exception("Selected element on pickerwheel does not appear on Issue subtype text line")
                        count += 1

                # tap on Issue type to expand it before going for next iteration
                self.tap_on_button(
                    self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern, 'Issue type'))
            return True
        except Exception as e:
            raise Exception("Unable to select and verify issue type and issue subtype for list {0} :{1} ".format(list,e))

    def enter_nonUTFstrings_in_notes(self):
        """
        Function to enter non-UTF 8 strings (non-english characters,character symbols)
        :return: Boolean (True:For success or False:For failure
        """
        pound = u"\xA3"
        euro = b'\xe2\x82\xac'.decode('utf8')
        nonenglish_characters = u"áÁâÂàÀåÅãÃäÄæÆçÇðÐéÉêÊèÈëËíÍÎìÌïÏñÑóÓôÔòÒøØÕOöÖßþÞúÚûÛùÙüÜýÝÿ"
        text = "Entering non-UTF-8 strings: "
        noncharacter_symbols = ":\"|\"{}+_)(*&^$%#@!~"
        data = text + noncharacter_symbols + nonenglish_characters + pound + euro
        try:
            self.enter_text(self.elements.get('ReportScreen', 'notes_textview'), data)
            return True
        except Exception as e:
            raise Exception("Unable to enter non-UTF 8 strings on screen".format(e))

    def enter_text_in_notes(self, data_to_entered):
        """
        Function to enter text on screen
        :param data_to_entered: text to be entered
        :return: Boolean (True:For success or False:For failure
        """
        try:
            self.enter_text(self.elements.get('ReportScreen', 'notes_textview'), data_to_entered)
            return True
        except Exception as e:
            raise Exception("Unable to enter text in notes {0} :{1}".format(data_to_entered,e))

    def verify_substring_on_screen(self, identifier, expected_text):
        """
        Function to verify substring on currently displayed screen
        :param: identifier: item whose value w.r.t. which expected text is to be checked
        :param: expected_text: expected text on screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            text_fetched = self.get_element_text(
                self.elements.get('ReportScreen', identifier))
            if expected_text in text_fetched:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify substring text for {0} : {1}".format(expected_text, e))

    def verify_element_is_absent(self, identifier):
        """
        Function to verify whether element is absent on screen
        :param identifier: the element whose absence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            flag = self.is_element_present(
                self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern, identifier))
            if flag is False:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify absence of text for {0} : {1}".format(identifier,e))

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :param type(default): the identification parameter like xpath,name. Default is 'xpath'
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type=='xpath':
                flag = self.is_element_present(
                    self.elements.get('ReportScreen', identifier))
            else:
                flag = self.is_element_present(
                    self.elements.get('ReportScreen','variable_text').replace(self.replace_pattern, identifier))
            return flag
        except Exception as e:
            raise Exception("Unable to verify presence of text for {0} : {1}".format(identifier,e))

    def paste_text_from_clipboard_notes_screen(self):
        """
        Function to paste text from clipboard to the screen
        :return: Boolean (True:For success or False:For failure)
        """
        clipboard="Clipboard text"
        try:
            """Enter text in notes"""
            self.enter_text_in_notes(clipboard)
            """Press and hold for -select all option"""
            self.touch_and_hold(self.elements.get('ReportScreen', 'notes_textview'),
                                180, 160)
            self.tap_element_by_name('Select All')
            """Select- "copy" option"""
            self.tap_element_by_name('Copy')
            """Click on delete-button to clear screen"""
            self.tap_element_by_name('delete')
            """Touch and hold for clipboard options to appear on notes screen"""
            self.touch_and_hold(self.elements.get('ReportScreen', 'notes_textview'),
                                180, 160)
            """Select 'Paste' option from clipboard"""
            self.tap_element_by_name('Paste')
            return clipboard
        except Exception as e:
            raise Exception("Unable to paste from clipboard: {0} ", e)

    def verify_details_selected_on_report_screen(self):
        """
        Function to verify  'details' selected on report screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            details_dataset = ['At home', 'Stationary:Outdoors', 'In a building', 'Stationary:Other',
                               'Walking', 'Driving', 'Moving:Other']
            for key in details_dataset:
                self.tap_element_by_name('Details')
                self.tap_element_by_name(key)
                fetched = self.get_element_text(
                    self.elements.get('ReportScreen', 'details_reportscreen'),'value')
                fetched = self.convert_using_unidecode(fetched)
                if fetched == key:
                    pass
                elif key == 'At home' and fetched== 'Stationary - At home':
                    pass
                elif key == 'In a building' and fetched == 'Stationary - In a building':
                    pass
                elif key.replace(':', ' - ') == fetched:
                     pass
                elif key=='Walking' and fetched == 'Moving - Walking':
                    pass
                elif key == 'Driving' and fetched == 'Moving - Driving':
                    pass
                else:
                    raise Exception("Selected details option:" + key + " does not appear on report screen.")
            return True
        except Exception as e:
            raise Exception("Unable to verify details for {0} :", e)

    def ImageSetup(self, image_name, element_identifier=None, type='name'):
        """
        Function to create setup image using IR at before runtime execution
        :param element: element-image by which it will be stored during runtime execution
        :param element_identifier: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern,
                                                                              element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('ReportScreen', self.images[element_identifier]), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} :{1} ".format(image_name, e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == "name":
                self.image_recognition(ref_image,
                                       self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern,
                                                                                                 element), element)
            else:
                self.image_recognition(ref_image, self.elements.get('ReportScreen', self.images[element]), element)
            return True
        except Exception as e:
            raise Exception("Unable to compare image for {0} :{1} ".format(ref_image, e))

    def verify_map_pin_location(self, element):
        """
        Function to verify  map-pin is centered on location screen
        :param element: the identifier of map view on screen
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Capture image"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(element)
            raw_image = Image.open(abs_file_path)
            formatted_image = raw_image.load()
            # get x,y size
            s = raw_image.size
            # iterate through x and y (every pixel)
            for x in xrange(s[0]):
                for y in xrange(s[1]):
                    r, g, b, a = formatted_image[x, y]
                    # Get pink in map
                    if ((180 < r < 210) & (95 < g < 110) & (200 < b < 230)):
                        formatted_image[x, y] = 255, 0, 0
                        if not ((350 < x < 400) & (450 < y < 550)):
                            pass
                    elif ((35 < r < 150) & (170 < g < 210) & (200 < b < 240) &(370<x <394) & (680<y<710)):
                        #if blue color present at centre of screen , blue GPS beacon gets highlighted
                        formatted_image[x, y] = 0, 0,255
                    else:
                        formatted_image[x, y] = 0, 0, 0 #color rest part of image in black
            return True
        except Exception as e:
            raise Exception("Unable to verify map-pin location image for {0} :{1} ".format(element,e))

    def verify_map_is_loaded_reportscreen(self,runtime_image):
        """
        Function to verify  map is loaded on report screen
        :param ref_image: reference image taken for comparison(grid image)
        :param element: the identifier of map-view whose presence/loading is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            ref_image = Image.open(self.get_ref_image_for_comparision('static_map'))
            self.ImageSetup(runtime_image, 'map_reportscreen', 'xpath')
            runtime_image = Image.open(self.get_ref_image_for_comparision(runtime_image))
            if ImageChops.difference(ref_image, runtime_image).getbbox() is None:
                return False
            else:
                return True
        except Exception as e:
            raise Exception("Unable to verify map is loaded on report screen for runtime image{0} with {1}:  ".format(runtime_image,e))

    def fetch_text_from_screen(self, identifier):
        """
        Function to fetch text from screen
        :param identifier: identifier from where text is to be fetched
        :return: Boolean (True:For success or False:For failure)
        """
        mapping={'details_reportscreen':'details_reportscreen',
                 'location_textview_reportscreen':'location_textview_reportscreen',
                 'call_option':'call_option',
                 'issue_subtype_blocked_call':'issue_subtype_blocked_call',
                 'date':'date',
                 'notes_textview_reportscreen':'notes_textview_reportscreen',
                 'notes_textview':'notes_textview'
                 }
        try:
            text = self.get_element_text(self.elements.get('ReportScreen', mapping[identifier]),'value')
            return text
        except Exception as e:
            raise Exception("Unable to fetch data from screen for {0} :{1} ".format(identifier,e))

    def swipe_pickerwheel(self, identifier,direction):
        """
        Function to swipe pickerwheel on screen
        :param identifier: identifier of pickerwheel to be swipped
        :param direction: the direction of swipe action
        :return: Boolean (True:For success or False:For failure)
        """
        mapping = {'day_picker': 'day_picker',
                   'generic_issue_type_picker': 'generic_issue_type_picker',
                   'hour_picker': 'hour_picker'
                   }
        try:
            self.swipe_pickerwheel_action(self.elements.get('ReportScreen', mapping[identifier]),direction)
            return True
        except Exception as e:
            raise Exception("Unable to swipe pickerwheel on screen for {0} for direction-{1}: {2} ".format(identifier,direction,e))


    def swipe_fetching_location_precise_tap(self, element):
        """
        Function to select element by name identifier by which location co-ordinates
        and click by precise tap using those
        :param link_element:  name of element to be selected
        :return: Boolean (True:For success or False:For failure
        """
        try:
            ele = self.find_element(
                self.elements.get('ReportScreen', 'variable_text').replace(self.replace_pattern,
                                                                          element))
            size = ele.size
            x1=size['width']
            y1=size['height']
            y1 = y1 + 10
            x2 = x1
            y2 = y1 + 50
            self.swipe_to_given_location(x1, y1, x2, y2, 1000)
            return True
        except Exception as e:
            raise Exception("Unable to get swipe element by location precise tap {0} : {1}".format(element,e))