from actioncontrollers.mobile import BaseController


class UsageScreen(BaseController.BaseController):
    filename = "UsageScreen"
    folder_name = "CoverageMap/iOS"

    def __init__(self):
        """Get object repository required for the current page"""
        self.elements = self.get_object_repo(self.folder_name, self.filename)