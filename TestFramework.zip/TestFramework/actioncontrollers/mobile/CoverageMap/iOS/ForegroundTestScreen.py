import time
import os
from PIL import Image
from utilities.Utilities import Utilities
from actioncontrollers.mobile import BaseController
util = Utilities()
class ForegroundTestScreen(BaseController.BaseController):
    filename = "ForegroundTestScreen"
    folder_name = "CoverageMap/iOS"
    images = {
    'Test fail':'Test_fail_toast_message_IR'
    }
    util = Utilities()
    def __init__(self):
        """Get object repository for the current repo"""
        self.elements = self.get_object_repo(self.folder_name,self.filename)

    def ImageSetup(self, image_name, element_identifier=None, type='name'):
        """
        Function to create setup image using IR at before runtime execution
        :param element: element-image by which it will be stored during runtime execution
        :param element_identifier: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern,
                                                                              element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('ForegroundTestScreen', self.images[element_identifier]), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} :{1} ".format(image_name, e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: the element which is identified at runtime
        :param type(default): Element identifier using 'name' or 'xpath' for taking the screenshot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == "name":
                self.image_recognition(ref_image,
                                       self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern,
                                                                                                 element), element)
            else:
                self.image_recognition(ref_image, self.elements.get('ForegroundTestScreen', self.images[element]), element)
            return True
        except Exception as e:
            raise Exception("Unable to compare image for {0} :{1} ".format(ref_image, e))

    def verify_element_is_present(self, identifier, type='xpath'):
        """
        Function to verify whether element is present on screen
        :param identifier: the element whose presence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == 'xpath':
                flag = self.is_element_present(
                    self.elements.get('ForegroundTestScreen', 'variable_xpath').replace(self.replace_pattern, identifier))
            else:
                flag = self.is_element_present(
                    self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern, identifier))

            return flag
        except Exception as e:
            raise Exception("Unable to verify presence of text for {0} : {1}".format(identifier, e))

    def verify_text_on_screen(self, identifier, expected_text,type='name'):
        """
        Function to get text from currently displayed screen
        :param: identifer: item whose value w.r.t. which expected text is to be checked
        :param: expected_text: expected text on screen
        :return: Boolean (True:For success or False:For failure)
        """
        mapping={'test_Test':'test_Test_xpath',
                 'test_Download':'test_Download_xpath',
                 'test_Upload':'test_Upload_xpath',
                 'date_download':'date1_download',
                 'date_upload': 'date2_upload',
                'test_Download_loop':'test_Download_xpath_loop'}
        try:
            if type=='name':
                text_fetched = self.get_element_text(self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern, identifier), 'value')
            else:
                text_fetched = self.get_element_text(
                    self.elements.get('ForegroundTestScreen', mapping[identifier]), 'value')

            if expected_text == text_fetched:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify text for {0} : {1}".format(expected_text, e))

    def set_settings_for_continuous_test(self, count):
        """
        Function to do settings for continuous test cycles execution- swipe left and set number of test to run
        and swipe right,then, start continuous test cycles
        :param: count: count of test to be run for tests
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            # fetch the device type connected
            device = self.util.read_ini_file(
                os.path.join(util.get_project_path(), 'config', 'MobileConfig')).get(
                'Generic', 'device_form_factor')

            """Swipe to left of screen"""
            if device == 'iphone5':
                self.swipe_to_given_location(150, 560, 90, 560)
            else: #swipe for iphone6,iphone6plus
                self.swipe_to_given_location(90, 560, 350, 560)

            # tap on required key to set the count of test execution
            self.tap_element_by_name(str(count))

            """Swipe to right of screen"""
            if device=='iphone5':
                self.swipe_to_given_location(150, 560, 90, 560)
            else: #swipe for iphone6,iphone6plus
                self.swipe_to_given_location(350, 560, 90, 560)
            """Click on -'Continuous' and 'start' button"""
            self.tap_element_by_name('Continuous')
            self.tap_element_by_name('startContinuous')
            return True
        except Exception as e:
            raise Exception("Unable to set settings for continuous test lengths for {0} :{1}".format(count,e))

    def verify_continuous_test_lengths(self, count):
        """
        Function to verify continuous test lengths
        :param: count: the count of test for which verification is done
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            identifier="Test results"
            #wait for Test results screen to appear
            self.wait_for_element_to_appear(
                self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern,
                                                                          identifier),100)
            """Verify the test execution - Check presence of correct count in text 'Test Cycles:'"""
            dynamic_testCycles='Test Cycles: '+count
            flag=self.verify_text_on_screen('testCycles', dynamic_testCycles)
            if flag==False:
                raise Exception("Test cycles count on Results screen is incorrect")
            #even number places have "upload" summary while odd number places have "download" summary
            #for (cycle)count=2 the summary lines should be=4 (1 download-upload per cycle)
            max=int(count)*2
            var = 1
            while var <= max:
                 text_fetched = self.get_element_text(
                            self.elements.get('ForegroundTestScreen', 'test_DownloadUpload_xpath_loop').replace('cell',str(var)),'value')
                 if var % 2 != 0:
                    if text_fetched == 'Download':
                           pass
                 else:
                    if text_fetched == 'Upload':
                          pass
                 var+=1
            return True
        except Exception as e:
                raise Exception("Unable to verify continuous test lengths for {0} :{1}".format(e,count))

    def fetch_text_from_screen(self, identifier,type='name'):
        """
        Function to fetch text from screen using some identifier
        :param identifier: identifier from where text is to be fetched
        :param type: default value is fetched-  by 'name'
        :return: Boolean (True:For success or False:For failure)
        """
        mapping = {'success_download':'progress_success_download',
                   'success_upload':'progress_success_upload',
                   'download_speed':'download_speed'
           }
        try:
            if type=='xpath':
                text = self.get_element_text(self.elements.get('ForegroundTestScreen', mapping[identifier]))
            else:
                text = self.get_element_text(self.elements.get('ForegroundTestScreen','variable_text').replace(self.replace_pattern, identifier),'value')
            return text
        except Exception as e:
            raise Exception("Unable to fetch data from screen for {0} :{1} ".format(identifier, e))

    def fetch_size_of_element_on_screen(self, identifier,type='name'):
        """
        Function to fetch size of element on screen
        :param identifier: identifier whose size is to be fetched
        :param type: default value is fetched-  by 'name'
        :return: Boolean (True:For success or False:For failure)
        """
        mapping = { }
        try:
            if type=='xpath':
                ele = self.find_element(self.elements.get('ForegroundTestScreen', mapping[identifier]))
            else:
                ele = self.find_element(
                    self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern,
                                                                                 identifier))
            size = ele.size
            return size
        except Exception as e:
            raise Exception("Unable to fetch size for element on screen for {0} : {1}" .format(identifier,e))

    def verify_element_is_absent(self, identifier):
        """
        Function to verify whether element is absent on screen
        :param identifier: the element whose absence is to be checked
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            flag = self.is_element_present(
                self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern, identifier))
            if flag is False:
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to verify absence of text for {0} : {1}".format(identifier,e))

    def wait_for_text_appearance(self, identifier, expected_text=None, type='name'):
        """
        Function to wait for element to appear. Works on the basis of the text / name /value of the element
        :param: identifier for which wait is executed
        :return:Boolean (True:For success or False:For failure)
        """
        mapping = {}
        try:
            if type == 'name':
                self.wait_for_element_to_appear(
                    self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern,
                                                                              identifier))
            else:
                self.wait_for_text_to_appear(
                    self.elements.get('ForegroundTestScreen',mapping[identifier]),
                    expected_text, 'value')
            return True
        except Exception as e:
            raise Exception("Unable to wait for element" .format(identifier,e))

    def get_count_of_elements(self, element):
        """
        Function to get count of elements on screen. Works on the basis of the text / name of the element
        :param element: the element whose count is to be checked
        :return:the count of its presence
        """
        try:
               elements=self.find_elements(self.elements.get('ForegroundTestScreen', 'variable_text').replace(self.replace_pattern, element))
               return elements.__len__()
        except Exception as e:
            raise Exception("Unable to get count for element:".format(element,e))