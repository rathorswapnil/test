import time
import os
import configparser
from PIL import Image

from actioncontrollers.mobile import BaseController
from utilities import adb_handler


class SetupScreen(BaseController.BaseController):
    parser = configparser.ConfigParser()
    filename = "ImageSetup"
    folder_name = "CoverageMap/Android"

    def __init__(self):
        """
        Constructor to get parser from Base controller class
        :return: parser object
        """
        self.elements = self.get_object_repo(self.folder_name, self.filename)

    def get_report_screen_screenshots(self):
        """
        Function to get report screen screen-shots and store it in screen-shot directory
        :return:Boolean(True:If all screen-shots taken successfully or False: For failure)
        """
        try:
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Report'))

            # Take Report screen Default elements screen-shots
            screen_text_android = ['Report', 'Required information', 'Issue type', 'When', 'Optional information',
                                   'Where', 'Details', 'Add a note', 'Select']

            for text in screen_text_android:
                self.image_setup(text, text)

            print "-------------- Report screen Default elements screen-shots taken successfully----------------"

            # Take Report screen Note section screen-shots
            self.image_setup('Notes_text', 'Notes_text', 'xpath')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'notes_edit'))
            self.image_setup('Notes_partialtext', 'note_layout', 'xpath')
            self.tap_back_button()

            # Enter value in Notes section and take screen-shots
            data = "Text to be entered to verify notes section"
            self.enter_text(self.elements.get('ImageSetupScreen', 'notes_edit'), data)
            self.driver.back()
            self.image_setup("Note_layout", "note_layout", 'id')

            print "---------------- Report screen Notes section screen-shots taken successfully-----------------"

            # Iterate through all the issue types and take screen-shots
            issue_type = ['Call', 'Data', 'Text', 'Device', 'App']

            # Iterate through issue types one by one
            for key in issue_type:
                self.tap_on_button(
                    self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Issue type'))
                # swipe to right till element text matches
                val = self.swipe_till_element_text(
                    self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, key), 'right',
                    key)

                if val and val is not None:
                    # Take Default 'Call' option screen-shot
                    if key == "Call":
                        self.image_setup('Call', 'Call')

                    self.tap_on_button(
                        self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, key))
                    self.image_setup(key, key)
                    # Get all issue sub-types under the selected issue type
                    ele = self.find_elements(self.elements.get('ImageSetupScreen', 'list_view'))

                    # Iterate through all issue sub-types and take screen-shots
                    ele_text = [ele[i].text for i in range(len(ele))]
                    for text in ele_text:
                        self.tap_on_button(
                            self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, text))
                        self.tap_on_button(
                            self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,
                                                                                           'Issue type'))
                        # Take screen-shot of all issue sub-type
                        self.image_setup(text, text)
                    self.tap_back_button()

            # Take screen-shot of App issue type and sub-type
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Issue type'))

            # Swipe till 'App' issue type
            self.swipe_till_element_text(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'App'), 'right',
                'App')
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'App'))

            # Select App issue sub-type
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'App crash'))
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'choosen_app'))

            # Take screen-shot of the selected 'App' issue type and application window
            self.image_setup('Choose an application', 'Choose an application')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'choose_app'))
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'choosen_app'))
            time.sleep(2)
            self.image_setup('Choosen_app', 'choose_app', 'xpath')
            self.tap_back_button()

            print "------------ Report screen Issue type and Sub-types screen-shots taken successfully-----------"

            # Take screen-shot of the 'Report Send' button
            self.image_setup('send_button', 'send_button', 'id')
            print "-------------- Report screen 'Send' report button screen-shot taken successfully-------------------"

            # Take When dialog screen-shots
            when_dialog_list = ['Now', 'Last hour']

            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'When'))
            self.image_setup('When_dialog', 'when_button', 'xpath')

            # Iterate through all the When dialog elements and take screen-shots
            for key in when_dialog_list:
                self.tap_on_button(
                    self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, key))
                self.tap_on_button(
                    self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'When'))
                self.image_setup(key, key)

            self.tap_back_button()

            # Take 'Choose' option screen-shots
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'When'))
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Choose'))

            # Take date/time and 'Apply' button screen-shot
            self.image_setup('datetime', 'datetime_header', 'id')
            self.image_setup('APPLY', 'APPLY')
            self.tap_back_button()

            print "-------------- Report screen 'When' section screen-shots taken successfully--------------------"

            # Take Details section screen-shots
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Details'))
            time.sleep(4)
            self.image_setup('details_justification', 'details_types', 'xpath')

            # Take When default section scree-shots by selecting different options
            self.image_setup('Stationary', 'Stationary')
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Moving'))
            self.image_setup('Moving', 'Moving')
            self.tap_back_button()

            print "------------- Report screen 'Details' section screen-shots taken successfully -----------------"

            # Take 'Where' screen screen-shots

            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Where'))
            time.sleep(2)
            # Take screen-shot of map with Default location displayed at first launch
            self.image_setup('Where_Navigation_Bar', 'where_nav_toolbar', 'id')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'map_apply_button'))
            self.image_setup("map_default", 'where_location_text_line1', 'id')

            # Take screen-shot of map by zooming the location
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Where'))
            time.sleep(4)
            self.tap_on_button( self.elements.get('ImageSetupScreen', 'current_location_image'))
            time.sleep(3)
            os.system('adb shell input swipe 300 500 300 100')
            time.sleep(4)
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'map_apply_button'))
            self.image_setup("map_pan_zoom", 'where_location_text_line1', 'id')

            print "-------------- Report screen 'Where' section screen-shots taken successfully-------------------"

            print "---------------------All Report screen screen-shots taken successfully-------------------------"
            return True
        except Exception as e:
            raise Exception("Unable to take report screen screen-shots", e)

    def image_setup(self, image_name, element_identifier=None, identification_type='name'):
        """
        Function to verify  image using IR at runtime
        :param image_name: Name givne to image for storage
        :param element_identifier: identifier of the element whose screen-shot to be taken
        :param identification_type: Element identifier using 'name' for taking the screen-shot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            """Capture ref image before execution"""
            time.sleep(2)
            abs_file_path = self.get_device_screenshot(image_name)
            screen_shot = Image.open(abs_file_path)
            if identification_type == "name":
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,
                                                                                   element_identifier),
                    screen_shot)
            else:
                setup_image = self.get_element_image_by_dimensions(
                    self.elements.get('ImageSetupScreen', element_identifier), screen_shot)
            setup_image.save(abs_file_path)
            return True

        except Exception as e:
            raise Exception("Unable to create setup image for {0} : ", e)

    def get_about_screen_screenshots(self):
        """
        Function is used to get the screen shots for about screen
        :return: (True For Success)
        """
        try:
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'About'))
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'whatsnew_button'))
            self.image_setup('whatsnew_UI', 'whatsnew_UI_IR', 'xpath')
            self.image_setup('whatsnew_title', 'whatsnew_title_IR', 'xpath')
            self.driver.back()
            self.image_setup("About_Navigation_Bar", 'about_nav_toolbar', 'id')
            self.image_setup("About_Screen_Contents", 'about_content_view', 'id')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,
                                                                                              'Terms and conditions'))
            time.sleep(3)
            self.image_setup("Terms_view_layout", 'view', 'id')
            self.switch_context("Webview")
            self.click_link("Privacy Policy")
            self.switch_context()
            time.sleep(3)
            self.image_setup("Privacy_view_layout", 'view', 'id')
            time.sleep(2)
            self.switch_context("Webview")
            self.driver.back()
            self.switch_context()
            self.driver.back()
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Privacy matters'))
            time.sleep(3)
            self.image_setup("Privacy_view_layout", 'view', 'id')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'back_button'))
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,
                                                                                              'Open source licenses'))
            self.image_setup('Opensource_navigation_toolbar', 'about_nav_toolbar', 'id')
            self.image_setup('Opensource_contents', 'about_content_view', 'id')
            # To be verified when there is no mobile connectivity
            self.opensource_license_no_connectivity()
            adb_handler.enable_and_disable_wifi('on')
            return True
        except Exception as e:
            raise Exception("Unable to get the image setup screenshots for About screen", e.message)

    def opensource_license_no_connectivity(self):
        """
        Function is used to get opensource license screenshots when no connectivity
        :return: (True For Success)
        """
        try:
            adb_handler.enable_and_disable_wifi('off')
            adb_handler.enable_and_disable_mobiledata('off')
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Butterknife'))
            self.image_setup('butterknief_license', 'butterknief_license', 'id')
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Butterknife'))
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'MPAndroidChart'))
            self.image_setup('mpachart_license', 'mpachart_license', 'id')
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'MPAndroidChart'))
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Otto'))
            self.image_setup('otto_license', 'otto_license', 'id')
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Otto'))
            return True
        except Exception as e:
            raise Exception("Unable to verify opesource license on no connectivity", e.message)

    def get_setting_screen_screenshots(self):
        """
        Function is used to get the screen shots for setting screen
        :return:
        """
        try:
            # To verify baseline data experience
            self.tap_on_button(
                self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern, 'Settings'))
            self.image_setup("Settings_Navigation_Bar", 'settings_nav_toolbar', 'id')
            self.image_setup("Settings_Screen_Contents", 'settings_screen_elements', 'id')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,

                                                                                         "Baseline data experience"))
            # To verify RF conditions
            self.image_setup("baseline_nav_toolbar", 'navigation_toolbar', 'id')
            self.image_setup("baseline_off", 'toggle_switch', 'id')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'toggle_switch'))
            self.image_setup("baseline_on", 'toggle_switch', 'id')
            self.driver.back()
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,
                                                                                              "RF/Network conditions"))
            self.image_setup("rf_nav_toolbar", 'navigation_toolbar', 'id')
            self.image_setup("rf_off", 'toggle_switch', 'id')
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'toggle_switch'))
            self.image_setup("rf_on", 'toggle_switch', 'id')
            self.driver.back()
            # To verify Send Data Points
            self.tap_on_button(self.elements.get('ImageSetupScreen', 'variable_text').replace(self.replace_pattern,
                                                                                              "Send data points using"))
            self.image_setup("send_points_popup", 'send_datpoints_layout', 'id')
            self.image_setup("any_network_check", 'any_network_layout', 'id')
            adb_handler.enable_and_disable_wifi('on')
            return True
        except Exception as e:
            raise Exception("Unable to get the image setup screenshots for Setting screen", e.message)
