import time
from utilities import adb_handler
from actioncontrollers.mobile import BaseController

class AboutScreen(BaseController.BaseController):
    filename = "AboutScreen"
    folder_name = "CoverageMap/Android"
    replace_pattern = "##data##"

    def __init__(self):
        """Get object repository for the current repo"""
        self.elements = self.get_object_repo(self.folder_name, self.filename)

    def select_element_by_name(self, ele_name):
        """
        Function to select any element by its name or text
        :param ele_name: Name or Text of the element
        :return: Boolean (True for success or False for failure)
        """
        try:
            self.tap_on_button(
                self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern, ele_name))
            return True
        except Exception as e:
            raise Exception("Unable to identify element {0} by its name : {1}".format(ele_name, e))

    def verify_about_default_ui_elements(self):
        """
        Function to verify about screen default elements
        :return: Boolean (True for Success or False for Failure)
        """
        try:
            """Locate and verify about screen elements"""
            self.image_compare("About_Navigation_Bar", "about_nav_toolbar", 'id')
            self.image_compare("About_Screen_Contents", "about_content_view", 'id')
            return True
        except Exception as e:
            raise Exception("Unable to verify about screen default elements {0}:".format(e))

    def image_compare(self, ref_image, element, type='name'):
        """
        Function to verify  image using IR at runtime
        :param ref_image: reference image taken for comparison
        :param element: element-image with which comparison is to be done
        :param type: Element identifier using 'name' for taking the screen-shot
        :return: Boolean (True:For success or False:For failure)
        """
        try:
            if type == "name":
                flag = self.image_recognition(ref_image,
                                              self.elements.get('AboutScreen', 'variable_text').replace(
                                                  '##data##', element), element)
            else:
                flag = self.image_recognition(ref_image, self.elements.get('AboutScreen', element), element)
            return flag
        except Exception as e:
            raise Exception("Unable to compare image for {0} : ", e)

    def verify_about_screen_title(self):
        """
        Function to verify about screen title
        :return: Boolean (True:For success or False: For Failure
        """
        try:
            text_to_be_verified = "About"
            text_fetched = self.get_element_text(
                self.elements.get('AboutScreen', 'variable_text').replace(self.replace_pattern, 'About'), 'text')
            if text_fetched == text_to_be_verified:
                return True
        except Exception as e:
            raise Exception("Unable to verify about screen title", e)

    def verify_google_play_store(self):
        """
        Function to verify google play store elements
        :return: Boolean (True for success or False for failure)
        """
        try:
            play_store_title = "Cell Phone Coverage Map"
            title = self.get_element_text(self.elements.get('AboutScreen', 'app_title_on_play_store'), 'text')
            if play_store_title == title:
                return True
        except Exception as e:
            raise Exception("Unable to verify google play store elements", e)

    def verify_terms_and_condition_section(self):
        """
        Function to verify default browser is google chrome
        :return: Boolean (True for success or False for failure)
        """
        try:
            to_text = "<info@rootmetrics.com>, "
            links = {'Google Maps Terms of': 'maps.google.com/help/terms_maps.html',
                     'Google Maps Legal': 'maps.google.com/help/legalnotices_maps.html',
                     'Apple Maps Terms of': 'www.apple.com/legal/internet-services/maps/terms-en.html'}

            self.select_element_by_name('Terms and conditions')
            time.sleep(3)
            self.image_compare("Terms_view_layout", "view", 'id')
            self.switch_context("Webview")
            self.click_link("Privacy Policy")
            self.switch_context()
            time.sleep(3)
            self.image_compare("Privacy_view_layout", "view", 'id')
            time.sleep(2)
            self.switch_context("Webview")
            self.tap_on_device_back_button()
            self.click_link("info@rootmetrics.c")
            self.switch_context()
            if to_text != self.get_element_text(self.elements.get('AboutScreen', 'gmail_to_box'), 'text'):
                raise Exception("Gmail to text not verified")
            for key, val in links.iteritems():
                self.switch_context("Webview")
                self.click_link(key)
                self.switch_context()
                if not val.__contains__(self.get_element_text(self.elements.get('AboutScreen', 'chrome_search_box'), 'text')):
                    raise Exception("Navigation sites did not matched {0} : {1}".format(key, val))
                self.tap_on_device_back_button()
            return True
        except Exception as e:
            raise Exception("Unable to verify default google chrome browser", e)

    def verify_privacy_section(self):
        """
        Function to verify privacy section elements
        :return: Boolean (True for success or False for failure)
        """
        try:
            to_text = "<userprivacy@rootmetrics.com>, "
            links = {'How Google uses': 'https://www.google.com/intl/en-US/policies/privacy/partners/',
                     'Network Advertising': 'www.networkadvertising.org'}
            self.select_element_by_name('Privacy matters')
            time.sleep(3)
            self.image_compare("Privacy_view_layout", "view", 'id')
            for key, val in links.iteritems():
                contexts = self.driver.contexts
                self.switch_context("WEBVIEW_com.rootmetrics")
                self.click_link(key)
                self.switch_context()
                if not val.__contains__(
                        self.get_element_text(self.elements.get('AboutScreen', 'chrome_search_box'), 'text')):
                    raise Exception("Navigation sites did not matched {0} : {1}".format(key, val))
                self.tap_on_device_back_button()

            self.switch_context("Webview")
            self.click_link("userprivacy@rootmetrics.c")
            self.switch_context()
            if to_text != self.get_element_text(self.elements.get('AboutScreen', 'gmail_to_box'), 'text'):
                raise Exception("Gmail 'TO' text not verified")

            return True
        except Exception as e:
            raise Exception("Unable to verify privacy section elements", e)

    def verify_aboutscreen_when_no_connectivity(self, operation):
        """
        Function to verify About section behavior when the device has no connectivity and also checked for opensource elements
        :param operation: Operation to be performed on the screen
        :return:  Boolean (True for success )
        """
        try:
            if operation == 'No_Connectivity':
                adb_handler.enable_and_disable_wifi('off')
                adb_handler.enable_and_disable_mobiledata('off')
                adb_handler.enable_and_disable_airplane_mode('off')
            elif operation == 'Airplane_Mode':
                adb_handler.enable_and_disable_wifi('off')
                adb_handler.enable_and_disable_airplane_mode('on')
            about_Screen_elements = ['Rate this app', 'Privacy matters', 'Terms and conditions']
            for element in about_Screen_elements:
                self.select_element_by_name(element)
                # time.sleep(2)
                self.is_element_present(self.elements.get('AboutScreen', 'rate_toast_msg'))
                fetched_text = self.get_element_text(self.elements.get('AboutScreen', 'rate_toast_msg'))
                if operation == 'No_Connectivity':
                    if not fetched_text == 'bad network, no soup for you!':
                        raise Exception("Toast notification does not appears at the bottom of the screen")
                elif operation == 'Airplane_Mode':
                    if not fetched_text == 'aha! airplane mode':
                        raise Exception("Toast notification does not appears at the bottom of the screen")
            self.select_element_by_name('Open source licenses')
            self.image_compare('Opensource_navigation_toolbar', 'about_nav_toolbar', 'id')
            self.image_compare('Opensource_contents', 'about_content_view', 'id')
            # To verify each section opens and displays license text but displayed link is NOT enabled as a hyperlink
            self.opesource_options('Butterknife', 'butterknief_license', operation)
            self.opesource_options('MPAndroidChart', 'mpachart_license', operation)
            self.opesource_options('Otto', 'otto_license', operation)
            adb_handler.enable_and_disable_wifi('on')
            adb_handler.enable_and_disable_airplane_mode('off')
            return True
        except Exception as e:
            raise Exception("Unable to verify About section behavior when the device has no connectivity", e.message)

    def opesource_options(self, option, option_licence, operation):
        """
        Function to verify each section of open source opens and displays license text but displayed link is NOT enabled as a hyperlink
        :param option:Option of open source to be selected
        :param option_licence:license of open source option
        :param:operation:option to verify whether it is Airplane mode or else No connection
        :return:Boolean (True for success )
        """
        try:
            self.select_element_by_name(option)
            self.image_compare(option_licence, option_licence, 'id')
            self.tap_on_button(self.elements.get('AboutScreen', option_licence))
            fetched_text_butterknief = self.get_element_text(self.elements.get('AboutScreen', 'rate_toast_msg'))
            if operation == 'No_Connectivity':
                if not fetched_text_butterknief == 'Placeholder text for the sad state of no active connection.':
                    raise Exception("Toast notification does not appears at the bottom of the screen")
            elif operation == 'Airplane_Mode':
                if not fetched_text_butterknief == 'Placeholder text for flighty airplane mode.':
                    raise Exception("Toast notification does not appears at the bottom of the screen")
            self.select_element_by_name(option)
        except Exception as e:
            raise Exception("Unable to verify each section of open source opens and displays license text but displayed link is NOT enabled as a hyperlink",
                e.message)

    def verify_whatsnew_UI(self):
        """
        Function to verify whatsnew screen UI elements and navigate back to about screen
        :return:  Boolean (True for success )
        """
        try:
            self.tap_on_button(self.elements.get('AboutScreen', 'whatsnew_button'))
            self.image_compare('whatsnew_UI', 'whatsnew_UI_IR', 'xpath')
            self.image_compare('whatsnew_title', 'whatsnew_title_IR', 'xpath')

            self.scroll_to_text('Tell us your experience')

            """Verify whether 'Get started' screen is absent """
            flag=  self.is_element_present(self.elements.get('AboutScreen', 'variable_text').replace('##data##','Get started'))
            if flag==True:
                raise Exception("'Get started' present on screen")
            """Verify whether About screen is displayed after back arrow is tapped"""
            self.tap_element_by_name('Navigate up')
            flag = self.is_element_present(self.elements.get('AboutScreen', 'variable_text').replace('##data##', 'About'))
            if flag == False:
                raise Exception("About screen not displayed")
            return True
        except Exception as e:
            raise Exception("Unable to verify whatsnew UI elements", e.message)