import imaplib
import re
import time
from actioncontrollers.web import BaseController
from actioncontrollers.web.adminportal import UsersPage
from actioncontrollers.web.adminportal import CommonPage


class LoginController(BaseController.BaseController):
    """ This class contains all login page functions """
    file_name = "LoginPage"

    def __init__(self,portal='webportal'):
        if portal == 'webportal':
            self.element_parser = self.get_object_repo(self.file_name)
        elif portal == 'adminportal':
            self.element_parser = self.get_object_repo(self.file_name,'adminportal')
        elif portal =='opsmanager':
            self.element_parser = self.get_object_repo(self.file_name,'opsmanager')

    def wait_for_page_load(self):
        self.find_element(self.element_parser.get('LoginScreen', 'user_table'))
        self.find_element(self.element_parser.get('LoginScreen', 'add_new_user_btn'))
        self.find_element(self.element_parser.get('LoginScreen', 'disable_user_btn'))
        time.sleep(5)
        print 'login page loaded succesfully'

    def login_to_app(self, user_name, password, portal_type="webportal"):
        """
        Function to login to an application
        :param: username
        :param: password
        :return: Boolean (True:for success)
        """
        try:
            self.get_url(portal_type) #To get the url for the specific portal
            self.enter_text(self.element_parser.get('LoginScreen', 'username_txt'), user_name)
            self.enter_text(self.element_parser.get('LoginScreen', 'password_txt'), password)
            self.click(self.element_parser.get('LoginScreen', 'signin_button'))
        except Exception as e:
            raise Exception("Unable to login to application '{0}'".format(e))
        # To close the welcome window, as validation is specific to webportal so condition is used
        if portal_type == 'webportal' or portal_type == 'webportalproxy':
            try:
                self.click(self.element_parser.get('LoginScreen','welcome_close'))
                self.wait_for_element_disappearance(self.element_parser.get('LoginScreen','welcome_close'))
                time.sleep(3)
                if self.get_element_availability(self.element_parser.get('LoginScreen','welcome_close')):
                    self.click(self.element_parser.get('LoginScreen','welcome_close'))
                    time.sleep(3)
            except Exception as e2:
                if self.get_element_availability(self.element_parser.get('LoginScreen','welcome_close')):
                    self.click(self.element_parser.get('LoginScreen','welcome_close'))
                    time.sleep(3)
                print 'Could not click on the close button of the welcome message modal view '+e2.message
        return True

    def verify_reset_password_mail_send_successfully(self, user_name,portal_type='webportal'):
            """
            Function to verify reset password email send successfull
            :param: username
            :param:portal_type
            :return: Boolean (True:for success)
            """
            try:
                self.get_url(portal_type)
                self.click(self.element_parser.get('LoginScreen', 'reset_password_link'))
                self.enter_text(self.element_parser.get('LoginScreen', 'username_txt'), user_name)
                self.click(self.element_parser.get('LoginScreen', 'send_reset_email_button'))
                success_message = self.get_text(self.element_parser.get('LoginScreen', 'email_in_message_tag'))
                time.sleep(10)
                #TODO: Add indefinite wait for email to recieve.
                if user_name in success_message:
                    self.click(self.element_parser.get('LoginScreen', 'done_button'))
                    return True
            except Exception as e:
                raise Exception("Unable to send reset password email '{0}'".format(e))

    def open_reset_password_link(self, username_gmail, password_gmail):
            """
            Function to fetch password reset link from email
            :param: username
            :param: password
            :return: Boolean (True:for success)
            """
            try:
                mail = imaplib.IMAP4_SSL('imap.gmail.com')
                mail.login(username_gmail, password_gmail) # Login to user's accounts
                mail.select('inbox')  # Connect to inbox.
                # Fetch all emails with SubjectLine RootMetrics Password Reset
                result, data = mail.uid('search', None, '(HEADER Subject "RootMetrics Password Reset")')
                latest_email_uid = data[0].split()[-1] # Get uid of the latest email
                result, data = mail.uid('fetch', latest_email_uid, '(RFC822)')
                raw_email = data[0][1]
                # Fetch reset password link from email using regular expression from the raw data
                reset_pwd_link = str(re.search(r'\*+.+?\s*href=\s*(http.+?\s*)>', raw_email, re.MULTILINE).group(1))
                self.open_url(reset_pwd_link)
                mail.logout()
                return True
            except Exception as e:
                raise Exception("Unable to open reset password link '{0}'".format(e))

    def set_new_password(self, new_password, confirm_password):
            """
            Function to submit new password and confirm password
            :return:
            """
            try:
                self.enter_text(self.element_parser.get('LoginScreen', 'reset_password_txt'), new_password)
                self.enter_text(self.element_parser.get('LoginScreen', 'reset_confirm_password_txt'), confirm_password)
            except Exception as e:
                raise Exception("Unable to set new password '{0}'".format(e))

    def verify_password_reset_successfully(self, new_password, confirm_password, success_message):
            """
            Function to verify new password is set successfully
            :return: Boolean (True:for success)
            """
            try:
                self.set_new_password(new_password, confirm_password)
                if new_password == confirm_password:
                    self.click(self.element_parser.get('LoginScreen', 'change_password_button'))
                    time.sleep(2)
                    message = self.get_text(self.element_parser.get('LoginScreen', 'password_changed_successfully_tag')).strip()
                if message == success_message:
                    self.click(self.element_parser.get('LoginScreen', 'signin_button'))
                    return True
            except Exception as e:
                raise Exception("Unable to reset password  '{0}'".format(e))

    def verify_password_and_confirm_password_do_not_match(self, new_password, confirm_password):
            """
            Function to verify password and confirm password do not match
            :return: Boolean (True:for success)
            """
            try:
                self.set_new_password(new_password, confirm_password)
                element = self.find_element(self.element_parser.get('LoginScreen', 'change_password_button'))
                if not element.is_enabled():
                    return True
            except Exception as e:
                raise Exception("Unable to verify password and confirm password do not match '{0}'".format(e))

    def verify_email_not_found(self, user_name, email_not_found_message,portal_type='webportal'):
            """
            Function to verify error message for invalid email entered for password reset
            :param: username
            :param: portal_type('adminportal','webportal')
            :return: Boolean (True:for success)
            """
            try:
                self.get_url(portal_type)#To get the url for the specific portal
                self.click(self.element_parser.get('LoginScreen', 'reset_password_link'))
                self.enter_text(self.element_parser.get('LoginScreen', 'username_txt'), user_name)
                self.click(self.element_parser.get('LoginScreen', 'send_reset_email_button'))
                time.sleep(2)
                error_text = self.get_text(self.element_parser.get('LoginScreen', 'invalid_email_message_tag')).strip()
                if email_not_found_message in error_text :
                    element = self.element_parser.get('LoginScreen', 'closeEmailNotFoundDialogue_button')
                    self.click(element)
                    return True
            except Exception as e:
                raise Exception("Unable to verify email not found error message '{0}'".format(e))

    def verify_invalid_login(self, login_message):
        """
        Function to verify invalid login error message
        :return: Boolean (True:for success)
        """
        try:
            error_message = self.get_text(self.element_parser.get('LoginScreen', 'invalid_login_message'))
            if login_message in error_message:
                element=self.element_parser.get('LoginScreen', 'closeInvalidDialogue')
                self.click(element)
                return True
        except Exception as e:
            raise Exception("Unable to verify invalid login to an application '{0}'".format(e))

    def logout_from_app(self):
        """
        Function to logout from an application
        :return: Boolean (True:for success)
        """
        try:
            self.click(self.element_parser.get('LoginScreen', 'signout_button'))
            time.sleep(5)
        except Exception as e:
            raise Exception("Unable to logout from app '{0}'".format(e))

# if __name__ == "__main__":
# ##########dataset#################
# username='aniket.deshpande@afourtech.com'
# test_user='afourtest@test.com'
# password='A4Tech@1234'
# permission='r'
# resource={"country":"united-states"}
# ui_permission_status_dict={}
# preference=True
# #################################
#
# logincontroller=LoginController()
# logincontroller.login_to_app(username,password)
# basePage=BaseController.BaseController()
# #basePage.navigate('usersTab')
# userPage=UsersPage.UsersPage()
# logincontroller.wait_for_page_load()
# userPage.open_edit_permission(test_user)
# common=CommonPage.CommonPage()
# common.check_uncheck_permission_for_resource(permission,resource,preference)
# ui_permission_status_dict=common.get_permission_from_ui()
# ui_permission_source_status_dict=common.get_permission_source_from_ui()
# print ui_permission_status_dict
# print '-----------------------------------------------------------'
# print ui_permission_source_status_dict