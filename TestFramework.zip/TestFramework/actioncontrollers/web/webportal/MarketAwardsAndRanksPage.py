# coding=utf-8
import json
import re
import time

from actioncontrollers.web.webportal import MarketBasePageController
from utilities import api_handler
from selenium.webdriver.common.action_chains import ActionChains

class MarketAwardsAndRanksPage(MarketBasePageController.MarketBasePageController):
    """ This class contains all the Awards and Rank Page functions """
    file_name = "MarketAwardsAndRanks"

    def __init__(self):
        super(MarketAwardsAndRanksPage, self).__init__()
        self.element_parser = self.get_object_repo(self.file_name)

    def get_score_types_list(self):
        """
        Function returns list of available score Types [Overall, Speed , Text etc ]
        :return: rootscore_types list
        """
        try:
            rootscore_types = [ele.text for ele in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_parameters'))]
            return rootscore_types
        except Exception as e:
            raise Exception("Unable to get list fo Score Types", e.message)

    def get_carriers_list(self):
        """
            Function to get carriers list from chart of RootScore
            :return:rootscore_carriers_list
        """
        try:
            # Create carrier list
            rootscore_ele_carriers_list = self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_carriers'))
            rootscore_carriers_list = [rootscore_ele.text for rootscore_ele in rootscore_ele_carriers_list]
            rootscore_carriers_list.reverse()
            return rootscore_carriers_list

        except Exception as e:
            raise Exception("Unable to create carriers list from web", e.message)

    def get_score_list(self):
        """
            Function to get score list from chart of RootScore
            :return:rootscore_carriers_list
        """
        try:
            # Create score list
            rootscore_ele_scores_list = self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_numeric_value'))
            rootscore_scores_list = [rootscore_ele.text for rootscore_ele in rootscore_ele_scores_list]
            rootscore_scores_list.reverse()
            return rootscore_scores_list

        except Exception as e:
            raise Exception("Unable to create scores list from web", e.message)

    def get_rootscore_carriers_dict_web(self):
        """
            To get the rootscore chart dict from web
            :return:carrier rank dict
        """
        try:
            carriers_dict_web = {}
            # Create rank list
            rootscore_ele_ranks_list = self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_ranks'))
            rootscore_ranks_list = [rootscore_ele.text for rootscore_ele in rootscore_ele_ranks_list]
            rootscore_ranks_list.reverse()

            # Create a dict of carriers and their rank from web
            carriers_rank_dict_web = dict(zip(self.get_carriers_list(), rootscore_ranks_list))

            # Create a dict of carriers and their score from web
            carriers_score_dict_web = dict(zip(self.get_carriers_list(), self.get_score_list()))

            # Create ColorCode list
            rootscore_ele_color_list = []
            for rootscore_ele_color in self.find_elements(
                    self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_colorcode')):
                rootscore_ele_color_list.append(rootscore_ele_color.value_of_css_property('fill'))

            rootscore_ele_color_list.reverse()

            # Create a dict of carriers and their Color from web
            carriers_color_dict_web = dict(zip(self.get_carriers_list(), rootscore_ele_color_list))

            # Merged [Rank,Score,Color] Carrier wise into a single carriers_dict_web

            for carrier in self.get_carriers_list():
                carrier_dict = {}
                carrier_dict['rank'] = carriers_rank_dict_web[carrier]
                carrier_dict['score'] = carriers_score_dict_web[carrier]
                carrier_dict['color'] = carriers_color_dict_web[carrier]
                carriers_dict_web[carrier] = carrier_dict

            return carriers_dict_web

        except Exception as e:
            raise Exception("Unable to get rootscore chart carries dict from web", e.message)

    def get_rootscore_dict_web(self):
        """
            To get the rootscore full dict for all score types from web
            :return:rootscore_dict_web
        """
        try:
            rootscore_dict_web = {}
            for score_type in self.get_score_types_list():
                self.click_score_type(score_type)
                rootscore_dict_web[score_type] = self.get_rootscore_carriers_dict_web()
            # Todo : Get data from RootScore chart by list reverse() concept. We have to find some better solution for that

            return rootscore_dict_web

        except Exception as e:
            raise Exception("Unable to get final rootscore dict from web", e.message)

    def verify_same_ranks_have_line(self):
        """
        Function to verify same ranks have line on Rootscore chart
        :return: None
        """
        try:
            for score_type in self.get_score_types_list():
                y_attribute_list = []
                self.click_score_type(score_type)
                rootscore_ele_ranks_list = self.find_elements(
                    self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_ranks'))
                rootscore_ranks_list = [rootscore_ele.text for rootscore_ele in rootscore_ele_ranks_list]

                for rootscore_ele_rank in rootscore_ele_ranks_list:
                    count = rootscore_ranks_list.count(rootscore_ele_rank.text)
                    if count > 1:
                        y_attribute_list.append(rootscore_ele_rank.get_attribute('y'))

                if y_attribute_list:
                    d = ''
                    common_rank_line_list = self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_common_rank_line'))
                    for common_rank_line_ele in common_rank_line_list:
                        d = d + common_rank_line_ele.get_attribute('d')

                    for y_attribute_value in y_attribute_list:
                        if y_attribute_value not in d:
                            raise Exception("line not available between same rank", y_attribute_value)
                del y_attribute_list
        except Exception as e:
            raise Exception("line not available on same rank", e.message)

    def verify_trace_bars_points(self):
        """
        Function to verify trace bars on rootscore chart have correct ending points
        :return:None
        """
        try:
            trace_bars_rect_ele = self.find_element(
                self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_trace_bars_plot'))
            trace_bars_rect_width = trace_bars_rect_ele.get_attribute('width')
            single_point_value = float(trace_bars_rect_width) / 100.00
            score_point_calc_list = []
            for score in self.get_score_list():
                score_point_calc_list.append(round(float(score) * single_point_value, 2))

            trace_bars_points_ele_list = self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_trace_bars_points'))
            trace_bars_points_web_list = []
            for trace_bars_points_ele in trace_bars_points_ele_list:
                trace_bars_points_web_list.append(trace_bars_points_ele.get_attribute('d'))

            trace_bars_points_web_list.reverse()

            for score_point in score_point_calc_list:
                index = score_point_calc_list.index(score_point)
                if str(score_point) not in trace_bars_points_web_list[index]:
                    raise Exception("Trace bar have incorrect ending point", score_point)

        except Exception as e:
            raise Exception("Unable to verify Trace bars ending points", e.message)

    def compare_api_ui_ranks(self, ui_dict, api_dict):
        """
        This method compares UI chart for Ranks to corresponding api source
        :param ui_dict: dict created by capturing ranks on UI
        :param api_dict: dict created by capturing scores from api response
        """
        try:
            for param in ui_dict:
                for carrier in ui_dict[param]:
                    if not api_dict[param][carrier]['rank'] == ui_dict[param][carrier]:
                        print 'Rank mismatch for carrier {0}: api rank {1} vs ui rank {2}'.format(carrier,
                                                                                                  api_dict[param][
                                                                                                      carrier]['rank'],
                                                                                                  ui_dict[param][
                                                                                                      carrier]['rank'])
            return True
        except Exception as e:
            print 'Failed while comparing UI vs API carrier ranks for given market as :{0}'.format(e.message)
            return False

    def compare_api_ui_scores(self, ui_dict, api_dict):
        """
        This method compares UI chart for Rootscore to corresponding api source
        :param ui_dict: dict created by capturing scores/ranks on UI
        :param api_dict: dict created by capturing ranks from api response
        """
        try:
            flag = True
            for param in ui_dict:
                for carrier in ui_dict[param]:
                    if not int(api_dict[param][carrier]['rank']) == int(ui_dict[param][carrier]['rank']):
                        print 'Rank mismatch for carrier {0}: api rank {1} vs ui rank {2}'.format(carrier,
                                                                                                  api_dict[param][
                                                                                                      carrier]['rank'],
                                                                                                  ui_dict[param][
                                                                                                      carrier]['rank'])
                        flag = False
                    if not round(float(api_dict[param][carrier]['score']) * 100, 1) == float(
                            ui_dict[param][carrier]['score']):
                        print 'Rootscore mismatch for carrier {0}: api rank {1} vs ui rank {2}'.format(carrier, round(
                            float(api_dict[param][carrier]['score']) * 100, 1), ui_dict[param][carrier]['score'])
                        flag = False
            return flag
        except Exception as e:
            print 'Failed while comparing UI vs API rootscore for given market as :{0}'.format(e.message)

    # portal 1.5 method
    def get_api_scorerank_dict(self, country, product, period, market):
        """
        This method makes call to method in api handler to call score api and retrieve parameter specific ranks and score
        :param country: United States/Canada/United Kingdom
        :param product: RSR Metro/RSR Airport/RSR Venue
        :param period: 2H 2015/1H 2016
        :param market: name of surveyed region
        :return: dict of data regarding score and ranks for specific product
        """
        market_score_dict = {}
        try:

            api_obj = api_handler.APIHandler()
            serialised_res = api_obj.get_scores_for_winners(api_obj.get_product_id(product, period, country))
            all_market_score_data = json.loads(serialised_res)['scores']
            market_score_dict = {}
            for market_score_data in all_market_score_data:
                if market in market_score_data['collection_area']:
                    market_score_dict = market_score_data['score_types']
            for param_key in market_score_dict:
                market_score_dict[param_key] = market_score_dict[param_key]['carriers']

        except Exception as e:
            print 'Failed to capture score/ranks from api for given market as :{0}'.format(e.message)

        return market_score_dict

    def get_param_bounds(self):
        """
        This function create dict of network parameters as key and start and end point on x-axis as their value
        to decide parameter based on circles location on rank chart
        :return: param_dict : {'Overall':{'start_x':'val1','end_x':'val2'},'Data':{'start_x':'val1','end_x':'val2'}..}
        """
        try:
            parameters = self.get_parameter_list()
            xyplot_area_ele = self.find_element(self.element_parser.get('AwardsAndRanksScreen', 'rankchart_xy_plot'))
            plot_start_x = int(xyplot_area_ele.location['x'])
            grid_x = [int(ele.location['x']) for ele in
                      self.find_elements(self.element_parser.get('AwardsAndRanksScreen', 'rankchart_xlines'))]
            grid_x.append(int(xyplot_area_ele.size['width']) + plot_start_x)
            param_dict = {}
            for param in parameters:
                inner_dict = {}
                inner_dict['start_x'] = plot_start_x
                for val in grid_x:
                    inner_dict['end_x'] = val
                    plot_start_x = val
                    grid_x.pop(0)
                    break
                param_dict[param] = inner_dict
            return param_dict
        except Exception as e:
            raise Exception("Unable to get x-axis start and end points on chart for network parameters" + e.message)

    def get_rank_bounds(self):
        """
        This function create dict of rank as key and start and end point on y-axis as its value
        to decide rank based on circles location on rank chart
        :return: rank_dict : {'1':{'start_y':'val1','end_y':'val2'},'2':{'start_y':'val1','end_y':'val2'}..}
        """
        try:
            ranks = [int(ele.text[:1]) for ele in self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                             'ranks'))]
            xyplot_area_ele = self.find_element(self.element_parser.get('AwardsAndRanksScreen', 'rankchart_y_start'))
            pattern = re.compile('^.*\,\s*([0-9].*)\)$')
            start_y = float(pattern.match(str(xyplot_area_ele.get_attribute('transform'))).groups()[0])
            grid_y = [float(pattern.match(str(ele.get_attribute('transform'))).groups()[0]) for ele in
                      self.find_elements(self.element_parser.get('AwardsAndRanksScreen', 'rankchart_ylines'))]
            rank_dict = {}
            for rank in ranks:
                inner_dict = {}
                inner_dict['start_y'] = start_y
                for val in grid_y:
                    inner_dict['end_y'] = val
                    start_y = val
                    grid_y.pop(0)
                    break
                rank_dict[rank] = inner_dict
            return rank_dict
        except Exception as e:
            raise Exception("Unable to get y-axis start and end points on chart for ranks" + e.message)

    def _get_rank_web_dict_by_period(self, period_type, color_dict, rank_range, param_range):

        try:

            ele_list = self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'rankchart_{0}_year_circles'.format(period_type)))
            # polygon_ele_list = self.find_elements(self.element_parser.get('AwardsAndRanksScreen','rank_chart_polygon'))
            rank_chart_data_dict = {}
            pattern = re.compile('^.*\,\s*([0-9].*)\)$')

            for ele in ele_list:
                rank, network_param, carrier, ele_y_location = None, None, None, None
                carrier_rank_dict = {}
                # ### ele_y_location = self._get_element_rank_y_bound(ele, polygon_ele_list)
                if period_type == 'current' and ele_y_location is None:
                    ele_y_location = float(pattern.match(str(ele.get_attribute('transform'))).groups()[0])
                elif period_type == 'previous' and ele_y_location is None:
                    ele_y_location = float(ele.get_attribute('cy'))

                # get carrier name that circle represent on chart by its color
                for carrier_name, color in color_dict.iteritems():
                    if ele.value_of_css_property('fill') == color:
                        carrier = carrier_name
                        break
                # get rank of carrier that circle represent on chart by its location
                for key_rank, bound in rank_range.iteritems():
                    if bound['start_y'] < ele_y_location < bound['end_y']:
                        rank = key_rank
                        break
                # get network parameter that circle represent on chart by its location
                for param_name, bound in param_range.iteritems():
                    if bound['start_x'] < ele.location['x'] < bound['end_x']:
                        network_param = param_name
                        break
                carrier_rank_dict[carrier] = rank
                if network_param in rank_chart_data_dict:
                    rank_chart_data_dict[network_param].update(carrier_rank_dict)
                else:
                    rank_chart_data_dict[network_param] = carrier_rank_dict
            return rank_chart_data_dict
        except Exception as e:
            raise Exception("Unable to get rank chart data from web" + e.message)

    def get_rank_chart_data(self, color_dict):
        """
        This function returns dict of rank chart data from web
        :param period_type: 'current' or 'previous'
        :param color_dict: color_code defined for carrier for current/previous period
        :return: rank_chart_data_dict'previous' (51336032) = {dict} {u'Data': {u'AT&T': 3, u'Sprint': 4, u'Verizon': 1, u'T-Mobile': 2}, u'Text': {u'AT&T': 1, u'Sprint': 1, u'Verizon': 1, u'T-Mobile': 1}, u'Overall': {u'AT&T': 2, u'Sprint': 2, u'Verizon': 1, u'T-Mobile': 2}, u'Reliability': {u'AT&T': 3, u'Sprint': 2, u'Ver… View
        """
        try:
            rank_range = self.get_rank_bounds()
            param_range = self.get_param_bounds()
            rank_chart_data_dict = {}
            rank_chart_data_dict['current'] = self._get_rank_web_dict_by_period('current', color_dict['current'],
                                                                                rank_range, param_range)
            rank_chart_data_dict['previous'] = self._get_rank_web_dict_by_period('previous', color_dict['previous'],
                                                                                 rank_range, param_range)

            for param_key in rank_chart_data_dict['current']:
                if not param_key in rank_chart_data_dict['previous']:
                    rank_chart_data_dict['previous'][param_key] = rank_chart_data_dict['current'][param_key]
                for carrier in rank_chart_data_dict['current'][param_key]:
                    if not carrier in rank_chart_data_dict['previous'][param_key]:
                        rank_chart_data_dict['previous'][param_key][carrier] = \
                            rank_chart_data_dict['current'][param_key][carrier]

            return rank_chart_data_dict
        except Exception as e:
            raise Exception("Unable to get rank chart data from web" + e.message)

    # def _get_element_rank_y_bound(self, element, polygon_ele_list):
    #     """
    #     Function return y co-ordinate of rank chart's circle by applying analytical logic
    #     :param element: web element circle
    #     :return: y co-ordinate of circle
    #     """
    #     try:
    #
    #         pattern = re.compile('translate.+?\s*(.+?)\)')
    #         element_location = tuple((pattern.match(str(element.get_attribute('transform'))).groups()[0]).split(','))
    #         for ele in polygon_ele_list:
    #             points_list = [tuple(points.split(',')) for points in ele.get_attribute('points').split(' ')]
    #             if float(points_list[1][1]) == float(points_list[2][1]) == float(element_location[1]) and \
    #                     (float(element_location[0]) - float(points_list[1][0]) == 12.5) or \
    #                     (float(element_location[0]) - float(points_list[1][0]) == -12.5):
    #                 return float(element_location[1])
    #     except Exception as e:
    #         raise Exception("Unable to get range for "+e.message)

    def get_carrier_and_color_code(self, carrier_lst):
        """
        Function returns dict of carrier(as key) and their color(as value) for current period defined for rank chart
        on web
        :return: color_dict
        """
        try:
            color_dict = {}
            for carrier in carrier_lst:
                color_dict[carrier] = self.find_element(
                    self.element_parser.get('AwardsAndRanksScreen', 'rankchart_carrier_color_code').replace(
                        self.replace_pattern,
                        carrier)).value_of_css_property(
                    'fill')
            return color_dict
        except Exception as e:
            raise Exception("Unable to get color code for carriers from web", e.message)

    def get_parameter_list(self):
        """
        Function returns list of available network parameters for selected product
        :return: network_parameters list ['Overall', 'Speed' , 'Text' etc ]
        """
        try:
            network_parameters = [ele.text for ele in self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                                 'rankchart_parameters'))]
            return network_parameters
        except Exception as e:
            raise Exception("Unable to get list fo network parameters" + e.message)

    def get_chart_carrier_ui_value_api_value_list(self, api_dict):
        """
        Function returns list of carrier and resp UI & API values
        :param : api_dict
        :return: chart_data_list eg. ['Vodafone', * , 0.19]
        """
        try:

            chart_y_axis_carrier_list = [str(ele.text) for ele in
                                         self.find_elements(self.element_parser.get('AwardsAndRanksScreen', 'ranks'))]
            chart_carrier_display_value = [str(ele.text) for ele in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'get_chart_carrier_display_value'))]
            carrier_list = [x.encode('utf-8') for x in api_dict['Data'].keys()]
            api_carrier_actual_chart_value = [[key, api_dict['Data'][key]['score']] for key in carrier_list]

            chart_data_list = []
            try:
                if len(chart_y_axis_carrier_list) and len(chart_carrier_display_value) == len(
                        api_carrier_actual_chart_value):
                    for val in range(4):
                        for key in api_carrier_actual_chart_value:
                            if chart_y_axis_carrier_list[val] in key[0]:
                                chart_data_list.append(
                                    [chart_y_axis_carrier_list[val], chart_carrier_display_value[val], key[1]])

                return chart_data_list
            except Exception as e:
                raise Exception("Unable to Create chart data list [Carrier, UI_Value, Api_Value]", e.message)
        except Exception as e:
            raise Exception("Unable to return chart data list [Carrier, UI_Value, Api_Value]", e.message)

    def get_api_msr_chart_dict(self, country, product, period, market):
        """
        This method makes call to method in api handler to call msr chart api
        :param country: Republic of Korea
        :param product: RSR Metro/RSR Airport/RSR Venue
        :param period: 2H 2015/1H 2016
        :param market: name of surveyed region
        :return: dict of msr data regarding value and metric for specific product
        """
        msr_chart_dict = {}  # orginal Dict
        msr_chart_dict_modified = {}  # modified Dict
        try:
            report_name = "msr"
            # api Handler
            api_obj = api_handler.APIHandler()
            # meta data
            meta_data = api_obj.get_meta_data()
            # get_product_id
            product_id = api_obj.get_product_id(product, period, country)
            # get_collection_set_id
            collection_set_id = api_obj._get_collection_set_id(product_id, market)
            # get_collection_set
            collection_set = api_obj._get_collection_set(product_id, collection_set_id)
            # get_report_id_from_collection_set
            report_id_list = api_obj.get_any_parameter_from_collection_set(collection_set, report_name, "report_id")
            # get_carrier_name_from_collection_set
            carrier_name_list = api_obj.get_any_parameter_from_collection_set(collection_set, report_name,
                                                                              "carrier_name")
            # get_carrier_id_from_collection_set
            carrier_id_list = api_obj.get_any_parameter_from_collection_set(collection_set, report_name, "carrier_id")

            # eg. carrier_id_with_name = [[1,AT&T],[2,Sprint],[3,T],[4,Verizon]
            carrier_id_with_name = []
            if len(carrier_id_list) == len(carrier_name_list):
                for index in range(len(carrier_id_list)):
                    carrier_id_with_name.append([carrier_id_list[index], carrier_name_list[index]])

            # eg. metric_id_with_name = [[rootscore_base_metric_id,test_type_id,portal_metric_name_to_use]
            metric_id_with_name = [[data.get('rootscore_base_metric_id'), data.get('test_type_id'),
                                    str(data.get('portal_metric_name_to_use'))] for data in
                                   meta_data.get('meta').get('metrics').get('msr_metrics')]

            # creating original single dict for every carrier with carrier name
            for index in range(len(carrier_name_list)):
                msr_carrier_dict = api_obj._get_report_by_id(product_id, report_id_list[index])
                msr_chart_dict[carrier_name_list[index]] = msr_carrier_dict['report']

            # mapping for quality parameter with respective score_type_id
            quality_parameter_mapping = [["Overall", 6], ["Reliability", 4], ["Data", 1], ["Speed", 5], ["Call", 2],
                                         ["Text", 3]]
            # percentage_metric_list for multiplying kpi_value * 100 for every list elements based on metric
            percentage_metric_list = ["Dropped outgoing call", "Uplink throughput task success",
                                      "Downlink throughput task success", "Blocked outgoing call (M-to-L)",
                                      "Email task success", "Lite data task success",
                                      "Downlink throughput access success", "Lite data access success", "Uplink throughput access success","Email access success"]

            for carrier in carrier_name_list:
                msr_chart_dict_modified[carrier] = {}
                for quality_parameter_index in range(len(quality_parameter_mapping)):

                    for value in range(len(quality_parameter_mapping)):
                        if msr_chart_dict[carrier][quality_parameter_index]['score_type_id'] == \
                                quality_parameter_mapping[value][1]:
                            msr_chart_dict_modified[carrier][quality_parameter_mapping[value][0]] = {}

                            for kpis in msr_chart_dict[carrier][quality_parameter_index]:
                                if kpis == "kpis":
                                    msr_chart_dict_modified[carrier][quality_parameter_mapping[value][0]][kpis] = {}

                                    for metric in range(len(msr_chart_dict[carrier][quality_parameter_index][kpis])):
                                        test_type_id = msr_chart_dict[carrier][quality_parameter_index][kpis][metric][
                                            'test_type_id']
                                        root_score_id = msr_chart_dict[carrier][quality_parameter_index][kpis][metric][
                                            'rootscore_base_metric_id']

                                        for value1 in range(len(metric_id_with_name)):
                                            if (test_type_id == metric_id_with_name[value1][1]) and (
                                                        root_score_id == metric_id_with_name[value1][0]):
                                                metric_name = metric_id_with_name[value1][2]
                                                msr_chart_dict_modified[carrier][quality_parameter_mapping[value][0]][
                                                    kpis][metric_name] = {}

                                                for carrierss in \
                                                        msr_chart_dict[carrier][quality_parameter_index]['kpis'][
                                                            metric]:
                                                    if carrierss == 'carriers':
                                                        msr_chart_dict_modified[carrier][
                                                            quality_parameter_mapping[value][0]][kpis][metric_name][
                                                            carrierss] = {}

                                                        for carriers_idssss in range(len(
                                                                msr_chart_dict[carrier][quality_parameter_index][kpis][
                                                                    metric][carrierss])):
                                                            carrier_ids = \
                                                                msr_chart_dict[carrier][quality_parameter_index][kpis][
                                                                    metric][carrierss][carriers_idssss]['carrier_id']
                                                            for carrier_index in range(len(carrier_id_with_name)):
                                                                if carrier_ids == carrier_id_with_name[carrier_index][
                                                                    0]:
                                                                    msr_chart_dict_modified[carrier][
                                                                        quality_parameter_mapping[value][0]][kpis][
                                                                        metric_name][carrierss][
                                                                        carrier_id_with_name[carrier_index][1]] = {}

                                                                    for datas in \
                                                                            msr_chart_dict[carrier][
                                                                                quality_parameter_index][
                                                                                kpis][metric][carrierss][
                                                                                carriers_idssss]:
                                                                        if datas == 'kpi_value':
                                                                            msr_value = msr_chart_dict[carrier][
                                                                                quality_parameter_index][kpis][metric][
                                                                                carrierss][carriers_idssss][datas]
                                                                            if metric_name in percentage_metric_list:
                                                                                kpi_value = format((msr_value) * 100,
                                                                                                   '.3g')
                                                                            else:
                                                                                kpi_value = format(msr_value, '.3g')

                                                                            if kpi_value.isdigit() == True:
                                                                                if len(kpi_value) == 1:
                                                                                    kpi_value = kpi_value + '.00'
                                                                                elif len(kpi_value) == 2:
                                                                                    kpi_value = kpi_value + '.0'
                                                                                elif len(kpi_value) == 3:
                                                                                    kpi_value = kpi_value + '.'
                                                                            else:
                                                                                integer = int(float(kpi_value))
                                                                                decimals = str(float(kpi_value)-int(float(kpi_value)))[2:]
                                                                                if integer == 0 and len(decimals) == 2:
                                                                                     kpi_value = kpi_value + '0'
                                                                                elif integer == 0 and len(decimals) == 1:
                                                                                     kpi_value = kpi_value + '00'
                                                                                elif integer == 1 and len(decimals) == 1:
                                                                                     kpi_value = kpi_value + '0'

                                                                            msr_chart_dict_modified[carrier][
                                                                                quality_parameter_mapping[value][0]][
                                                                                kpis][metric_name][carrierss][
                                                                                carrier_id_with_name[carrier_index][1]][
                                                                                datas] = kpi_value
                                                                        else:
                                                                            msr_chart_dict_modified[carrier][
                                                                                quality_parameter_mapping[value][0]][
                                                                                kpis][metric_name][carrierss][
                                                                                carrier_id_with_name[carrier_index][1]][
                                                                                datas] = msr_chart_dict[carrier][
                                                                                quality_parameter_index][kpis][metric][
                                                                                carrierss][carriers_idssss][datas]

                                                    else:
                                                        msr_chart_dict_modified[carrier][
                                                            quality_parameter_mapping[value][0]][kpis][metric_name][
                                                            carrierss] = \
                                                            msr_chart_dict[carrier][quality_parameter_index][kpis][
                                                                metric][
                                                                carrierss]


                                else:
                                    msr_chart_dict_modified[carrier][quality_parameter_mapping[value][0]][kpis] = \
                                        msr_chart_dict[carrier][quality_parameter_index][kpis]

            return msr_chart_dict_modified
        except Exception as e:
            print 'Failed to capture MSR chart values from api for given market as :{0}'.format(e.message)

    def get_msr_chart_dict_web(self, current_period):
        """
        Function to get msr chart dict from web
        :param current_period: 2H 2015, 1H 2016 etc
        :return:msr_chart_dict_web
        """
        try:

            msr_chart_dict = {}
            msr_carrier_list = [ele.text for ele in self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                               'msr_chart_carrier'))]
            msr_quality_parameter_list = [ele.text for ele in
                                          self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                     'rootscore_chart_parameters'))]
            for carrier_a in msr_carrier_list:
                msr_chart_dict[str(carrier_a)] = {}
                self.click(
                    self.base_element_parser.get('MarketPageScreen', 'market_carrier').replace(self.replace_pattern,
                                                                                               carrier_a))
                for quality_parameter in msr_quality_parameter_list:
                    msr_chart_dict[str(carrier_a)][str(quality_parameter)] = {}
                    msr_chart_dict[str(carrier_a)][str(quality_parameter)]['kpis'] = {}
                    self.click(
                        self.base_element_parser.get('MarketPageScreen', 'score_type').replace(self.replace_pattern,
                                                                                               quality_parameter))
                    if (
                            self.find_elements(self.element_parser.get('AwardsAndRanksScreen', 'msr_chart'),
                                               2)).__len__() != 0:
                        msr_metric_list = [str(ele.text) for ele in
                                           self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                      'msr_metrics_length'))]
                        msr_metric_carrier_value_list = [ele.text for ele in self.find_elements(
                            self.element_parser.get('AwardsAndRanksScreen',
                                                    'msr_metric_carrier_values'))]
                        index = 0
                        for metric_name in msr_metric_list:
                            msr_chart_dict[str(carrier_a)][str(quality_parameter)]['kpis'][metric_name] = {}
                            msr_chart_dict[str(carrier_a)][str(quality_parameter)]['kpis'][metric_name]['carriers'] = {}
                            for carrier_b in [ele.text for ele in self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                               'msr_chart_carrier'))]:
                                if index != len(msr_metric_carrier_value_list):
                                    msr_chart_dict[str(carrier_a)][str(quality_parameter)]['kpis'][metric_name][
                                        'carriers'][str(carrier_b)] = {}
                                    kpi_value = re.sub("[^\d.]+", "", str(msr_metric_carrier_value_list[index]))
                                    msr_chart_dict[str(carrier_a)][str(quality_parameter)]['kpis'][metric_name][
                                        'carriers'][str(carrier_b)]['kpi_value'] = kpi_value
                                    index += 1
            return msr_chart_dict
        except Exception as e:
            raise Exception("Unable to get msr chart dict from web " + e.message)

    def verify_msr_chart_dict(self, api_dict, web_dict):
        """
        Function to compare api_dict with web_dict
        :param : api_dict
        :param : web_dict
        :return: Bool {true,false}
        """
        try:
            bool = True
            for carrier in web_dict:
                for quality_parameter in web_dict[carrier]:
                    for metric_index in web_dict[carrier][quality_parameter]['kpis']:
                        for carrier_api in web_dict[carrier][quality_parameter]['kpis'][metric_index]['carriers']:
                            value_api = \
                                api_dict[carrier][quality_parameter]['kpis'][metric_index]['carriers'][carrier_api][
                                    'kpi_value']
                            value_web = \
                                web_dict[carrier][quality_parameter]['kpis'][metric_index]['carriers'][carrier_api][
                                    'kpi_value']
                            if value_api != value_web:
                                print (value_api, value_web, carrier, quality_parameter, metric_index, carrier_api)
                                bool = False

            return bool
        except Exception as e:
            raise Exception("Unable to compare MSR dict web & api ", e.message)

    def verify_msr_messages(self,api_dict):
        """
        Function is used to get the best metric value for the given carrier and quality parameter
        :param : api_dict to fetch {kpis,max_score_reached,published}
        :return: Boolean True for successfull verify the messages display for MSR, False: Unsuccessfull verification
        """
        try:
         msr_carrier_list = [ele.text for ele in self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                               'rootscore_chart_carriers'))]
         msr_quality_parameter_list = [ele.text for ele in
                                          self.find_elements(self.element_parser.get('AwardsAndRanksScreen',
                                                                                    'rootscore_chart_parameters'))]
         bool = True
         for carrier_a in msr_carrier_list:
            self.click( self.base_element_parser.get('MarketPageScreen', 'market_carrier').replace(self.replace_pattern,carrier_a))
            for quality_parameter in msr_quality_parameter_list:
                self.click(self.base_element_parser.get('MarketPageScreen', 'score_type').replace(self.replace_pattern,quality_parameter))
                kpis = api_dict[carrier_a][quality_parameter]['kpis']
                max_score = api_dict[carrier_a][quality_parameter]['max_score_reached']
                published = api_dict[carrier_a][quality_parameter]['published']
                if (kpis == {} and max_score == False and published == False) or (kpis == {} and max_score == True and published == True):
                    if not (self.find_elements(self.element_parser.get('AwardsAndRanksScreen', 'msr_no_metrics_focus_message'))):
                        bool = False
            print("Verified all MSR Messages for carrier:%s" %carrier_a)
         return bool
        except Exception as e:
            raise Exception("Message verification failed", e.message)


    def get_msr_best_performance_values_web(self):
        """
        Function is used to get the best metric value for the given carrier and quality parameter
        :return: returns the best performance value list
        """
        try:
            return [re.sub("[^\d.]+", "", str(ele.text)) for ele in
                    self.find_elements(self.element_parser.get('AwardsAndRanksScreen', 'msr_best_performance'),1)]
        except Exception as e:
            raise Exception("unable to fetch the best performance value from web", e.message)

    def click_market_carriers(self, carrier):
        """
        Function to click on carrier type [AT&T, Sprint etc]
        :param carrier: Carriers which are at header of map
        :return:True for Success and Exception for failure
        """
        try:
            self.click(self.base_element_parser.get('MarketPageScreen', 'market_carrier').replace(self.replace_pattern,
                                                                                                  carrier))
            return True
        except Exception as e:
            raise Exception("Unable to click parameter {0} : {1}".format(carrier, e))

    def verify_msr_carrier_color_code(self, carrier):
        """
        Function to click on carrier type [AT&T, Sprint etc] to verify the color code of carriers
        :param carrier: Carriers which are at header of map
        :return: True for success or Exception for Failure
        """
        try:
            # Create ColorCode list
            rootscore_ele_color_list = []
            for rootscore_ele_color in self.find_elements(
                    self.element_parser.get('AwardsAndRanksScreen', 'rootscore_chart_colorcode')):
                rootscore_ele_color_list.append(rootscore_ele_color.value_of_css_property('fill'))

            rootscore_ele_color_list.reverse()

            # Create a dict of carriers and their Color from web
            carriers_color_dict_web = dict(zip(self.get_carriers_list(), rootscore_ele_color_list))
            # fetch the parameters- Overall, Reliability,speed,data,call,text
            rootscore_chart_parameters = self.get_score_types_list()
            for param in rootscore_chart_parameters:
                self.click_score_type(param)
                time.sleep(3)  # need this wait to refresh page and load the metrics
                no_metrics_focus_similarly_well_message = self.find_elements(
                    self.element_parser.get('AwardsAndRanksScreen', 'msr_no_metrics_focus_message'))
                if len(no_metrics_focus_similarly_well_message) == 1:
                    print ("MSR chart not available for carrier: {0} and parameter: {1}".format(
                        carrier, param))

                else:
                    """Fetch the vertical color blocks"""
                    fetch_color_blocks = self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen', 'msr_metrics_color_blocks'))
                    rgba_values = []
                    for items in fetch_color_blocks:  # fetch rgba values
                        rgba_values.append(items.value_of_css_property('background-color'))

                    rgb_values = []
                    for index in range(len(rgba_values)):  # convert rgba values to rgb values list
                        rgb_values.append(rgba_values[index].replace('rgba', 'rgb').replace(', 1)', ')'))

                    """Verify if carrier's color code present in vertical color blocks"""
                    for i in rgb_values:
                        if i == carriers_color_dict_web[carrier]:  # if match found break the loop
                            break
                        else:
                            continue  # continue to verify carrier's color code in other vertical color blocks

            return True
        except Exception as e:
            raise Exception("Unable to verify carrier color code for carrier {0} : error {1}: ".format(carrier, e))

    def verify_msr_carriers_parameters_inline_list(self, carrier, filters, inline_list):
        """
        This method verifies the selected carrier with the message 'Metric focus on '
        and also checks the parameters's titles
        :param carrier: the selected carrier from msr chart verification
        :return Boolean: True for Success and Exception for Failure
        """
        try:
            rootscore_chart_parameters = self.get_score_types_list()
            for param in rootscore_chart_parameters:
                self.click_score_type(param)
                if self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen',
                                                'msr_chart')).__len__() == 0:  # MSR_chart not loaded
                    print("MSR chart not available for carrier :{0} for parameter :{1}".format(
                        carrier, param))
                    continue
                else:  # MSRchart loaded
                    rootscore_carriers_metric_focus_list = self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen', 'msr_carrier_metric_focus'))
                    carrier_metric_focus = rootscore_carriers_metric_focus_list[0].text.rstrip(':')
                    if carrier != carrier_metric_focus:
                        # '{Carrier}: Metrics to focus on' does not match for selected carrier name
                        raise Exception(
                            '"{}: Metrics to focus on" does not match for selected carrier name:{0} and parameter {1}'.format(
                                carrier, param))
                    # Verify message- 'Metrics stored by impact on:' for correct paramter selected
                    param_value_message = self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen', 'msr_parameters_values'))
                    count = 0
                    while not filters[count] in param_value_message[0].text and count < len(filters):
                        count += 1
                    if filters[count] not in param_value_message[0].text:
                        raise Exception(
                            "Message:'Metrics stored by impact on:' failed for {0}".format(param_value_message))

                    fetch_inline_list = self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen', 'msr_inline_list'))
                    if cmp(fetch_inline_list[0].text, inline_list) != 1:
                        raise Exception("Inline list: not displayed on screen for {1} and parameter {2}".format(
                            fetch_inline_list, carrier, param))

                    # click the info- icon
                    self.click(self.element_parser.get('AwardsAndRanksScreen', 'msr_info_icon'))

                    info_icon_popup = self.find_elements(
                        self.element_parser.get('AwardsAndRanksScreen', 'msr_info_icon_popup'))
                    if info_icon_popup.__len__() == 0:
                        raise Exception("Info icon popup not displayed for carrier{0} and parameter {1}".format(
                            carrier, param))
            return True

        except Exception as e:
            raise Exception(
                'Failed while verifying msr carriers and respective parameters for carrier:{0}--{1}'.format(carrier, e))

    def get_performance_parameter_value_api_and_compare_against_web(self, api_MSR_chart_dict):
        """
        Function is used to fetch the performance parameter value from API and compare it against web
        :param api_MSR_chart_dict:
        :return:True(For success)
        """
        try:
            bool = True
            for carriers in api_MSR_chart_dict:
                self.click_link(carriers)
                # Sleep added for the carrier to click and metric table to load
                time.sleep(2)
                for quality_param in api_MSR_chart_dict[carriers]:
                    self.click_link(quality_param)
                    # Sleep added for the quality parameter to click and metric table to load
                    time.sleep(2)
                    # Get best performance value form web
                    metric_best_performance = self.get_msr_best_performance_values_web()
                    # Get the performance parameter values form web
                    web_performance_list = self.get_msr_performance_parameters_web()
                    metric_performance_api_list = []
                    try:
                        # Code to fetch the performance parameter values from web and compare them against API
                        for metric_name in api_MSR_chart_dict[carriers][quality_param]['kpis']:
                            for value in api_MSR_chart_dict[carriers][quality_param]['kpis'][metric_name]['carriers']:
                                performance_param_api = \
                                    api_MSR_chart_dict[carriers][quality_param]['kpis'][metric_name]['carriers'][value][
                                        'kpi_half_comparison']
                                kpi_value = \
                                    api_MSR_chart_dict[carriers][quality_param]['kpis'][metric_name]['carriers'][value][
                                        'kpi_value']
                                metric_performance_api_list.append([str(performance_param_api), kpi_value])
                        # Comparison Code
                        # TODO:Remove print statements and add exception once functionality is implemented
                        for metric_value in metric_performance_api_list:
                            if metric_value[0] == 'improved':
                                if not metric_value[1] in web_performance_list[0][0]:
                                    print (
                                        "The {0} metric improved value from web does not match with API value".format(
                                            metric_value[1]))
                            elif metric_value[0] == 'degraded':
                                if not metric_value[1] in web_performance_list[0][1]:
                                    print (
                                        "The {0} metric degarded value from web does not match with API value".format(
                                            metric_value[1]))
                            elif metric_value[0] == '':  # '' specifies stayed same value
                                if not metric_value[1] in web_performance_list[0][2]:
                                    print (
                                    "The {0} metric stayed same value from web does not match with API value".format(
                                        metric_value[1]))
                                    bool = False
                    except Exception as e:
                        raise Exception(
                            "The comparison of API and Web fails for the metric performance parameter values",
                            e.message)
                    try:
                        # Code to fetch the best performance parameter values from web and compare them against API
                        metric_best_performance_api_list = []
                        for metric_name in api_MSR_chart_dict[carriers][quality_param]['kpis']:
                            for value in api_MSR_chart_dict[carriers][quality_param]['kpis'][metric_name]['carriers']:
                                if api_MSR_chart_dict[carriers][quality_param]['kpis'][metric_name]['carriers'][value][
                                    'kpi_best'] == True:
                                    kpi_value = \
                                        api_MSR_chart_dict[carriers][quality_param]['kpis'][metric_name]['carriers'][
                                            value][
                                            'kpi_value']
                                    metric_best_performance_api_list.append(kpi_value)
                        # TODO:Remove print statements and add exception once functionality is implemented
                        # Comparison Code
                        for metric in metric_best_performance:
                            if metric not in metric_best_performance_api_list:
                                print metric, carriers, quality_param
                                bool = False
                    except Exception as e:
                        raise Exception("The comparison of API and Web fails for the metric best performance values",
                                        e.message)
            return bool
        except Exception as e:
            raise Exception("Unable to compare the performance values from api and web", e.message)

    def get_msr_performance_parameters_web(self):
        """
        Function is used to get the performance metric value from web for the given carrier and quality parameter
        :return: returns the  performance parameters value list from web
        """
        try:
            # TODO:Optimize the code
            Final_performance_parameter_list = []
            improved_metric_list = [re.sub("[^\d.]+", "", str(ele.text)) for ele in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'metric_value_improved_color_code'),1)]
            degraded_metric_list = [re.sub("[^\d.]+", "", str(ele.text)) for ele in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'metric_value_degraded_color_code'),1)]
            stayed_same_metric_list = [re.sub("[^\d.]+", "", str(ele.text)) for ele in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'metric_value_same_color_code'),1)]
            Final_performance_parameter_list.append(
                [improved_metric_list, degraded_metric_list, stayed_same_metric_list])
            return Final_performance_parameter_list
        except Exception as e:
            raise Exception("unable to fetch the best performance values from web", e.message)

    def verify_stats_section_title(self):
        """
        Function verifies Stats section titles [Statistics,Drive/Walk Route,Indoor Locations,Methodology]
        :return:boolean True or False
        """
        try:
            predefined_dict = {'Statistics': 'Statistics', 'Drive/Walk Route': 'Drive/Walk Route',
                               'Indoor Locations': 'Indoor Location List', 'Methodology': 'Methodology'}
            stats_section_title_list = [title.text for title in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'stats_section_title_list'))]
            stats_title_list = [stats.text for stats in self.find_elements(
                self.element_parser.get('AwardsAndRanksScreen', 'stats_title_list'))]
            # dict from left and right panel title list
            stats_title_dict = dict(zip(stats_section_title_list, stats_title_list, ))
            # Dict from right:left panel title
            section_nav_dict = dict(zip(stats_title_list, stats_section_title_list))
            self.click(self.element_parser.get('AwardsAndRanksScreen', 'click_methodology'))
            # wait is used to load the help page after clicking on methodology parameter
            time.sleep(3)
            # Code to check the active state of navigation on scrolling to particular text
            for key, value in section_nav_dict.iteritems():
                self.scroll_to_text(
                    self.element_parser.get('AwardsAndRanksScreen', 'stats_title').replace(self.replace_pattern, key))
                self.find_element(self.element_parser.get('AwardsAndRanksScreen', 'active_navigation_title').replace(
                    self.replace_pattern, value))
            # Verifying predefined dict with the fetched dict
            if predefined_dict != stats_title_dict:
                raise Exception("web dict and predefined dicts are not same")
            # Iterating dict for identifying titles
            for key, value in stats_title_dict.iteritems():
                stats_section_title_ele = self.find_element(
                    self.element_parser.get('AwardsAndRanksScreen', 'stats_section_title').replace(self.replace_pattern,
                                                                                                   key))
                # click on key of dict
                actions = ActionChains(self.web_driver)
                actions.click(stats_section_title_ele).perform()
                stats_title = (self.find_element(
                    self.element_parser.get('AwardsAndRanksScreen', 'stats_title').replace(self.replace_pattern,
                                                                                           stats_title_dict.get(
                                                                                               key)))).text
                # comparing title in dict and title on web page
                if stats_title != stats_title_dict.get(key):
                    return False
            return True
        except Exception as e:
            raise Exception("Unable to verify stats and methodology section titles", e.message)


if __name__ == "__main__":
    test = MarketAwardsAndRanksPage()
    test.get_api_scorerank_dict('United States', 'RSR Metro', '2H 2015', 'Virginia Beach, VA')
