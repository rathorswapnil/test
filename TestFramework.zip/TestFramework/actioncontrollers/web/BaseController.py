import os
import base64
import time
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, ElementNotVisibleException, ElementNotSelectableException
from selenium.webdriver.support.ui import WebDriverWait as wait
from selenium.webdriver.support import expected_conditions as expected
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from utilities import Utilities
from json import loads,dumps
from browsermobproxy import Server


class BaseController(Utilities.Utilities):
    """ This class contains all common functions used by page or test scripts """
    proxy = None
    web_driver = None
    application_url = None
    replace_pattern = '##data##'
    utilities = Utilities.Utilities()

    @property
    def driver(self):
        """
        To get initialized driver
        :return:web_driver instance
        """
        return BaseController.web_driver

    def get_url(self, portal_type):
        """
        To get the specific url according to the portal type
        :param portal_type:
        :return:
        """
        global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'WebConfig'))
        if portal_type == 'webportal':
            application_url = global_config.get('Web', 'environment_url')
        elif portal_type == 'adminportal':
            application_url = global_config.get('Web', 'admin_environment_url')
        elif portal_type == 'rootmetrics':
            application_url = global_config.get('Web', 'rootmetrics_environment_url')
        elif portal_type == 'opsmanager':
            application_url = global_config.get('Web', 'opsmanager_environment_url')
        elif portal_type == 'webportalproxy':
            application_url = global_config.get('WebProxy','environment_url')
            BaseController.web_driver = self.set_proxy_browser_driver()

        if BaseController.web_driver is None:
            if portal_type != 'webportalproxy':
                BaseController.web_driver = self.set_browser_driver()

        BaseController.web_driver.get(application_url)
        self.maximize_browser()

    def get_current_url(self):
        """
        This function is used to get the current url
        :return: current_url
        """
        if BaseController.web_driver is None:
            BaseController.web_driver = self.set_browser_driver()
        return BaseController.web_driver.current_url

    def scroll_to_end(self):
        """
        Scrolls the webpage to the end
        :return:
        """
        if BaseController.web_driver is None:
            BaseController.web_driver = self.set_browser_driver()
        lenOfPage = BaseController.web_driver.execute_script(
            "window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
        match = False
        while (match == False):
            lastCount = lenOfPage
            time.sleep(3)
            lenOfPage = BaseController.web_driver.execute_script(
                "window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
            if lastCount == lenOfPage:
                match = True

    def get_object_repo(self, page_name, portal_type='webpages'):
        """
        Function to get webportal object repository
        :param page_name: page name
        :return: parser
        """
        try:
            """Read object repo file"""
            return self.read_ini_file(os.path.join(self.get_project_path(), 'objectrepository', portal_type, page_name))
        except Exception as e:
            raise Exception("Unable to read object repository file:'{0}'".format(e))

    def get_element_availability(self, path):
        """
        Function to check for element available on screen
        :param path: search element path
        :return: True if element is available and visible
        """
        search_type = str(path).split('|')[0]
        element_identifier = str(path).split('|')[1]
        try:
            if search_type == "xpath":
                try:
                    wait(self.driver, 3).until(expected.presence_of_element_located((By.XPATH, element_identifier)))
                    wait(self.driver, 3).until(expected.visibility_of_element_located((By.XPATH, element_identifier)))
                    return True
                except:
                    return False
            elif search_type == "id":
                try:
                    wait(self.driver, 3).until(expected.presence_of_element_located((By.ID, element_identifier)))
                    wait(self.driver, 3).until(expected.visibility_of_element_located((By.ID, element_identifier)))
                    return True
                except:
                    return False
            elif search_type == "name":
                try:
                    wait(self.driver, 3).until(expected.presence_of_element_located((By.NAME, element_identifier)))
                    wait(self.driver, 3).until(expected.visibility_of_element_located((By.NAME, element_identifier)))
                    return True
                except:
                    return False
            elif search_type == "class_name":
                try:
                    wait(self.driver, 3).until(
                        expected.presence_of_element_located((By.CLASS_NAME, element_identifier)))
                    wait(self.driver, 3).until(
                        expected.visibility_of_element_located((By.CLASS_NAME, element_identifier)))
                    return True
                except:
                    return False
            elif search_type == "css_selector":
                try:
                    wait(self.driver, 3).until(
                        expected.presence_of_element_located((By.CSS_SELECTOR, element_identifier)))
                    wait(self.driver, 3).until(
                        expected.visibility_of_element_located((By.CSS_SELECTOR, element_identifier)))
                    return True
                except:
                    return False
            elif search_type == "link_text":
                try:
                    wait(self.driver, 3).until(expected.presence_of_element_located((By.LINK_TEXT, element_identifier)))
                    wait(self.driver, 3).until(
                        expected.visibility_of_element_located((By.LINK_TEXT, element_identifier)))
                    return True
                except:
                    return False
            else:
                raise NotImplemented("search type '{0}' is not implemented".format(search_type))
        except Exception as e:
            raise Exception("Unable to find element: {0}: '{1}'".format(path, e.message))

    def wait_for_element_disappearance(self, path):
        """
        Function to wait for element to disappear from UI
        :param path: search element path
        :return: element if unavailability is confirmed
        """
        search_type = str(path).split('|')[0]
        element_identifier = str(path).split('|')[1]
        try:
            if search_type == "xpath":
                try:
                    wait(self.driver, 3).until(expected.presence_of_element_located((By.XPATH, element_identifier)))
                    wait(self.driver, 3).until(expected.visibility_of_element_located((By.XPATH, element_identifier)))
                except:
                    print 'Info: element not available while verifying disappearance'
                wait(self.driver, 10).until(expected.invisibility_of_element_located((By.XPATH, element_identifier)))

            elif search_type == "id":
                try:
                    wait(self.driver, 5).until(expected.presence_of_element_located((By.ID, element_identifier)))
                    wait(self.driver, 5).until(expected.visibility_of_element_located((By.ID, element_identifier)))
                except:
                    print 'Info: element not available while verifying disappearance'
                wait(self.driver, 10).until(expected.invisibility_of_element_located((By.ID, element_identifier)))

            elif search_type == "name":
                try:
                    wait(self.driver, 5).until(expected.presence_of_element_located((By.NAME, element_identifier)))
                    wait(self.driver, 5).until(expected.visibility_of_element_located((By.NAME, element_identifier)))
                except:
                    print 'Info: element not available while verifying disappearance'
                wait(self.driver, 10).until(expected.invisibility_of_element_located((By.NAME, element_identifier)))

            elif search_type == "class_name":
                try:
                    wait(self.driver, 5).until(
                        expected.presence_of_element_located((By.CLASS_NAME, element_identifier)))
                    wait(self.driver, 5).until(
                        expected.visibility_of_element_located((By.CLASS_NAME, element_identifier)))
                except:
                    print 'Info: element not available while verifying disappearance'
                wait(self.driver, 10).until(
                    expected.invisibility_of_element_located((By.CLASS_NAME, element_identifier)))

            elif search_type == "css_selector":
                try:
                    wait(self.driver, 5).until(
                        expected.presence_of_element_located((By.CSS_SELECTOR, element_identifier)))
                    wait(self.driver, 5).until(
                        expected.visibility_of_element_located((By.CSS_SELECTOR, element_identifier)))
                except:
                    print 'Info: element not available while verifying disappearance'
                wait(self.driver, 10).until(
                    expected.invisibility_of_element_located((By.CSS_SELECTOR, element_identifier)))

            elif search_type == "link_text":
                try:
                    wait(self.driver, 5).until(expected.presence_of_element_located((By.LINK_TEXT, element_identifier)))
                    wait(self.driver, 5).until(
                        expected.visibility_of_element_located((By.LINK_TEXT, element_identifier)))
                except:
                    print 'Info: element not available while verifying disappearance'
                wait(self.driver, 10).until(
                    expected.invisibility_of_element_located((By.LINK_TEXT, element_identifier)))
            else:
                raise NotImplemented("search type '{0}' is not implemented".format(search_type))

        except Exception as e:
            raise Exception("Unable to find element: {0}: '{1}'".format(path, e.message))

    def wait_for_spinner_to_load(self, path, path_disappear, timeout=60):
        """
        Function to wait for element to disappear from UI
        :param path: search element path
        :return: element if unavailability is confirmed
        """
        try:
            element_identifier = str(path).split('|')[1]
            element_identifier_disappear =str(path_disappear).split('|')[1]
            wait(self.driver, timeout).until(expected.visibility_of_element_located((By.XPATH, element_identifier)))
            wait(self.driver, timeout).until(expected.invisibility_of_element_located((By.XPATH, element_identifier)))
            wait(self.driver, timeout).until(expected.invisibility_of_element_located((By.XPATH, element_identifier_disappear)))
        except Exception as e:
                print "Unable to find spinner"

    def find_element(self, path):
        """
        Function to find element by giving 'path'
        :param path: search element path
        :return: element
        """
        search_type = str(path).split('|')[0]
        element_identifier = str(path).split('|')[1]
        try:
            if search_type == "xpath":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.XPATH, element_identifier)))
                wait(self.driver, 45).until(expected.visibility_of_element_located((By.XPATH, element_identifier)))
                elements = self.driver.find_element_by_xpath(element_identifier)
            elif search_type == "id":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.ID, element_identifier)))
                wait(self.driver, 45).until(expected.visibility_of_element_located((By.ID, element_identifier)))
                elements = self.driver.find_element_by_id(element_identifier)
            elif search_type == "name":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.NAME, element_identifier)))
                wait(self.driver, 45).until(expected.visibility_of_element_located((By.NAME, element_identifier)))
                elements = self.driver.find_element_by_name(element_identifier)
            elif search_type == "class_name":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.CLASS_NAME, element_identifier)))
                wait(self.driver, 45).until(expected.visibility_of_element_located((By.CLASS_NAME, element_identifier)))
                elements = self.driver.find_element_by_class_name(element_identifier)
            elif search_type == "css_selector":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.CSS_SELECTOR, element_identifier)))
                wait(self.driver, 45).until(
                    expected.visibility_of_element_located((By.CSS_SELECTOR, element_identifier)))
                elements = self.driver.find_element_by_css_selector(element_identifier)
            elif search_type == "link_text":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.LINK_TEXT, element_identifier)))
                wait(self.driver, 45).until(expected.visibility_of_element_located((By.LINK_TEXT, element_identifier)))
                elements = self.driver.find_element_by_link_text(element_identifier)
            else:
                raise NotImplemented("search type '{0}' is not implemented".format(search_type))
            return elements
        except Exception as e:
            raise Exception("Unable to find element: {0}: '{1}'".format(path, e.message))

    def find_elements(self, path , timeout=45):
        """
        Method to find elements by giving 'path'
        :param path: search element path
        :return: elements
        """
        search_type = str(path).split('|')[0]
        element_identifier = str(path).split('|')[1]
        try:
            if search_type == "xpath":
                wait(self.driver, timeout).until(expected.presence_of_element_located((By.XPATH, element_identifier)))
                wait(self.driver, timeout).until(expected.visibility_of_element_located((By.XPATH, element_identifier)))
                elements = self.driver.find_elements_by_xpath(element_identifier)
            elif search_type == "id":
                wait(self.driver, timeout).until(expected.presence_of_element_located((By.ID, element_identifier)))
                wait(self.driver, timeout).until(expected.visibility_of_element_located((By.ID, element_identifier)))
                elements = self.driver.find_elements_by_id(element_identifier)
            elif search_type == "name":
                wait(self.driver, timeout).until(expected.presence_of_element_located((By.NAME, element_identifier)))
                wait(self.driver, timeout).until(expected.visibility_of_element_located((By.NAME, element_identifier)))
                elements = self.driver.find_elements_by_name(element_identifier)
            elif search_type == "class_name":
                wait(self.driver, timeout).until(expected.presence_of_element_located((By.CLASS_NAME, element_identifier)))
                wait(self.driver, timeout).until(expected.visibility_of_element_located((By.CLASS_NAME, element_identifier)))
                elements = self.driver.find_elements_by_class_name(element_identifier)
            elif search_type == "css_selector":
                wait(self.driver, timeout).until(expected.presence_of_element_located((By.CSS_SELECTOR, element_identifier)))
                wait(self.driver, timeout).until(
                    expected.visibility_of_element_located((By.CSS_SELECTOR, element_identifier)))
                elements = self.driver.find_elements_by_css_selector(element_identifier)
            elif search_type == "link_text":
                wait(self.driver, timeout).until(expected.presence_of_element_located((By.LINK_TEXT, element_identifier)))
                wait(self.driver, timeout).until(expected.visibility_of_element_located((By.LINK_TEXT, element_identifier)))
                elements = self.driver.find_elements_by_link_text(element_identifier)
            else:
                raise NotImplemented("search type '{0}' is not implemented".format(search_type))
            return elements
        except (TimeoutException, ElementNotVisibleException, ElementNotSelectableException) as te:
            # TODO : Add log entry to update timeout for element
            return []


    def get_checkbox_status(self, path):
        """
        Function to check status of checkbox whether it's tick marked
        :param path: search element path
        :return:Boolean (True:for success)
        """
        try:
            if self.find_element(path).is_selected():
                return True
            else:
                return False

        except Exception as e:
            raise Exception("Unable to get status of checkbox for path {0}: '{1}'".format(path, e))

    def get_dropdown_values(self, path):
        """
        This function return list of options available in dropdown
        :param path: path to retrieve option list
        :return: list of visible options in dropdown
        """
        option_list = []
        menuitem_elements = self.find_elements(path)
        for option in menuitem_elements:
            option_list.append(option.text)
        return option_list

    def mouse_hover_click(self, path, edit_link):
        """
        Function perform focusing,mouser over to element on web page
        :param element: element identification
        :return: void
        """
        try:
            webdriver = BaseController.web_driver
            actions = ActionChains(webdriver)
            element = self.find_element(path)
            self.driver.execute_script("arguments[0].scrollIntoView(false);", element)
            actions.move_to_element(element).perform()
            # print 'hover succesufull!!'
            time.sleep(2)
            actions.move_to_element(self.find_element(edit_link)).perform()
            self.click(edit_link)
            time.sleep(6)
        except Exception as e:
            print 'failed to focus link as ' + e.message

    def mouse_hover(self, element):
        """
        Function perform focusing over to element on web page
        :param element: web-element to focus on
        :return: void
        """
        try:
            actions = ActionChains(self.web_driver)
            self.driver.execute_script("arguments[0].scrollIntoView(false);", element)
            actions.move_to_element(element).perform()
        except Exception as e:
            print 'failed to focus link as '+e.message

    def get_attribute(self, path, attribute_name):
        """
        Function to get element attribute
        :param path: search element path
        :param attribute_name: attribute name
        :return:attribute_name
        """
        try:
            the_element = self.find_element(path)
            return the_element.get_attribute(attribute_name)
        except Exception as e:
            raise Exception("Unable to get element attribute: '{0}'".format(e))

    def set_focus(self, path):
        """
        Function to click on element
        :param path: search element path
        :return:Boolean (True:for success)
        """
        try:
            self.find_element(path).send_text('focus')
        except Exception as e:
            print 'set focus done!'

    def click(self, path):
        """
        Function to click on element
        :param path: search element path
        :return:Boolean (True:for success)
        """
        try:
            self.find_element(path).click()
            return True
        except Exception as e:
            raise Exception("Unable to click on element: '{0}'".format(e))

    def click_link(self, link_text):
        """
        Function to click on link
        :param link_text: link text to click
        :return:Boolean (True:for success)
        """
        try:
            self.click('{0}''|{1}'.format("link_text", link_text))
            return True
        except Exception as e:
            raise Exception("Unable to click on link: '{0}'".format(e))

    def enter_text(self, path, text_to_enter):
        """
        Function to send text to element
        :param path: search element path
        :param text_to_enter: text to enter
        :return:Boolean (True:for success)
        """
        try:
            self.find_element(path).clear()
            self.find_element(path).send_keys(text_to_enter)
            return True
        except Exception as e:
            raise Exception("Unable to enter text: '{0}'".format(e))

    def get_text(self, path):
        """
        Function to get element text
        :param path: search element path
        :return:element text
        """
        try:
            element_text = self.find_element(path).text
            return element_text
        except Exception as e:
            raise Exception("Unable to get element text: '{0}'".format(e))

    def is_page_title(self, page_title):
        """
        Function to verify page title
        :param page_title: page title to verify
        :return:Boolean (True:for success)
        """
        try:
            element = wait(self.driver, 100).until(expected.title_is(page_title))
            if element:
                return True
            else:
                return False
        except Exception as e:
            print ("Unable to verify page title: '{0}'".format(e.message))

    def maximize_browser(self):
        """
        Function to maximize browser window
        :return:Boolean (True:for success)
        """
        try:
            self.driver.maximize_window()
            return True
        except Exception as e:
            raise Exception("Unable to maximize browser window '{0}'".format(e))

    def open_url(self, url):
        """
        Function to hit given url
        :return:Boolean (True:for success)
        """
        try:
            self.driver.get(url)
            return True
        except Exception as e:
            raise Exception("Unable to open the given url '{0}'".format(e))

    def set_desired_capability(self, browser):
        """
        This function sets desired capabilities for given browsers
        :return: capabilities
        """
        capabilities = None
        if 'firefox' == browser:
            capabilities = DesiredCapabilities.FIREFOX
        elif 'chrome' == browser:
            capabilities = DesiredCapabilities.CHROME
        elif 'ie' == browser:
            capabilities = DesiredCapabilities.INTERNETEXPLORER
        elif 'safari' == browser:
            capabilities = DesiredCapabilities.SAFARI
        capabilities['loggingPrefs'] = {'browser': 'ALL'}
        return capabilities

    def get_browser_log(self):
        """
        This function returns captured browser log as string
        :return: log_string
        """
        log_string = []
        log_entries = self.driver.get_log('browser')
        # convert log entries from unicode to string
        for entries in log_entries:
            string_data = dict([(str(k), str(v)) for k, v in entries.items()])
            log_string.append(string_data)
        return log_string

    def set_browser_driver(self):
        """
        Function to set browser driver
        :return: webportal driver instance
        """
        try:
            # TODO:Need to handle the code to disable specific extension for chrome
            """Read configuration file"""
            global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'WebConfig'))
            capabilities = self.set_desired_capability(global_config.get('Web', 'browser'))
            profile = self.set_browser_preferences(global_config.get('Web', 'browser'))
            if 'firefox' == global_config.get('Web', 'browser'):
                the_web_driver = webdriver.Firefox(firefox_profile=profile, capabilities=capabilities)
            elif 'chrome' == global_config.get('Web', 'browser'):
                options = webdriver.chrome.options.Options()
                options.add_argument("--disable-extensions")
                the_web_driver = webdriver.Chrome(desired_capabilities=capabilities,chrome_options=profile)
                the_web_driver.implicitly_wait(10)
            elif 'safari' == global_config.get('Web', 'browser'):
                the_web_driver = webdriver.Safari(desired_capabilities=capabilities)
                the_web_driver.implicitly_wait(30)
            elif 'ie' == global_config.get('Web', 'browser'):
                the_web_driver = webdriver.Ie(capabilities=capabilities)
            return the_web_driver
        except Exception as e:
            raise Exception("Unable to set browser '{0}'".format(e))

    def reload_page(self):
        self.driver.refresh()

    def close_browser(self):
        """
        Function to close or quite browser instance
        :return:Boolean (True:for success)
        """
        try:
            BaseController.web_driver.quit()
            BaseController.web_driver = None
            return True
        except Exception as e:
            raise Exception("Unable to quit browser '{0}'".format(e))

    def get_base64_encoded_screen_shot(self, folder_name, file_name):

        # create output directory if it does not exists
        if not os.path.exists(os.path.join(self.get_project_path(), 'screen_shots', 'web')):
            os.makedirs(os.path.join(self.get_project_path(), 'screen_shots', 'web'))

        if not os.path.exists(os.path.join(self.get_project_path(), 'screen_shots', 'web', folder_name)):
            os.makedirs(os.path.join(self.get_project_path(), 'screen_shots', 'web', folder_name))

        abs_file_path = os.path.join(self.get_project_path(), 'screen_shots', 'web', folder_name, file_name + '.png')
        self.driver.get_screenshot_as_file(abs_file_path)
        with open(abs_file_path, "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read())
        img_element = 'b64EncodedStart{0}b64EncodedEnd'.format(encoded_string)
        return img_element

    def select_value_from_dropdown(self, drop_down_path, value_path):
        """
        Function to select given value from given drop-down
        :return:Boolean (True:for success)
        """
        try:
            self.click(drop_down_path)
            self.click(value_path)
            return True
        except Exception as e:
            raise Exception("Unable to select option {0} from the drop-down {1} : {2}".format(value_path,drop_down_path,e))

    def click_checkbox(self, path):
        """
        This function is used to click checkbox using javascript executor
        :param path:
        :return:
        """
        try:
            element_identifier = str(path).split('|')[1]
            self.driver.execute_script("document.getElementById('{0}').click()".format(element_identifier))
        except Exception as e:
            raise Exception("Unable to click checkbox using javascript executor '{0}'".format(e.message))

    def get_status_of_checkbox(self, path):
        """
        This function is used to get the status of checkbox without waiting the elemnt to be present
        :param path:
        :return:
        """
        try:
            if self.driver.find_element_by_id(str(path).split('|')[1]).is_selected():
                return True
            else:
                return False
        except Exception as e:
            raise Exception("Unable to get the status of the checkbox '{0}'".format(e.message))

    def find_elements_by_xpath(self,path,wait_time=45,wait_for_presense=True):
        """
        This method return element when xpath is passed as argument
        :return: web element
        """
        search_type = str(path).split('|')[0]
        element_identifier = str(path).split('|')[1]
        elements=[]
        try:
            if search_type == "xpath":
                if wait_for_presense:
                    wait(self.driver, wait_time).until(expected.presence_of_element_located((By.XPATH, element_identifier)))
                elements = self.driver.find_elements_by_xpath(element_identifier)
                return elements
        except Exception as e:
            print 'no element found with locator value {0}: {1}'.format(path, e.message)
            return elements
            # raise Exception("Unable to find element: {0}: '{1}'".format(path, e.message))

    def find_element_by_xpath(self,path):
        """
        This method return element when xpath is passed as argument
        :return: web element
        """
        search_type = str(path).split('|')[0]
        element_identifier = str(path).split('|')[1]
        try:
            if search_type == "xpath":
                wait(self.driver, 45).until(expected.presence_of_element_located((By.XPATH, element_identifier)))
                elements = self.driver.find_element_by_xpath(element_identifier)
                return elements
        except Exception as e:
            raise Exception("Unable to find element: {0}: '{1}'".format(path, e.message))

    def verify_dicts(self, first_dict_normal, second_dict_normal):
        first_dict = {}
        final_dict = {}
        try:
            for key in first_dict_normal:
                if second_dict_normal.has_key(key):
                    first_value_dict = first_dict_normal[key]
                    second_value_dict = second_dict_normal[key]
                    for val1 in first_value_dict:
                        if first_value_dict[val1] != second_value_dict[val1]:
                            first_dict[val1] = second_value_dict[val1]
                            final_dict[key] = first_dict
            return final_dict

        except Exception as e:
            print "Key not present: [{0}]".format(key)

    def to_dict(self,input_ordered_dict):
        return loads(dumps(input_ordered_dict))

    def set_browser_preferences(self, browser):
        """
        This function creates browser profile and set preferences to that profile
        :param browser:
        :return:
        """
        profile = None
        if 'firefox' == browser:
            profile = webdriver.FirefoxProfile()
            profile.set_preference("browser.download.folderList", 2)
            profile.set_preference("browser.download.manager.showWhenStarting", False)
            profile.set_preference("browser.download.dir", '{0}'.format(self.set_file_download_location()))
            profile.set_preference("browser.helperApps.neverAsk.saveToDisk", "text/csv")
        elif 'chrome' == browser:
            """ providing default download prefernces for chrome """
            profile = webdriver.ChromeOptions()
            prefs = {"download.default_directory" : "{0}".format(self.set_file_download_location())}
            profile.add_experimental_option("prefs",prefs)

        return profile

    def set_file_download_location(self):
        """
        This function defines and returns path where file should be downloaded
        :return: download location
        """
        download_location = os.path.join(self.get_project_path(), 'testdata', 'downloads')
        return download_location

    def set_proxy_browser_driver(self):
        """
        Function to set proxy browser driver
        :return: webportal driver instance
        """
        try:
            """Read configuration file"""
            global_config = self.read_ini_file(os.path.join(self.get_project_path(), 'config', 'WebConfig'))
            BaseController.proxy = self.get_proxy()
            capabilities = self.set_desired_capability(global_config.get('WebProxy', 'browser'))
            profile = self.set_browser_preferences(global_config.get('WebProxy', 'browser'))
            if 'firefox' == global_config.get('WebProxy', 'browser'):
                profile.set_proxy(BaseController.proxy.selenium_proxy())
                the_web_driver = webdriver.Firefox(firefox_profile=profile, capabilities=capabilities)
            elif 'chrome' == global_config.get('WebProxy', 'browser'):
                options = webdriver.chrome.options.Options()
                options.add_argument("--disable-extensions")
                options.add_argument("--proxy-server={0}".format(BaseController.proxy.proxy))
                the_web_driver = webdriver.Chrome(desired_capabilities=capabilities,chrome_options=options)
                the_web_driver.implicitly_wait(10)
            return the_web_driver
        except Exception as e:
            raise Exception("Unable to set proxy browser '{0}'".format(e))

    def get_proxy(self):
        try:
            if BaseController.proxy == None:
                server = Server(os.path.join(self.get_project_path(), 'Binaries','browsermob-proxy-2.1.2','bin','browsermob-proxy'))
                server.start()
                BaseController.proxy = server.create_proxy()
                return BaseController.proxy
            else:
                return BaseController.proxy
        except Exception as e:
            raise Exception("Unable to create proxy '{0}'".format(e))

    def scroll_to_text(self, path):
        """
        Function to scroll to the given text on the screen
        :param: path: of text to which scroll action is performed
        :return:Boolean (True:For success or False:For failure)
        """
        try:
            webdriver = BaseController.web_driver
            actions = ActionChains(webdriver)
            element = self.find_element(path)
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
            actions.move_to_element(element).perform()
            return True
        except Exception as e:
            raise Exception("Unable to scroll down to find text")
