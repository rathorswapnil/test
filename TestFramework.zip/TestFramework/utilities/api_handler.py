import json
import re
import os

import requests
from utilities.Utilities import Utilities

class APIHandler(object):
    """
    This class handles functionality related to RootMetrics API calls for data validation.
    """
    util = Utilities()
    auth_token= ''

    def __init__(self):
        self.auth_token=self._get_authorization_token()

    def _getResponse(self, url, requestType, headers=None, cookies=None, data=None):
        """
        This is a generic method to file any api call
        :param url:
        :param requestType:
        :param headers: dictionary of headers to be set
        :param cookies: dictionary of cookies to be set
        :param content: content to be set
        :return: response object
        """
        if requestType == 'get':
            res = requests.get(url, headers=headers, cookies=cookies)
        elif requestType == 'post':
            res = requests.post(url, headers=headers, cookies=cookies, data=data)
        elif requestType == 'put':
            raise Exception("put - yet to be implemented")
        elif requestType == 'delete':
            raise Exception("delete - yet to be implemented")
        else:
            raise Exception("Invalid request type provided: " + requestType)
        res.raise_for_status()
        return res

    def _get_authorization_token(self):
        """
        This method will return the authorization token to be used for API calls.
        :return: authorization token (beare xxxxxx...)
        """
        util = Utilities()
        global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'WebConfig'))
        reporting_url = str(global_config.get('Web', 'environment_url'))
        username = str(global_config.get('LoginCredentials', 'username'))
        password = str(global_config.get('LoginCredentials', 'password'))

        # Todo Retrieve url from config file
        r1 = self._getResponse(reporting_url, "get")

        # Todo : Move authorization token to a separate function which checks for elapsed time, if time > 60 min,
        # Todo :  return new token else return existing token
        csrf_token = r1.cookies['csrftoken']
        session_id = r1.cookies['sessionid']
        redirect_location = r1.url
        cookies = {'csrftoken': csrf_token, 'sessionid': session_id}
        r2 = self._getResponse(redirect_location, "get", cookies=cookies)

        headers = {'Referer': redirect_location}
        cookies = {'csrftoken': csrf_token, 'sessionid': session_id}
        # TDOD Retrieve username and password from config file
        content = {'csrfmiddlewaretoken': csrf_token, 'username': username,
                   'password': password}
        r3 = self._getResponse(redirect_location, "post", headers=headers, cookies=cookies, data=content)

        redirect_location = r3.history[0].headers['location']
        resp_headers = r3.history[1].headers['Set-Cookie']
        access_token = re.search('access_token=(.*?);', resp_headers).group(1)
        refresh_token = re.search('refresh_token=(.*?);', resp_headers).group(1)
        authorization_token = 'bearer ' + access_token
        print "Retrieved authorization token :" + authorization_token
        return authorization_token

    def get_product_id(self, product_name, product_period, country):
        """
        This function will return the product id based on the product name, period and country
        :param product_name: Valid product names as given in 'v1/products' API response,
            corresponding to 'product_line' eg: 'RSR metro'
        :param product_period: Valid product periods as given in 'v1/products' API response,
            corresponding to 'friendly_product_period' eg: '1H 2015'
        :param country: Valid product periods as given in 'v1/products' API response,
            corresponding to 'country' eg: 'United States'
        :return: product_id
        """

        util = Utilities()
        global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'WebConfig'))
        reporting_url = str(global_config.get('Web', 'reports_url'))

        # authorization_token = self._get_authorization_token()

        headers = {'Authorization': self.auth_token}
        res = self._getResponse(reporting_url + 'reportsdafasdfasds/v1/products', "get", headers=headers)
        api_res_json = json.loads(res.content)
        product_id = [product.get('product_id') for product in api_res_json['products'] if
                      product.get('product_composite_key').get('country') == country and product.get('product_composite_key').get('product_period')[5:]+' '+product.get('product_composite_key').get('product_period')[:4] == product_period and product.get(
                          'product_composite_key').get('product_line') == product_name]
        if product_id.__len__() != 1:
            raise OverflowError("More than one or zero products were retrieved")
        return product_id[0]

   
if __name__ == "__main__":
    test=APIHandler()
    # test.report_api_validation('United States','RSR Metro','2H 2015',None,None,'x')
    # test.get_product_id()
    # test.get_authorization_token()

    # product_id=test.get_product_id('RSR Metro','2H 2015','United States')
    # content=test.get_scores_for_winners(product_id)
    # res_json=json.loads(content)
    # col_name_list=json.loads(content)['report_metadata']['columns']
    # value_list=json.loads(content)['stats']['reports']
    # value_dict={}
    # for stat in value_list:
    #     for i in xrange(len(stat)):
    #         value_dict[col_name_list[i]]=stat[i]
    #
    # print value_dict
    # collection_set_id=2725
    # res_net_json = test.get_net_params(product_id,collection_set_id)
    # print res_net_json
    # test.get_stats(35,'Verizon')
    # test.get_scores_for_winners(35)
    # res=test.fetch_report_data_for_graphs('United States','RSR Metro','2H 2015','T-Mobile','Virginia Beach, VA','paired_snr','dsd_effective_throughput')
    # pass
    # test.fetch_report_data_for_graphs('United States','RSR Metro','2H 2015')