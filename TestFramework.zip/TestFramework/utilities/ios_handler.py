import os
from utilities.Utilities import Utilities

util = Utilities()
global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'MobileConfig'))
ideviceinstaller_path="/usr/local/bin/"
platform = global_config.get('Generic', 'execution_platform').lower()

def install_ipa(absolute_path_to_ipa):
    """
    The function is used to install the app
    :param absolute_path_to_apk: Path to the apk file
    :return: response
    """
    try:
        response = os.system(ideviceinstaller_path + "ideviceinstaller -i {0}".format(absolute_path_to_ipa))
        return response
    except Exception as e:
        raise Exception("Unable to install the ipa", e.message)

def uninstall_ipa():
    """
    The function is used to uninstall the app
    :param absolute_path_to_apk: Path to the apk file
    :return: response
    """
    try:
        response = os.system(ideviceinstaller_path + "ideviceinstaller -U com.rootmetrics.map")
        return response
    except Exception as e:
        raise Exception("Unable to uninstall the ipa", e.message)

