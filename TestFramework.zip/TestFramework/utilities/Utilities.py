import json
import os

import configparser


class Utilities(object):
    def get_project_path(self):
        """ Get the prject path for the current project"""
        try:
            project_path = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
            return project_path
        except Exception:
            raise Exception("Unable to get project path")

    def read_ini_file(self, file_path):
        """
        Function to read any .ini file and return a parser object
        :param file_path:
        :return:
        """
        try:
            parser = configparser.ConfigParser()
            parser.read(file_path + '.ini')
            return parser
        except Exception:
            raise Exception("Unable to read file '{0}.{1}'".format(file_path, 'ini'))

    def read_json_file(self, file_path):
        """
        Function to read any .json file and return a json object
        :param json object:
        :return:
        """
        try:
            json_data = open(file_path + '.json').read()
            data = json.loads(json_data)
            return data
        except Exception as e:
            raise Exception("Unable to read file '{0}.{1}' as '{2}'".format(file_path, 'json', e.message))

    def update_ini_file(self, value_name, value):
        """
        This function is used to set the values in ini file for scout master app
        :param value_name:
        :param value:
        :return:
        """
        # TODO: Make the section name also parameterised
        try:
            projectpath = self.get_project_path()
            mobile_parser = configparser.ConfigParser()
            fp = open(os.path.join(projectpath, 'config', 'MobileConfig.ini'), "r+")
            mobile_parser.read(os.path.join(projectpath, 'config', 'MobileConfig.ini'))
            mobile_parser.set('Android_ScoutMaster', value_name, value)
            mobile_parser.write(fp)
            fp.close()
        except Exception as e:
            raise Exception("Unable to update ini file", e.message)
