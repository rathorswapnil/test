import psycopg2
import psycopg2.extras


class DBHandler(object):
    publicationtest_db_cursor = None
    authorization_db_cursor = None
    rootadmin_db_cursor = None
    oauth_db_cursor = None
    rootauth_db_cursor = None
    connection = None

    def connect_to_databse(self, databasename):
        try:
            connection_string = "dbname='{0}' user='{1}' host='{2}' password='{3}'".format(databasename, 'sa', 'penvironment.cd8ppgk5ioqo.us-west-2.rds.amfdfdsdafazonaws.com', '5d7FsdaNC3sadfsadfX')
            connection = psycopg2.connect(connection_string)
            if databasename == "publicationtest":
                if self.publicationtest_db_cursor is None:
                    self.publicationtest_db_cursor = connection.cursor()
                    return self.publicationtest_db_cursor
                else:
                    return self.publicationtest_db_cursor
        except Exception as e:
            self.connection.close()
            print "Unable to connect to " + databasename + e.message

    def get_roles(self):
        """
        This function returns the all roles available in ws_authorization database
        :return: query results as string
        """
        try:
            cursor_instance = self.connect_to_databse('ws_authorization')
            cursor_instance.execute("select * from role")
            query_results = cursor_instance.fetchall()
            return query_results
        except Exception as e:
            print "Unable to get role from ws_authorization database" + e.message

if __name__ == '__main__':
    obj = DBHandler()
    #rows=obj.get_roles()
    #rows=obj.get_users()
    #rows=obj.get_role_permissions()
    #rows=obj.get_user_permissions()
    #rows = obj.get_users_permissions(7, "afourtest@test.com")
    rows = obj.get_roles_permissions("afour-test-role2")
    #rows = obj.get_api_endpoints()
    print(rows)