import os
import time
from utilities.Utilities import Utilities

util = Utilities()
global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'MobileConfig'))
adb_path = "$ANDROID_HOME/platform-tools"
platform = global_config.get('Generic', 'execution_platform').lower()

def clear_app_data(app_package):
    """
    The function is used to clear the app data
    :param app_package: package name for the app
    :return: (True for Success and False for failure)
    """
    try:
        if platform == 'windows':
            output = os.system("adb shell pm clear " + app_package)
        else:
            output = os.system(adb_path + "/adb shell pm clear " + app_package)
        if 0 == output:
            return True
        else:
            return False
    except Exception as e:
        raise Exception("Unable to clear the app data", e.message)


def install_app(absolute_path_to_apk):
    """
    The function is used to install the app
    :param absolute_path_to_apk: Path to the apk file
    :return: response
    """
    try:
        if platform == 'windows':
            response = os.system("adb install {0}".format(absolute_path_to_apk))
        else:
            response = os.system(adb_path + "/adb install {0}".format(absolute_path_to_apk))
        return response
    except Exception as e:
        raise Exception("Unable to install the app", e.message)


def capture_pic():
    """
    This function will capure a pic from the camera using adb command.
    Ensure that the camera is open before calling this function
    :return: True if the pic was capture and false otherwise
    """
    try:
        if platform == 'windows':
            response = os.system('adb shell "input keyevent KEYCODE_CAMERA"')
        else:
            response = os.system(adb_path + '/adb shell "input keyevent KEYCODE_CAMERA"')
        return response
    except Exception as e:
        raise Exception("Unable to capture pic", e.message)


def send_text(text_to_type):
    """
    The function is used to send the text
    :param text_to_type: Text to be entered
    :return: (True for Success and False for failure)
    """
    try:
        if platform == 'windows':
            output = os.system('adb shell input keyboard text {0}'.format(text_to_type.replace(' ', '%s')))
        else:
            output = os.system(adb_path + '/adb shell input keyboard text {0}'.format(text_to_type.replace(' ', '%s')))
        if 0 == output:
            return True
        else:
            return False
    except Exception as e:
        raise Exception("Unable to enter the text", e.message)


def send_key(key_values):
    """
    The function is used to  enter key value
    :param key_values: key value
    :return: (True for Success and False for failure)
    """
    if platform == 'windows':
        output = os.system('adb shell input keyevent {0}'.format(key_values))
    else:
        output = os.system(adb_path + '/adb shell input keyevent {0}'.format(key_values))
    if 0 == output:
        return True
    else:
        return False


def tapscreen(x, y):
    """
    The function is used to tap on screen
    :param x: x dimension
    :param y: y dimension
    :return: (True for Success and False for failure)
    """
    if platform == 'windows':
        os.system('adb shell input tap %d %d' % (x, y))
    else:
        os.system(adb_path + '/adb shell input tap %d %d' % (x, y))
    return True


def set_clipboard_text(clip_text):
    """
    The function is used to install and set the keyboard
    :param clip_text: Clipboard value to set
    :return: (True for Success and False for failure)
    """
    output = install_app(os.path.join(util.get_project_path(), 'Binaries', 'clipper.apk'))

    if platform == 'windows':
        output = os.system('adb shell # am startservice ca.zgrs.clipper\.ClipboardService')
        output = os.system('adb shell am broadcast -a clipper.set -e text "{0}"'.format(clip_text))
    else:
        output = os.system(adb_path + '/adb shell am startservice ca.zgrs.clipper\.ClipboardService')
        output = os.system(adb_path + '/adb shell am broadcast -a clipper.set -e text "{0}"'.format(clip_text))

    time.sleep(2)
    if 0 == output:
        return True
    else:
        return False


def install_and_set_keyboard(keyboard):
    """
    The function is used to install and set the keyboard
    :param keyboard: keyboard value
    :return: (True for Success and False for failure)
    """
    if keyboard not in ['google', 'adb']:
        raise Exception('Please provide correct value for keyboard')

    output = install_app(os.path.join(util.get_project_path(), 'Binaries', '{0}-keyboard.apk'.format(keyboard)))

    if platform == 'windows' and keyboard.lower() == 'adb':
        output = os.system('adb shell ime set com.android.adbkeyboard/.AdbIME')
    elif platform == 'windows' and keyboard.lower() == 'google':
        output = os.system(
            'adb shell ime set com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME')
    elif platform == 'mac' and keyboard.lower() == 'adb':
        output = os.system(adb_path + '/adb shell ime set com.android.adbkeyboard/.AdbIME')
    elif platform == 'mac' and keyboard.lower() == 'google':
        output = os.system(
            adb_path + '/adb shell ime set com.google.android.inputmethod.latin/com.android.inputmethod.latin.LatinIME')

    if 0 == output:
        return True
    else:
        return False


def send_unicode_characters_to_keyboard(characters):
    """
    The function is used to send the unicode characters
    :param characters: characters to be entered
    :return: (True for Success and False for failure)
    """
    if platform == 'windows':
        output = os.system('adb shell am broadcast -a ADB_INPUT_TEXT --es msg "{0}"'.format(characters))
    else:
        output = os.system(adb_path + '/adb shell am broadcast -a ADB_INPUT_TEXT --es msg "{0}"'.format(characters))

    if 0 == output:
        return True
    else:
        return False


def enable_and_disable_airplane_mode(status):
    """
    The function is used enable the airplane mode
    :param status: on/off value to switch on or off the airplane mode
    :return:True(For Success)
    """
    try:
        status_val = None
        status_flag = None
        if status.lower() == "on":
            status_val = 1
            status_flag = "true"
        elif status.lower() == "off":
            status_val = 0
            status_flag = "false"

        os.system('adb shell settings put global airplane_mode_on {0}'.format(status_val))
        time.sleep(1)
        os.system('adb shell am broadcast -a android.intent.action.AIRPLANE_MODE --ez state {0}'.format(status_flag))
        time.sleep(3)
        return True
    except Exception as e:
        raise Exception("unbale to enable the airplane mode", e.message)


def enable_and_disable_mobiledata(status):
    """
    The function is used to enable/disable mobiledata
    :param status: on/off value to switch on or off the mobiledata
    :return: True(For Success)
    """
    try:
        os.system(' adb shell am start -n io.appium.settings/.Settings -e data "{0}"'.format(status.lower()))
        time.sleep(5)
        return True
    except Exception as e:
        raise Exception("Unable to enable or disable the mobiledata", e.message)


def enable_and_disable_wifi(status):
    """
    The function is used to enable/disable wifi services
    :param status: on/off value to switch on or off the wifi
    :return: True(For Success)
    """
    try:
        os.system(' adb shell am start -n io.appium.settings/.Settings -e wifi "{0}"'.format(status.lower()))
        time.sleep(5)
        return True
    except Exception as e:
        raise Exception("Unable to enable or disable the wifi", e.message)

def kill_app():
    """
    The function is used to kill the application
    :return: True(For Success)
    """

    try:
        global_config = util.read_ini_file(os.path.join(util.get_project_path(), 'config', 'MobileConfig'))
        package = global_config.get('Android_CoverageMap', 'app_package')
        os.system('adb shell am force-stop "{0}"'.format(package))
        return True
    except Exception as e:
        raise Exception("Unable to kill the app",e.message)


def enable_and_disable_location_services(status):
    """
    The function is used to enable and disable location services
    :param:status:gps to enable and " " to disable location services
    :return:
    """
    try:
        os.system('adb shell settings put secure location_providers_allowed "{0}"'.format(status.lower()))
        time.sleep(3)
    except Exception as e:
        raise Exception("unable to enable and disable location services",e.message)
