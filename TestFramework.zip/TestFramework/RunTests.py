import sys
import getopt
import os
import configparser


def main(argv):
    project_location = os.path.abspath(os.path.join(os.path.dirname(__file__), "."))
    opts = None
    args = None
    app_name = 'none'
    suite_to_execute = None
    suite_name = None
    kit_type = None
    platform_name = None

    if (argv.__len__()) != 0:
        try:
            opts, args = getopt.getopt(argv, "hp:a:j:k:s:", ["help", "platform=", "app=", "suite=", "kit="])
        except getopt.GetoptError:
            print 'Please specify correct usage as\n[-h <Help>]\n[-p < chrome | firefox | ie | safari | ios | android |e2e >]\n[-a < coveragemap | scoutmaster >]\n[-j < metro | airport | urban | transit >]\n[-k < single | dual >]\n[-s < fullsuite | bvt | rootmetrics.com | webportal_1.1 | webportal_1.3| webportal_1.5 | webportal_1.7_ui | webportal_1.8| webportal_1.8_ui|webportal_2.0_ui| opsmanager | allendtoend | specificend2end>]'
            sys.exit(2)

        for opt, arg in opts:
            if opt in ("-p", "--platform"):
                platform_name = arg.lower()
                continue

            if opt in ("-a", "--app"):
                app_name = arg.lower()
                continue

            if opt in ("-s", "--suite"):
                suite_name = arg.lower()
                continue

            if opt in ("-k", "--kit"):
                kit_type = arg
                continue

            if opt == "-h":
                print '[-h <Help>]\n[-p < chrome | firefox | ie | safari | ios | android | e2e>]\n[-a < coveragemap | scoutmaster >]\n[-s < fullsuite | bvt | rootmetrics.com | webportal_1.1 | webportal_1.3| webportal_1.5| webportal_1.7 |opsmanager | allendtoend | specificend2end | scoutmaster_alarms|webportal_1.7_ui|webportal_1.8|webportal_1.8_ui|webportal_2.0_ui>]\n[-k < single | dual >]'
                sys.exit()

        '''Setting default parameters for scoutmaster app test execution if not entered on terminal'''
        if 'none' not in app_name and 'scoutmaster' in app_name:
            suite_flag = False
            for opt in opts:
                if '--suite' not in opt and '-s' not in opt and 'scoutmaster' in app_name:
                    continue
                else:
                    suite_flag = True
                    continue
            if not suite_flag:
                suite_name = 'fullsuite'

    else:
        platform_name = 'chrome'
    supported_platforms = ['safari', 'chrome', 'firefox', 'ie', 'ios', 'android', 'e2e']
    supported_suites = ['fullsuite', 'bvt', 'rootmetrics.com', 'webportal_1.1', 'webportal_1.3', 'webportal_1.5', 'webportal_1.7', 'webportal_1.7_ui', 'webportal_1.8', 'webportal_1.8_ui', 'webportal_2.0_ui', 'opsmanager',
                        'allend2end', 'specificend2end', 'scoutmaster_alarms','reports','about','settings','foreground']

    mobile_parser = configparser.ConfigParser()
    mobile_parser.read_file(open(project_location + "/config" + "/MobileConfig.ini"))
    fp1 = open(project_location + "/config" + "/MobileConfig.ini", "r+")

    if platform_name in supported_platforms or suite_name in supported_suites:
        if platform_name == 'android' and app_name == 'coveragemap':
            mobile_parser.set('Generic', 'device_type', 'android')

            mobile_parser.set('Generic', 'app', app_name)
            suite_to_execute = 'RunAndGenerateAndroidSuiteReport_coveragemap.py'
            mobile_parser.write(fp1)
            fp1.close()
        elif platform_name == 'android' and app_name == 'scoutmaster':
            mobile_parser.set('Generic', 'device_type', 'android')

            mobile_parser.set('Generic', 'app', app_name)
            if suite_name == 'fullsuite':
                suite_to_execute = 'RunAndGenerateAndroidSuiteReport_fullsuite_scoutmaster.py'
            elif suite_name == 'scoutmaster_alarms' and kit_type == 'single':
                suite_to_execute = 'RunAndGenerateSuiteReport_SingleKitAlarmFunctionality.py'
            elif suite_name == 'scoutmaster_alarms' and kit_type in [None, 'dual']:
                suite_to_execute = 'RunAndGenerateSuiteReport_DualKitAlarmFunctionality.py'
            else:
                suite_to_execute = 'RunAndGenerateAndroidSuiteReport_bvt_scoutmaster.py'
            mobile_parser.write(fp1)
            fp1.close()
        elif platform_name == 'ios' and app_name == 'coveragemap':
            mobile_parser.set('Generic', 'device_type', 'ios')
            mobile_parser.write(fp1)
            if suite_name == 'support_firstlaunch_foreground':
                suite_to_execute = 'iOS_SupportScreen_FirstLaunch_ForegroundTestScreen_suite.py'
            elif suite_name == 'about_settings_report':
                suite_to_execute = 'iOS_AboutScreen_SettingsScreen_ReportScreen_suite.py'
            elif suite_name == 'location_disabled':
                suite_to_execute = 'iOS_LocationServices_disabled_wifiOFF_suite.py'
            elif suite_name == 'map':
                suite_to_execute = 'iOS_MapScreen_Suite.py'
            fp1.close()
        elif platform_name == 'e2e' and suite_name in ['allendtoend', 'specificend2end']:
            print "Setting suite to execute as one of the e2e suties"
            web_parser = configparser.ConfigParser()
            fp = open(project_location + "/config" + "/WebConfig.ini", "r+")
            web_parser.read(project_location + "/config" + "/WebConfig.ini")
            web_parser.set('Web', 'browser', 'chrome')
            mobile_parser.set('Generic', 'app', 'scoutmaster')
            mobile_parser.set('Generic', 'device_type', 'android')
            mobile_parser.write(fp1)
            fp1.close()
            if suite_name == 'allendtoend':
                suite_to_execute = 'RunAndGenerateEndToEndSuiteAll.py'
            elif suite_name == 'specificend2end':
                suite_to_execute = 'RunAndGenerateEndToEndSuiteSpecific.py'
            web_parser.write(fp)
            fp.close()
        else:
            web_parser = configparser.ConfigParser()
            fp = open(project_location + "/config" + "/WebConfig.ini", "r+")
            web_parser.read(project_location + "/config" + "/WebConfig.ini")
            web_parser.set('Web', 'browser', platform_name)
            if suite_name == 'rootmetrics.com':
                suite_to_execute = 'RunAndGenerateRootmetricsPortalSuiteReport.py'
            elif suite_name == 'webportal_1.1':
                suite_to_execute = 'RunAndGenerateWebportal_1.1PortalSuiteReport.py'
            elif suite_name == 'webportal_1.3':
                suite_to_execute = 'RunAndGenerateWebportal_1.3PortalSuiteReport.py'
            elif suite_name == 'webportal_1.5':
                suite_to_execute = 'RunAndGenerateWebportal_1.5PortalSuiteReport.py'
            elif suite_name == 'webportal_1.7':
                suite_to_execute = 'RunAndGenerateWebportal_1.7Functional_PortalSuiteReport.py'
            elif suite_name == 'webportal_1.7_ui':
                suite_to_execute = 'RunAndGenerateWebportal_1.7WebPortal_UI_SuiteReport.py'
            elif suite_name == 'webportal_1.8':
                suite_to_execute = 'RunAndGenerateWebportal_1.8PortalSuitReport.py'
            elif suite_name == 'webportal_1.8_ui':
                suite_to_execute = 'RunAndGenerateWebportal_1.8Portal_UISuiteReport.py'
            elif suite_name == 'webportal_2.0_ui':
                suite_to_execute = 'RunAndGenerateWebportal_2.0Portal_UISuiteReport.py'
            elif suite_name == 'opsmanager':
                suite_to_execute = 'RunAndGenerateOpsManager.py'
            else:
                suite_to_execute = 'RunAndGenerateWebportal_1.0PortalSuitReport.py'
            web_parser.write(fp)
            fp.close()

        if (suite_to_execute != None):
            abs_path_of_suite_to_execute = os.path.join(project_location, suite_to_execute)
            os.system("python " + abs_path_of_suite_to_execute)
        else:
            print ("Please provide -s {Suite Name} to Execute")
    else:
        print "Please provide correct platform or suite values"'\n'"Platform = < chrome | firefox | ie | safari | ios | android >"'\n'"Suites = < fullsuite | bvt| rootmetrics.com | webportal_1.1 | webportal_1.3| webportal_1.5|opsmanager | allendtoend | specificend2end | scoutmaster_alarms>"


if __name__ == "__main__":
    main(sys.argv[1:])
